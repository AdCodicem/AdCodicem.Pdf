#!/bin/bash
cd /home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-23 || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
exec setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "$1"
