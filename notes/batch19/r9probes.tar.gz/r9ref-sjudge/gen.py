import struct
import sys
from pathlib import Path

out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)


def build(name, pad=0, with11=True, s_prev_ref=True):
    """A hybrid file: an oldest classic table, then S (the /XRefStm's stream, object 6) whose /Prev is a reference to
    object 20, which holds '21 0 R' and a long comment, object 21 holding the table's /Prev; the newest table's /Prev
    falls 7 bytes before S."""
    head = b"%PDF-1.5\n%\xe2\xe3\xcf\xd3\n"
    parts = [head]
    offs = {}

    def add(num, body):
        offs[num] = sum(len(p) for p in parts)
        parts.append(b"%d 0 obj\n" % num + body + b"\nendobj\n")

    add(1, b"<< /Type /Catalog /Pages 2 0 R >>")
    add(2, b"<< /Type /Pages /Kids [] /Count 0 >>")
    add(3, b"(three old)")
    t0 = sum(len(p) for p in parts)
    rows = b"0000000000 65535 f \n" + b"".join(b"%010d 00000 n \n" % offs[n] for n in (1, 2, 3))
    parts.append(b"xref\n0 4\n" + rows + b"trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % t0)
    if pad:
        parts.append(b"%" + b"-" * (pad - 2) + b"\n")
    add(4, b"(four)")
    s_at = sum(len(p) for p in parts)
    table_prev = s_at - 7

    # Offsets after S are computed in two passes: S's length does not depend on them (fixed-width rows).
    def assemble(o20, o21, o11):
        data = b"".join(struct.pack(">BIH", 1, o, 0) for o in (offs[4], s_at, o20, o21))
        prev = b"/Prev 20 0 R" if s_prev_ref else b"/Prev %010d" % table_prev
        s = (b"6 0 obj\n<< /Type /XRef /Size 22 /W [1 4 2] /Index [4 1 6 1 20 2] /Root 1 0 R " + prev +
             b" /Length %d >>\nstream\n" % len(data) + data + b"\nendstream\nendobj\n")
        tail = []
        pos = s_at + len(s)
        p11 = pos
        if with11:
            d11 = struct.pack(">BIH", 1, o11, 0)
            o11_text = (b"11 0 obj\n<< /Type /XRef /Size 22 /W [1 4 2] /Index [11 1] /Root 1 0 R /Prev %010d /Length 7 >>\nstream\n" % t0
                        + d11 + b"\nendstream\nendobj\n")
            tail.append(o11_text)
            pos += len(o11_text)
        p20 = pos
        o20_text = b"20 0 obj\n21 0 R\n%" + b"=" * 120 + b"\nendobj\n"
        tail.append(o20_text)
        pos += len(o20_text)
        p21 = pos
        o21_text = b"21 0 obj\n%010d\nendobj\n" % table_prev
        tail.append(o21_text)
        pos += len(o21_text)
        t1 = pos
        tail.append(b"xref\n0 1\n0000000000 65535 f \ntrailer\n<< /Size 22 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n"
                    % (table_prev, s_at, t1))
        return s, tail, (p20, p21, p11)

    s, tail, (p20, p21, p11) = assemble(0, 0, 0)
    s, tail, _ = assemble(p20, p21, p11)
    data = b"".join(parts) + s + b"".join(tail)
    (out / name).write_bytes(data)
    print(name, "S at", s_at, "table /Prev", table_prev, "first table at", t0, "obj20 at", p20)


build("re-big-S.pdf")
build("retry-S.pdf", pad=700, with11=False)
build("retry-S-direct.pdf", pad=700, with11=False, s_prev_ref=False)
