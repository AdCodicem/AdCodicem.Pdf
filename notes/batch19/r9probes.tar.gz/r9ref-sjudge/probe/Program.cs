using System.Collections;
using System.Reflection;
using AdCodicem.Pdf;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.Objects;

foreach (var path in args)
{
    var bytes = File.ReadAllBytes(path);
    foreach (var (name, options) in new (string, PdfReaderOptions)[]
    {
        ("default", PdfReaderOptions.Default),
        ("object64", new PdfReaderOptions { Limits = PdfReaderLimits.Default with { MaxObjectLength = 64 } }),
        ("object64throw", new PdfReaderOptions { ThrowOnLimit = true, Limits = PdfReaderLimits.Default with { MaxObjectLength = 64 } }),
        ("throw", new PdfReaderOptions { ThrowOnLimit = true }),
    })
    {
        Console.WriteLine($"=== {Path.GetFileName(path)} {name}");
        try
        {
            using var document = PdfDocument.Open(bytes, options);
            var reader = typeof(PdfDocument).GetProperty("Reader", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(document)!;
            var structure = reader.GetType().GetProperty("Structure")!.GetValue(reader)!;
            var sections = (IEnumerable)structure.GetType().GetProperty("Sections")!.GetValue(structure)!;
            foreach (var s in sections)
            {
                var t = s.GetType();
                Console.WriteLine($"S {t.GetProperty("NamedBy")!.GetValue(s)} {t.GetProperty("NamedOffset")!.GetValue(s)} {t.GetProperty("Offset")!.GetValue(s)} {t.GetProperty("Kind")!.GetValue(s)} {t.GetProperty("State")!.GetValue(s)}");
            }

            Console.WriteLine($"R open WasRepaired={document.WasRepaired}");
            foreach (var d in document.Diagnostics)
            {
                Console.WriteLine($"D {d.Severity} {d.Code} {d.Position} {d.Message}");
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"T open {e.GetType().Name}: {e.Message}");
        }
    }
}
