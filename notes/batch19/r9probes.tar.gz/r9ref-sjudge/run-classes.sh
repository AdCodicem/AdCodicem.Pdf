#!/bin/bash
# Runs the reader's chain test classes in the worktree given as $1, one dotnet process, bounded.
export DOTNET_GCHeapHardLimit=0xC0000000
cd "$1" || exit 1
setsid -w timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- \
  --filter-class "*GuardCutValueTests" --filter-class "*HostileInputTests" --filter-class "*CrossReferenceChainTests" \
  --filter-class "*ReaderLimitsTests" --filter-class "*CrossReferenceRuleTests" 2>&1 | tail -8
