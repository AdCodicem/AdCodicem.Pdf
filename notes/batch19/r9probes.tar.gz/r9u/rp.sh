#!/bin/bash
# $1 = repo dir, $2 = method filter, $3 = output file
cd "$1" || exit 2
export DOTNET_GCHeapHardLimit=0xC0000000
if [ -n "$4" ]; then mkdir -p "$4"; export ZZ_OUT="$4"; fi
dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*$2*" --output Detailed > "$3" 2>&1
echo "exit $?" >> "$3"
