
    private static string Codes(PdfDocument document) =>
        string.Join(",", document.Diagnostics.Select(d => Inv($"{d.Code}@{d.Position}")));

    // P-A: dropped candidate (key twice + undecodable), oldest table out of the search's reach: the chain ends, a rebuild
    // indexes object 4; how often are the dictionary's and the decoding's reports made?
    [Theory]
    [InlineData("/Foo")]
    [InlineData("/FlateDecode")]
    public void ZzR9Rebuild(string filter)
    {
        output = new Out("rebuild");
        var file = new HandWrittenFile(version: "1.5");
        var catalog = file.Object(1, "<< /Type /Catalog /Pages 2 0 R >>");
        var pages = file.Object(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        var page = file.Object(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << >> >>");
        var oldest = file.Position;
        file.Raw(Inv($"xref\n0 4\n0000000000 65535 f \n{Row(catalog)}{Row(pages)}{Row(page)}trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n{oldest}\n%%EOF\n"));
        file.Raw("%" + new string('-', 1200) + "\n");
        var four = file.Object(4, Inv($"<< /Size 10 /W [1 4 2] /W [1 4 2] /Index [7 1] /Filter {filter} /Length 7 >>\nstream\nxxxxxxx\nendstream"));
        file.Raw("%" + new string('-', 1200) + "\n");
        var six = file.Object(6, "(six)");
        var newest = file.Position;
        file.Raw(Inv($"xref\n0 1\n0000000000 65535 f \n6 1\n{Row(six)}trailer\n<< /Size 10 /Root 1 0 R /Prev {four + 4} >>\nstartxref\n{newest}\n%%EOF\n"));
        using var document = PdfDocument.Open(file.Bytes);
        output.WriteLine(filter + " open: " + Codes(document));
        var obj = document.GetObject(new PdfObjectId(4));
        output.WriteLine(filter + " obj4: " + obj?.GetType().Name + " " + Codes(document));
        if (obj is PdfStream s)
        {
            _ = s.Decode();
        }

        output.WriteLine(filter + " decoded: " + Codes(document));
        _ = new PdfValidator().Validate(document);
        output.WriteLine(filter + " validated: " + Codes(document));
    }

    // P-C: the HybridFiles shape of the round-8 test, two read orders after opening.
    [Theory]
    [InlineData("[1 4 2] /W [1 4 2]", "/Foo", null)]
    [InlineData("[1 4 2]", "/Foo", 3)]
    [InlineData("[1 4 2] /W [1 4 2]", "/FlateDecode", null)]
    public void ZzR9Orders(string widths, string filter, int? length)
    {
        output = new Out("orders");
        var (file, _, _, _) = HybridFiles.PrevNamingAStreamBesideTheOldestTable(string.Empty, widths: widths, filter: filter, length: length);
        string RunA()
        {
            using var d = PdfDocument.Open(file);
            var o = d.GetObject(new PdfObjectId(4));
            if (o is PdfStream s)
            {
                _ = s.Decode();
            }

            _ = new PdfValidator().Validate(d);
            _ = new PdfValidator().Validate(d);
            return string.Join(",", d.Diagnostics.Select(x => Inv($"{x.Code}@{x.Position}")).Order());
        }

        string RunB()
        {
            using var d = PdfDocument.Open(file);
            _ = new PdfValidator().Validate(d);
            var o = d.GetObject(new PdfObjectId(4));
            if (o is PdfStream s)
            {
                _ = s.Decode();
            }

            _ = new PdfValidator().Validate(d);
            return string.Join(",", d.Diagnostics.Select(x => Inv($"{x.Code}@{x.Position}")).Order());
        }

        var a = RunA();
        var b = RunB();
        output.WriteLine(Inv($"{widths}|{filter}|{length}: same={a == b} A={a}"));
        if (a != b)
        {
            output.WriteLine("   B=" + b);
        }
    }

    // P-B: public decoding paths with an unsupported filter and with Flate data corrupt before its first byte.
    [Theory]
    [InlineData("/Foo")]
    [InlineData("/FlateDecode")]
    [InlineData("[/FlateDecode /Foo]")]
    public void ZzR9Paths(string filter)
    {
        output = new Out("paths");
        var file = new HandWrittenFile(version: "1.5");
        var o1 = file.Object(1, "<< /Type /Catalog /Pages 2 0 R >>");
        var o2 = file.Object(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        var o3 = file.Object(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 8 0 R /Resources << >> >>");
        var o8 = file.Object(8, Inv($"<< /Filter {filter} /Length 7 >>\nstream\nxxxxxxx\nendstream"));
        var members = "5 0 (five)";
        var o4 = file.Object(4, Inv($"<< /Type /ObjStm /N 1 /First 4 /Filter {filter} /Length {members.Length} >>\nstream\n{members}\nendstream"));
        var xs = file.Position;
        var rows = StreamRows((0, 0, 65535), (1, o1, 0), (1, o2, 0), (1, o3, 0), (1, o4, 0), (2, 4, 0), (0, 0, 0), (0, 0, 0), (1, o8, 0), (1, xs, 0));
        file.Object(9, Inv($"<< /Type /XRef /Size 10 /W [1 4 2] /Root 1 0 R /Length {rows.Length} >>\nstream\n{rows}\nendstream"));
        file.Raw(Inv($"startxref\n{xs}\n%%EOF\n"));
        using var document = PdfDocument.Open(file.Bytes);
        output.WriteLine(filter + " open: " + Codes(document));
        var content = document.GetObject(new PdfObjectId(8)) as PdfStream;
        var own = new PdfDiagnostics();
        var decoded = content!.Decode(own);
        output.WriteLine(Inv($"{filter} content Decode(own): len={decoded.Length} own={string.Join(",", own.Select(d => d.Code))}"));
        decoded = content.Decode();
        output.WriteLine(Inv($"{filter} content Decode(): len={decoded.Length} doc={Codes(document)}"));
        var five = document.GetObject(new PdfObjectId(5));
        output.WriteLine(Inv($"{filter} obj5: {five?.GetType().Name} {(five is PdfString str ? str.ToText() : "")} doc={Codes(document)}"));
        var report = new PdfValidator().Validate(document);
        output.WriteLine(Inv($"{filter} validator: {string.Join(",", report.Findings.Select(f => f.RuleId))} doc={Codes(document)}"));
    }
}
