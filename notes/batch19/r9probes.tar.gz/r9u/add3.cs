
    [Theory]
    [InlineData("[/ASCIIHexDecode /Foo]", ">")]
    [InlineData("[/ASCIIHexDecode /Foo /Bar]", ">")]
    [InlineData("[/ASCIIHexDecode 5]", ">")]
    public void ZzR9EmptyThenUnknown(string filter, string data)
    {
        output = new Out("empty");
        var file = new HandWrittenFile(version: "1.5");
        var o1 = file.Object(1, "<< /Type /Catalog /Pages 2 0 R >>");
        var o2 = file.Object(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        var o3 = file.Object(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 8 0 R /Resources << >> >>");
        var o8 = file.Object(8, Inv($"<< /Filter {filter} /Length {data.Length} >>\nstream\n{data}\nendstream"));
        var xref = file.Position;
        file.Raw(Inv($"xref\n0 4\n0000000000 65535 f \n{Row(o1)}{Row(o2)}{Row(o3)}8 1\n{Row(o8)}trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"));
        using var document = PdfDocument.Open(file.Bytes);
        var content = (PdfStream)document.GetObject(new PdfObjectId(8))!;
        var own = new PdfDiagnostics();
        var decoded = content.Decode(own);
        output.WriteLine(Inv($"{filter} {data}: len={decoded.Length} own={string.Join(",", own.Select(d => d.Code + ": " + d.Message))}"));
    }
}
