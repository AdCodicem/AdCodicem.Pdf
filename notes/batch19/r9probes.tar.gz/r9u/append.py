import sys

target, addition = sys.argv[1], sys.argv[2]
text = open(target).read().rstrip()
assert text.endswith('}')
text = text[:-1] + open(addition).read()
open(target, 'w').write(text)
print('appended', addition)
