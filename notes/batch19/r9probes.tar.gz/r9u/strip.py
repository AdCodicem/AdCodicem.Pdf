import re
import sys

src, dst = sys.argv[1], sys.argv[2]
text = open(src).read()
start = text.index('    // P-C: the HybridFiles shape')
end = text.index('    // P-B: public decoding paths')
text = text[:start] + text[end:]
open(dst, 'w').write(text)
print('stripped')
