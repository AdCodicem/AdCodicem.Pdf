import sys


def parse(p):
    blocks = {}
    cur = None
    sub = None
    for l in open(p):
        l = l.rstrip('\n')
        if l.startswith('== '):
            sub = l[3:]
            blocks[cur][sub] = []
            continue
        if not l.startswith(' '):
            cur = l.split(':')[0]
            blocks[cur] = {}
            sub = None
            continue
        if sub is not None:
            blocks[cur][sub].append(l)
    return blocks


a = parse(sys.argv[1])
b = parse(sys.argv[2])
for k in sorted(set(a) | set(b)):
    for s in sorted(set(a.get(k, {})) | set(b.get(k, {}))):
        if a.get(k, {}).get(s) != b.get(k, {}).get(s):
            print('###', k, '|', s)
            print('  A:')
            for x in a.get(k, {}).get(s, []):
                print('   ', x[:170])
            print('  B:')
            for x in b.get(k, {}).get(s, []):
                print('   ', x[:170])
