import json
import subprocess
import sys
import time

ROOT = "/home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-2"
OUT = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9u/mut/mutants.jsonl"
READER = ROOT + "/src/AdCodicem.Pdf/IO/PdfFileReader.cs"

ROLL = """            if (attempt.UndecodedReports is { } decoding)
            {
                _diagnostics.RollBackBesideLimits(decoding);
            }"""
MARK = "var decoding = deferred is null && !candidate ? _diagnostics.GetMark() : _diagnostics.GetMarkWithDecodingReports();"
REC = "section.UndecodedReports = candidate ? decoding : null;"
TYPED = """            if (section.TypedXRef)
            {
                return XRefSectionState.Read;
            }

            var decodingChecked"""
INDEX = """        if (Unread(dictionary, PdfName.Index, out var index, out _) is not null)
        {
            return UndecodedFault(stream);
        }"""
SIZE = """            if (Unread(dictionary, PdfName.Size, out var size, out _) is not null)
            {
                return UndecodedFault(stream);
            }"""
HELPER = """        if (stream is null)
        {
            return null;
        }

        // How many rows the data holds says nothing here: only whether it holds any.
        _ = RowsHeldAtMost(stream, 1, out var undecoded);
        return undecoded ? DataUndecoded : null;
    }"""

MUTANTS = [
    ("R01", READER, ROLL, ROLL.replace("                _diagnostics.RollBackBesideLimits(decoding);\n", "")),
    ("R02", READER, ROLL, ROLL.replace("is { } decoding", "is not { } decoding")),
    ("R03", READER, ROLL, ROLL.replace("is { } decoding)", "is { } decoding || true)")),
    ("R04", READER, MARK, MARK.replace(" && !candidate", "")),
    ("R05", READER, MARK, MARK.replace("deferred is null && ", "")),
    ("R06", READER, MARK, MARK.replace("!candidate", "candidate")),
    ("R07", READER, MARK, MARK.replace("deferred is null", "deferred is not null")),
    ("R08", READER, MARK, MARK.replace("deferred is null && !candidate ?", "!(deferred is null && !candidate) ?")),
    ("R09", READER, REC, REC.replace("candidate ?", "!candidate ?")),
    ("R10", READER, "                " + REC + "\n", ""),
    ("R11", READER, REC, "section.UndecodedReports = decoding;"),
    ("R12", READER, REC, "section.UndecodedReports = null;"),
    ("R13", READER, TYPED, TYPED.replace("if (section.TypedXRef)", "if (!section.TypedXRef)")),
    ("R14", READER, TYPED, "            var decodingChecked"),
    ("R15", READER, TYPED, TYPED.replace("if (section.TypedXRef)", "if (true)")),
    ("R16", READER, TYPED, TYPED.replace("return XRefSectionState.Read;", "return default;")),
    ("R17", READER, INDEX, INDEX.replace("return UndecodedFault(stream);", "return null;")),
    ("R18", READER, SIZE, SIZE.replace("return UndecodedFault(stream);", "return null;")),
    ("R19", READER, HELPER, HELPER.replace("if (stream is null)", "if (stream is not null)")),
    ("R20", READER, HELPER, HELPER.replace("        if (stream is null)\n        {\n            return null;\n        }\n\n", "")),
    ("R21", READER, HELPER, HELPER.replace("RowsHeldAtMost(stream, 1,", "RowsHeldAtMost(stream, 0,")),
    ("R22", READER, HELPER, HELPER.replace("RowsHeldAtMost(stream, 1,", "RowsHeldAtMost(stream, 2,")),
    ("R23", READER, HELPER, HELPER.replace("return undecoded ? DataUndecoded", "return !undecoded ? DataUndecoded")),
    ("R24", READER, HELPER, HELPER.replace("return undecoded ? DataUndecoded : null;", "return null;")),
    ("R25", READER, HELPER, HELPER.replace("return undecoded ? DataUndecoded : null;", "return DataUndecoded;")),
]

CLASSES = ["CrossReferenceChainTests", "CrossReferenceRuleTests", "GuardCutValueTests", "FilterTests", "FilterDamageTests",
           "DocumentReaderTests", "HostileInputTests", "WindowEdgeTests", "StreamLengthTests"]


def run(args, timeout):
    start = time.time()
    proc = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return proc.returncode, proc.stdout + proc.stderr, time.time() - start


def main():
    only = set(arg for arg in sys.argv[1:] if not arg.startswith("--"))
    classes = [] if "--whole" in sys.argv else CLASSES
    for key, path, old, new in MUTANTS:
        if only and key not in only:
            continue
        with open(path, encoding="utf-8") as f:
            original = f.read()
        count = original.count(old)
        if count != 1:
            record = {"id": key, "fate": "bad-pattern", "count": count}
            print(json.dumps(record), flush=True)
            with open(OUT, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
            continue
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(original.replace(old, new))
            code, output, took = run(["dotnet", "build", "tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj", "-c", "Release", "-m:2"], 1800)
            if code != 0:
                errors = sorted(set(line.split(": error ")[1][:120] for line in output.splitlines() if ": error " in line))[:3]
                record = {"id": key, "fate": "not-viable", "errors": errors, "build": round(took)}
            else:
                args = ["dotnet", "test", "--project", "tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj", "-c", "Release", "--no-build", "--"]
                for c in classes:
                    args += ["--filter-class", "AdCodicem.Pdf.Tests." + c]
                code, output, took2 = run(args, 3600)
                failed = [line.split(" (")[0] for line in output.splitlines() if line.startswith("failed ")]
                totals = [line.strip() for line in output.splitlines() if "total:" in line or "failed:" in line]
                record = {"id": key, "fate": "killed" if failed else ("survived" if code == 0 else "error"),
                          "failed": len(failed), "first": failed[:6], "totals": totals, "build": round(took), "test": round(took2)}
        finally:
            with open(path, "w", encoding="utf-8") as f:
                f.write(original)
        print(json.dumps(record), flush=True)
        with open(OUT, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")


main()
