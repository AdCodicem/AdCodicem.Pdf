#!/bin/bash
# $1 = repo dir, $2 = output file, rest = class short names
cd "$1" || exit 2
out="$2"; shift 2
export DOTNET_GCHeapHardLimit=0xC0000000
args=()
for c in "$@"; do args+=(--filter-class "AdCodicem.Pdf.Tests.$c"); done
dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- "${args[@]}" > "$out" 2>&1
echo "exit $?" >> "$out"
