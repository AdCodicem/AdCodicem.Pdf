#!/bin/bash
# usage: suite.sh <repo dir> <out file> [extra args...] -- the unit suite, no build, under a heap limit, bounded time
cd "$1" || exit 2
out="$2"; shift 2
export DOTNET_GCHeapHardLimit=0xC0000000
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- "$@" > "$out" 2>&1
echo "exit $?"
