#!/bin/bash
export DOTNET_GCHeapHardLimit=0xC0000000
cd /home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-33 || exit 1
exec dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*Data_is_said_undecoded_only_where*"
