#!/bin/bash
# usage: r9ref-runclass.sh <worktree> <class-filter>...
cd "$1" || exit 1
shift
args=()
for c in "$@"; do args+=(--filter-class "$c"); done
export DOTNET_GCHeapHardLimit=0xC0000000
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- "${args[@]}" 2>&1 | tail -8
