#!/bin/bash
# Copies the core project of each tree with MaxRelocationCandidates set to 1 and 2, and writes a probe project per tree.
set -e
B=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/lot19/r9bat
H=/home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-6
for t in branch main; do
  src="$H"; if [ "$t" = main ]; then src="$B/main"; fi
  for R in 1 2; do
    d="$B/var-$t-R$R"; rm -rf "$d"; mkdir -p "$d/src"
    cp "$src/Directory.Build.props" "$src/Directory.Packages.props" "$src/.editorconfig" "$d/"
    if [ -f "$src/global.json" ]; then cp "$src/global.json" "$d/"; fi
    cp -r "$src/src/AdCodicem.Pdf" "$d/src/"
    rm -rf "$d/src/AdCodicem.Pdf/bin" "$d/src/AdCodicem.Pdf/obj"
    perl -pi -e "s/private const int MaxRelocationCandidates = 32;/private const int MaxRelocationCandidates = $R;/" "$d/src/AdCodicem.Pdf/IO/PdfFileReader.cs"
    grep -c "MaxRelocationCandidates = $R;" "$d/src/AdCodicem.Pdf/IO/PdfFileReader.cs"
  done
done
declare -A REF
REF[branch]="$H/src/AdCodicem.Pdf/AdCodicem.Pdf.csproj"
REF[main]="$B/main/src/AdCodicem.Pdf/AdCodicem.Pdf.csproj"
for t in branch main; do for R in 1 2; do REF[$t-R$R]="$B/var-$t-R$R/src/AdCodicem.Pdf/AdCodicem.Pdf.csproj"; done; done
for t in "${!REF[@]}"; do
  d="$B/probe-$t"; mkdir -p "$d"
  cat > "$d/Probe.csproj" <<EOT
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <NoWarn>\$(NoWarn);CS1591;CA1305</NoWarn>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="../probe-src/*.cs" />
    <ProjectReference Include="${REF[$t]}" />
  </ItemGroup>
</Project>
EOT
done
