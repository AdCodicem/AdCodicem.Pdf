#!/bin/bash
# Builds each probe project, one dotnet process at a time.
B=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/lot19/r9bat
for t in ${@:-branch main branch-R1 branch-R2 main-R1 main-R2}; do
  echo "== $t"
  setsid timeout -k 15 900 dotnet build "$B/probe-$t/Probe.csproj" -c Release -m:2 -v q -nologo > "$B/build-probe-$t.log" 2>&1
  echo "exit=$?"
  tail -3 "$B/build-probe-$t.log"
done
