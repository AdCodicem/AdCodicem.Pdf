using System.Globalization;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.IO.Filters;
using AdCodicem.Pdf.IO.XRef;
using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.Validation.Rules;

/// <summary>
/// <see cref="PdfValidationRuleIds.FileTrailerValueWrong"/>: the values a section's trailer — a classic table's, or a
/// cross-reference stream's dictionary — gives the reader to read the chain are written as the specification asks:
/// direct where it makes them direct, and integers where it makes them integers.
/// </summary>
/// <remarks>
/// <para>
/// A cross-reference stream's <c>/Type</c>, <c>/Index</c>, <c>/Prev</c> and <c>/W</c> are direct, the elements of
/// <c>/Index</c> and <c>/W</c> with them, and so are its <c>/Filter</c> and <c>/DecodeParms</c> (ISO 32000-1, 7.5.8.2).
/// ISO 32000-2 adds, through an erratum the PDF Association approved (pdf-issues #246), its <c>/Length</c> and every
/// element and entry of its <c>/Filter</c> and <c>/DecodeParms</c>: judged in a file that declares PDF 2.0. A classic
/// trailer's <c>/Prev</c> is a direct integer (Table 15); its <c>/XRefStm</c> may be indirect (Table 19). Where Table 5,
/// Table 8, Table 15 or Table 17 make a value an integer, a real with no fractional part is reported.
/// </para>
/// <para>
/// The reader reads such a value all the same, as other readers do — a reference where a section already read places
/// its object, a real with no fractional part as the integer it equals —: a warning (ADR 45). A value it could not read
/// so — a reference no section read before it places, a real with a fractional part — is another fault, the section's
/// (<see cref="PdfValidationRuleIds.XRefSectionMalformed"/>, <see cref="PdfValidationRuleIds.XRefSectionNotFound"/>) or
/// the stream's; a <c>/Size</c> is <see cref="PdfValidationRuleIds.FileSizeWrong"/>'s. Only the sections the reader read
/// are judged.
/// </para>
/// <para>
/// Each trailer is judged as the file wrote it; a reference it holds is followed as any read follows it, through the index
/// the validator had the reader settle on before its first rule — the chain's own, unless a read could still have rebuilt
/// it, in which case it was rebuilt then (#237) —, so that what was read before validating changes nothing. A value the
/// reader does not read is judged as the file wrote it, a reference it holds not followed: following it would read what
/// the reading never did, and could reach a guard it never met (#263). So are a hybrid file's stream's own <c>/Prev</c>,
/// which the reader does not follow, the chain going on through the table's; the <c>/Prev</c> and <c>/XRefStm</c> of a
/// table an <c>/XRefStm</c> names in a stream's place; the elements of a <c>/W</c> past the third; and what of a
/// cross-reference stream's <c>/Filter</c> and <c>/DecodeParms</c> decoding does not read — the parameters of a filter
/// that reads none, past its predictor where it has none, or past the element that ends the chain —, what decoding reads
/// judged as it read it, whatever the cache let go since.
/// </para>
/// </remarks>
internal sealed class TrailerValueWrongRule : IValidationRule
{
    /// <summary>What makes a cross-reference stream's own values direct.</summary>
    private const string Iso1 = "ISO 32000-1 makes it direct (7.5.8.2)";

    /// <summary>What makes, in a file that declares PDF 2.0, the rest of a cross-reference stream's values direct.</summary>
    private const string Iso2 = "ISO 32000-2 makes it direct (7.5.8.2)";

    /// <summary>The entries of a <c>/DecodeParms</c> dictionary that Table 8 makes integers.</summary>
    private static readonly PdfName[] IntegerParameters =
        [PdfName.Predictor, PdfName.Colors, PdfName.BitsPerComponent, PdfName.Columns, PdfName.EarlyChange];

    /// <inheritdoc/>
    public string Id => PdfValidationRuleIds.FileTrailerValueWrong;

    /// <inheritdoc/>
    public PdfValidationSeverity Severity => PdfValidationSeverity.Warning;

    /// <inheritdoc/>
    public void Check(ValidationContext context)
    {
        var sections = context.Structure.Sections;
        var pdf20 = ArlingtonWalk.DeclaredVersion(context.Document) == 20;

        foreach (var section in sections)
        {
            if (section.State is not (XRefSectionState.Read or XRefSectionState.Relocated) || section.Trailer is not { } trailer)
            {
                continue;
            }

            var judge = new Judge(context, this, section);

            if (section.Kind == XRefSectionKind.Stream)
            {
                judge.Value(new What(PdfName.Type), trailer.GetRaw(PdfName.Type), Iso1, integer: null);
                judge.Integers(trailer, PdfName.W);
                judge.Integers(trailer, PdfName.Index);

                // A hybrid file's stream gives a /Prev of its own, which the reader does not follow, the chain going on through
                // the table's (7.5.8.4): judged as the file wrote it, a reference it holds not followed (#263).
                if (IsFollowed(sections, section, PdfName.Prev))
                {
                    judge.Value(new What(PdfName.Prev), trailer.GetRaw(PdfName.Prev), Iso1, "Table 17", resolve: section.NamedBy != "/XRefStm");
                }

                judge.Value(new What(PdfName.Length), trailer.GetRaw(PdfName.Length), pdf20 ? Iso2 : null, "Table 5");

                // What decoding reads, followed as decoding follows it, through the bound on filters the reader read under.
                var reads = new DecodingReads();
                FilterChain.TryFollow(trailer, context.Document.Reader.FilterChainBound, ref reads);
                judge.Decoding(trailer, pdf20, reads);
            }
            else
            {
                // A table an /XRefStm names gives values the reader does not follow either: judged as written (#263).
                var followed = section.NamedBy != "/XRefStm";

                if (IsFollowed(sections, section, PdfName.Prev))
                {
                    judge.Value(new What(PdfName.Prev), trailer.GetRaw(PdfName.Prev), "ISO 32000-1 makes it direct (Table 15)", "Table 15", followed);
                }

                if (IsFollowed(sections, section, PdfName.XRefStm))
                {
                    judge.Value(new What(PdfName.XRefStm), trailer.GetRaw(PdfName.XRefStm), direct: null, "Table 19", followed);
                }
            }
        }
    }

    /// <summary>
    /// Determines whether the <paramref name="key"/> of <paramref name="section"/> named a section the chain found, or none
    /// it looked for: one that names no section is <see cref="PdfValidationRuleIds.XRefSectionNotFound"/>'s to report.
    /// </summary>
    private static bool IsFollowed(IReadOnlyList<XRefSectionRecord> sections, XRefSectionRecord section, PdfName key)
    {
        var naming = FileQuote.Name(key);

        foreach (var other in sections)
        {
            if (other.NamedOffset < 0 && other.NamedFrom == section.Offset && other.NamedBy == naming)
            {
                return false;
            }
        }

        return true;
    }

    /// <summary>Judges the values of one section's trailer, and reports each written as the specification does not allow.</summary>
    private readonly struct Judge(ValidationContext context, IValidationRule rule, XRefSectionRecord section)
    {
        private string Subject => section.Kind == XRefSectionKind.Stream
            ? string.Create(CultureInfo.InvariantCulture, $"The cross-reference stream at offset {section.Offset}")
            : string.Create(CultureInfo.InvariantCulture, $"The trailer of the cross-reference table at offset {section.Offset}");

        /// <summary>
        /// Reports a value written as a reference where <paramref name="direct"/> says the specification makes it direct, or
        /// as a real with no fractional part where <paramref name="integer"/> names the table that makes it an integer — the
        /// value a reference leads to included —, in one finding.
        /// </summary>
        /// <param name="what">The value, as the message names it: <c>its /W</c>, <c>element 1 of its /W</c>.</param>
        /// <param name="value">The value as the file wrote it, or null when there is none.</param>
        /// <param name="direct">What makes the value direct, or null when nothing does.</param>
        /// <param name="integer">The table that makes the value an integer, or null when none does.</param>
        /// <param name="resolve">
        /// Whether a reference the value is written as is followed to judge what it leads to, which a value the reader does
        /// not read is not: following it would read what the reading never did.
        /// </param>
        public void Value(What what, PdfObject? value, string? direct, string? integer, bool resolve = true)
        {
            var reference = direct is not null ? value as PdfReference : null;
            var real = integer is not null && (resolve ? value?.Resolve() : value) is PdfReal written && written.AsInteger() is not null;

            // Past the report's room, the value is counted, its finding not written (#168).
            if ((reference is null && !real) || !context.HasRoomFor(rule))
            {
                return;
            }

            var id = reference is null
                ? string.Empty
                : string.Create(CultureInfo.InvariantCulture, $"the reference {reference.Id.Number} {reference.Id.Generation} R");
            var message = (reference, real) switch
            {
                (not null, true) => $"{Subject} writes {what} as {id}, to a real number: {direct}, and {integer} of ISO 32000-1 an integer.",
                (not null, false) => $"{Subject} writes {what} as {id}, where {direct}.",
                _ => $"{Subject} gives {what} as a real number, where {integer} of ISO 32000-1 asks for an integer.",
            };

            context.Report(
                rule,
                PdfValidationLocation.AtPosition(section.TrailerLocation),
                message,
                reference is null ? "Write the value as an integer." : "Write the value itself in place of the reference.");
        }

        /// <summary>
        /// Reports an array of integers — <c>/W</c>, <c>/Index</c> — written as a reference, and each element written as
        /// one or as a real, the array a reference leads to included.
        /// </summary>
        public void Integers(PdfDictionary trailer, PdfName key)
        {
            var value = trailer.GetRaw(key);
            Value(new What(key), value, Iso1, integer: null);

            if (value?.Resolve() is not PdfArray array)
            {
                return;
            }

            // The reader reads three elements of a /W, the widths of three fields, and every element of an /Index.
            for (var i = 0; i < array.Count; i++)
            {
                Value(new What(key, i), array[i], Iso1, "Table 17", key != PdfName.W || i < 3);
            }
        }

        /// <summary>
        /// Reports a cross-reference stream's <c>/Filter</c> or <c>/DecodeParms</c> written as a reference, and, in a file
        /// that declares PDF 2.0, each element and entry written as one; and the integers of Table 8 a <c>/DecodeParms</c>
        /// gives written as reals — not a dictionary a <c>/Filter</c> gives, which is no decode parameters, Table 8 not
        /// governing it, and ends decoding unread. A reference among them is followed where decoding follows it, as
        /// <paramref name="reads"/> says.
        /// </summary>
        public void Decoding(PdfDictionary trailer, bool pdf20, DecodingReads reads)
        {
            var inside = pdf20 ? Iso2 : null;

            foreach (var key in (ReadOnlySpan<PdfName>)[PdfName.Filter, PdfName.DecodeParms])
            {
                var value = trailer.GetRaw(key);
                var decodeParms = key == PdfName.DecodeParms;
                Value(new What(key), value, Iso1, integer: null);

                switch (reads.Resolve(value))
                {
                    case PdfArray array:
                        for (var i = 0; i < array.Count; i++)
                        {
                            var what = new What(key, i);
                            Value(what, array[i], inside, integer: null);

                            if (reads.Resolve(array[i]) is PdfDictionary parameters)
                            {
                                Parameters(parameters, what, inside, reads, decodeParms);
                            }
                        }

                        break;

                    case PdfDictionary parameters:
                        Parameters(parameters, new What(key), inside, reads, decodeParms);
                        break;
                }
            }
        }

        private void Parameters(PdfDictionary parameters, What where, string? inside, DecodingReads reads, bool decodeParms)
        {
            foreach (var (key, value) in parameters)
            {
                var integer = decodeParms && Array.IndexOf(IntegerParameters, key) >= 0 ? "Table 8" : null;
                Value(where.Entry(key), value, inside, integer, reads.Follows(value));
            }
        }
    }

    /// <summary>
    /// A value of a section's trailer, as a finding's message names it: <c>its /W</c>, <c>element 1 of its /W</c>,
    /// <c>/Columns of element 0 of its /DecodeParms</c>. It is written only for a finding the report has room for, not for
    /// each value judged: an <c>/Index</c> may hold as many elements as its trailer has room for (#168).
    /// </summary>
    /// <param name="key">The trailer's key that holds the value.</param>
    /// <param name="element">The element of the array <paramref name="key"/> holds that the value is, or -1 for none.</param>
    /// <param name="entry">The key the value has in the dictionary named so far, or null for none.</param>
    private readonly struct What(PdfName key, int element = -1, PdfName? entry = null)
    {
        /// <summary>Names the value <paramref name="name"/> gives in the dictionary this names.</summary>
        public What Entry(PdfName name) => new(key, element, name);

        /// <inheritdoc/>
        public override string ToString()
        {
            var its = "its " + FileQuote.Name(key);
            var where = element < 0 ? its : string.Create(CultureInfo.InvariantCulture, $"element {element} of {its}");
            return entry is null ? where : FileQuote.Name(entry) + " of " + where;
        }
    }

    /// <summary>
    /// The references among a cross-reference stream's <c>/Filter</c> and <c>/DecodeParms</c> that decoding follows, each as
    /// the file wrote it, which <see cref="FilterChain.TryFollow"/> gives in the order decoding reads them, with what it led
    /// to (#263). The rule walks what they led to, not what a second read of them gives: the cache may have let an object go
    /// since, and its references read again are other instances, which decoding did not follow.
    /// </summary>
    private readonly struct DecodingReads() : IFilterValueReader
    {
        private readonly Dictionary<PdfObject, PdfObject?> _followed = new(ReferenceEqualityComparer.Instance);

        /// <summary>Determines whether <paramref name="written"/> is no reference, or one decoding follows.</summary>
        public bool Follows(PdfObject? written) => written is not PdfReference || _followed.ContainsKey(written);

        /// <summary>Gives what <paramref name="written"/> led to where decoding follows it, and itself otherwise.</summary>
        public PdfObject? Resolve(PdfObject? written) =>
            written is PdfReference && _followed.TryGetValue(written, out var value) ? value : written;

        /// <inheritdoc/>
        public bool TryRead(PdfName key, PdfObject? written, bool entry, out PdfObject? value)
        {
            value = written?.Resolve();

            if (written is PdfReference)
            {
                _followed[written] = value;
            }

            return true;
        }
    }
}
