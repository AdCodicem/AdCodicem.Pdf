namespace AdCodicem.Pdf.Diagnostics;

/// <summary>
/// The diagnostic codes the library emits. They are part of the public contract: renaming one is a
/// breaking change, because callers filter and assert on them.
/// </summary>
public static class PdfDiagnosticCodes
{
    /// <summary>
    /// The file has no <c>%PDF-</c> header within the bytes the reader searches at its start (ISO 32000-1, 7.5.2): the
    /// file was read all the same, its offsets counted from its first byte.
    /// </summary>
    public const string HeaderMissing = "header.missing";

    /// <summary>The cross-reference table was rebuilt by scanning the whole file.</summary>
    public const string XRefRebuilt = "xref.rebuilt";

    /// <summary>
    /// An object, or a cross-reference section the chain names, was not at the offset the file claimed, and was
    /// found nearby.
    /// </summary>
    public const string XRefOffsetAdjusted = "xref.offset-adjusted";

    /// <summary>
    /// A cross-reference section the chain names, through <c>/Prev</c> or <c>/XRefStm</c>, is neither where
    /// it is named nor near it — nothing there reads as a section, which <see cref="XRefSectionUnreadable"/> reports
    /// otherwise —, lies outside the file, or is named by a value that is not an offset. The objects only it
    /// indexes are missing from the index, which is rebuilt by scanning the file when one of them is asked for. The report
    /// is placed at the offset the section was named at, or, when that offset lies outside the file or the value is not an
    /// offset, at the section whose trailer named it.
    /// </summary>
    public const string XRefSectionMissing = "xref.section-missing";

    /// <summary>
    /// A cross-reference section the chain names, through <c>/Prev</c> or <c>/XRefStm</c>, is where it is named but
    /// cannot be read — a stray token among a table's rows or in place of its trailer, a subsection numbering objects
    /// past 2,147,483,647, a cross-reference stream whose <c>/W</c>, <c>/Index</c>, <c>/Size</c> or data cannot give
    /// rows, or whose <c>/Length</c> no section read before it places and whose data no <c>endstream</c> ends before the
    /// next object or the end of the file —, and nothing near it can be read in its place. A value that leads to an object
    /// one of the reader's limits cut is the limit's: the chain ends there, and nothing is reported of the section. The rows read before the
    /// fault, if any, were kept; the objects only the rest indexes are missing from the index, which is rebuilt by
    /// scanning the file when one of them is asked for. The report is placed at the section, the fault in its message.
    /// </summary>
    public const string XRefSectionUnreadable = "xref.section-unreadable";

    /// <summary>
    /// The chain of previous cross-reference sections looped back on itself: a <c>/Prev</c> or <c>/XRefStm</c> names an
    /// offset the chain has already reached, read or, outside the file, named. The report is placed at the section the
    /// chain looped back to, or at the section whose trailer named it when that offset lies outside the file.
    /// </summary>
    public const string XRefChainCycle = "xref.chain-cycle";

    /// <summary>
    /// An object's cross-reference entry places it outside the file. The report carries no position, since the index
    /// does not keep where the entry was read; its message gives the offset. A section named outside the file is
    /// <see cref="XRefSectionMissing"/>'s, or the rebuild's when <c>startxref</c> names it.
    /// </summary>
    public const string XRefEntryOutOfRange = "xref.entry-out-of-range";

    /// <summary>
    /// A stream's <c>/Length</c> is not where its data ends: its <c>endstream</c> lies elsewhere and ends the data, the
    /// <c>/Length</c> gives no length the reader can take and the <c>endstream</c> ends the data, or no <c>endstream</c>
    /// follows the declared length — none before the next object or the end of the file, or none looked for once the
    /// document's searches read as much of the file as they may — and that length is kept, or the data runs to the next
    /// object, or, taken without a search, to the end of the file. A <c>/Length</c> that leads to an object one of the reader's limits cut, or left out of the index, is not
    /// judged: the limit's report says why.
    /// </summary>
    public const string StreamLengthInvalid = "stream.length-invalid";

    /// <summary>
    /// A stream has no <c>endstream</c> before the next object or the end of the file: its object's <c>endobj</c> ends its
    /// data — after its declared length, or where the object ends —, or its data runs to the end of the file. Data taken
    /// without a search, the document's searches having read as much of the file as they may, is
    /// <see cref="StreamLengthInvalid"/>'s, whose <c>endstream</c> no search said is missing.
    /// </summary>
    public const string StreamTruncated = "stream.truncated";

    /// <summary>
    /// An object stream's dictionary names an object the stream holds — as its <c>/Type</c>, <c>/Length</c>, <c>/N</c>,
    /// <c>/First</c>, a filter or one of its parameters —, which cannot be read before the stream is: the stream was
    /// decoded without it.
    /// </summary>
    public const string StreamSelfReference = "stream.self-reference";

    /// <summary>
    /// An object is in the object stream its entry names, at another index than the entry gives: the object stream's
    /// header lists it elsewhere, and it was read from there. The report is placed where the object stream's data
    /// starts, and names the object, the object stream and both indexes.
    /// </summary>
    public const string ObjectStreamMemberMoved = "object-stream.member-moved";

    /// <summary>
    /// An object an object stream holds is written as a stream — a dictionary followed by <c>stream</c> —, or holds one,
    /// which an object stream cannot hold (ISO 32000-1 7.5.7): it reads as null, and its data is not read. The report is
    /// placed where the object stream's data starts, and names the object, the object stream and the byte the object
    /// starts at; it is made once for each object and each definition of its object stream.
    /// </summary>
    public const string ObjectStreamMemberStream = "object-stream.member-stream";

    /// <summary>
    /// What an object stream — a stream an entry of the index names as one — says of itself cannot be believed: it is not
    /// of <c>/Type /ObjStm</c>, its <c>/N</c> is absent or no non-negative integer, or, when it declares objects, its
    /// <c>/First</c> is, or lies past its decoded data, or its header ends or breaks before listing as many objects as its <c>/N</c> declares —
    /// a pair that is not two integers, that gives a number no object can have or an offset no member can start at, whose
    /// offset is not past the one before it, or whose member would start at or past the end of the decoded data, unless a
    /// guard cut it. The header is read as far as it goes, whatever its <c>/N</c> claims: the objects listed before the
    /// fault, if any, are read; the others cannot be read from it. The report is placed where the object stream's data
    /// starts, and names the object stream and its fault.
    /// </summary>
    public const string ObjectStreamUnreadable = "object-stream.unreadable";

    /// <summary>
    /// A token stood where the syntax does not allow it: where a value or a dictionary key was expected, after a key
    /// that has no value, or closing an array with a dictionary's end. It was read as null, skipped, or it ended what
    /// it stood in.
    /// </summary>
    public const string SyntaxUnexpectedToken = "syntax.unexpected-token";

    /// <summary>
    /// An object ended before it was whole: the file, or an object stream's decoded data, ended in the middle of it — a value
    /// missing, or an array, a dictionary or a string it opened never closed —, or an <c>endobj</c> stood where a value or a
    /// key should be, inside an array or a dictionary it opened. What was read is kept: a string takes the bytes to the end of
    /// the data, and an <c>endobj</c> ends every container it finds open: the object's own, or, when the object lost it too, the
    /// next object's, the container then taking that object. An object an object stream holds is read to the next one's
    /// start, the last to the end of the decoded data: running into either, it is cut short there, and the message says
    /// which.
    /// Reported once, for the innermost construct left open, where it opens — where the value would start, when none is open;
    /// past the depth the reader follows, the container it skipped, which holds what it did not follow —, the constructs
    /// around it counted in the message; inside an object an object stream holds, where the stream's data
    /// starts, the member and the byte in the message. The edge of a window the reader grows is no end of the data, and a cut
    /// a guard made is the guard's: an object an object stream holds read past
    /// <see cref="Documents.PdfReaderLimits.MaxObjectLength"/> is <see cref="LimitObject"/>'s.
    /// </summary>
    public const string SyntaxTruncatedObject = "syntax.truncated-object";

    /// <summary>
    /// Nesting exceeded the depth the reader follows, or the stack the thread leaves the reader, or the validator's walk
    /// of what an object stream's decoding reads: what lies past it was skipped, or read as null.
    /// </summary>
    public const string SyntaxDepthExceeded = "syntax.depth-exceeded";

    /// <summary>
    /// A number is beyond what a real can hold — its magnitude rounds past the largest a double holds, about 1.8 × 10^308
    /// —: it was read as null, so a dictionary holds no entry for its key. The report quotes the number, and is placed
    /// where it starts, or, for a number inside an object an object stream holds, where the stream's data starts, the
    /// member and the byte in its message. An integer past the range of a <see langword="long"/> is no fault of its own:
    /// it reads as a real, the one nearest to it.
    /// </summary>
    public const string SyntaxNumberOutOfRange = "syntax.number-out-of-range";

    /// <summary>
    /// A hexadecimal string holds bytes that are neither hexadecimal digits nor white space, the only bytes ISO 32000-1
    /// (7.3.4.3) lets it hold — a <c>%</c> among them, which is no comment there —: they were skipped, as pdf.js and pdfium
    /// skip them, where PDFBox stops at the first, MuPDF and poppler read each as the digit 0, and qpdf and pypdf lose the
    /// string. Reported once for each string, where
    /// its first such byte lies, how many there are in the message; inside an object an object stream holds, where the
    /// stream's data starts, the member and the byte in the message.
    /// </summary>
    public const string SyntaxHexStringInvalid = "syntax.hex-string-invalid";

    /// <summary>
    /// A name holds a number sign that two hexadecimal digits do not follow: it was kept as the byte it is, as PDF 1.1 read
    /// it and most readers still do, where ISO 32000-1 (7.3.5) has a writer write <c>#23</c>. Reported once for each name,
    /// where its first such number sign lies, the name read quoted in the message; inside an object an object stream holds,
    /// where the stream's data starts, the member and the byte in the message. A <c>#00</c> is no such fault: it is an
    /// escape, of a byte no name may hold, which the validator reports.
    /// </summary>
    public const string SyntaxNameEscapeInvalid = "syntax.name-escape-invalid";

    /// <summary>
    /// A dictionary gives a key more than once, which ISO 32000-1 (7.3.7) forbids: keys compare as they read, so a key written
    /// with <c>#xx</c> escapes repeats the one written without. The last value given is kept, and a null given last removes
    /// the key, as qpdf, pdf.js, PDFBox, MuPDF and pdfium read it; a key given with no value, before <c>&gt;&gt;</c> or
    /// <c>endobj</c>, is one given null, and a value a guard's cut leaves short removes nothing. Reported for each key given
    /// again, where it is given, unless a window's edge reaches the key itself, the
    /// key quoted in the message; inside an object an object stream holds, where the stream's data starts, the member and the
    /// byte in the message.
    /// </summary>
    public const string SyntaxKeyRepeated = "syntax.key-repeated";

    /// <summary>
    /// Rebuilding the index met more than one definition of an object number: the file was updated, or copies an
    /// object. It is reported once for each rebuild, as information with no position: how many definitions met a number
    /// already found, the first ten of those numbers, and which definition was kept — the last written directly in the
    /// file, or, for a number written only inside object streams, the first listed in the object stream read first.
    /// </summary>
    public const string ObjectRedefined = "object.redefined";

    /// <summary>
    /// The trailer's <c>/Root</c> did not lead to a document catalog, and the reader found the catalog among the
    /// file's objects: among those the file indexes when its index is sound, in a rebuilt index otherwise.
    /// </summary>
    public const string TrailerRootRecovered = "trailer.root-recovered";

    /// <summary>
    /// A filter's data is not what the filter says. Flate data that nothing could decode was left as the filters before it
    /// left it, and decoding stopped there; data that decoded in part — a Flate stream that lost its tail or turned corrupt,
    /// an LZW stream that uses a code it has not defined, ASCII85 data a <c>~</c> ends that something other than
    /// <c>&gt;</c> follows — was kept as far as it went; data that may have decoded wrong — a byte passed over that encodes
    /// nothing, an ASCII85 group past four bytes or of a single digit, data that ends inside a group, a pair, a run or an
    /// LZW code without its end marker — is a warning too; data read despite a fault that lost nothing, such as a missing
    /// zlib header or checksum, an end marker missing after a whole unit or ending on a <c>~</c>, or the <c>&lt;~</c>
    /// PostScript writes, is reported as a repair. The message says which; for a Flate stream turned corrupt, a byte that
    /// encodes nothing, an ASCII85 group past four bytes and a <c>~</c> something other than <c>&gt;</c> follows, it says at
    /// which byte of the filter's data the first lies.
    /// </summary>
    public const string FilterFailed = "filter.failed";

    /// <summary>
    /// A Flate stream's data decoded to its end, but the zlib checksum that follows it disagrees with what it
    /// decoded to: all of it was kept, as other readers keep it, and some of it may be wrong.
    /// </summary>
    public const string FilterChecksumMismatch = "filter.checksum-mismatch";

    /// <summary>
    /// A filter named by the file is not supported, and decoding stopped there: the data is what the filters before
    /// it decoded, or the stream's own when it is the first. A <c>/Filter</c> entry that is neither a name nor an
    /// array leaves the data as the stream holds it.
    /// </summary>
    public const string FilterUnsupported = "filter.unsupported";

    /// <summary>
    /// A filter of a stream decodes to more than <see cref="Documents.PdfReaderLimits.MaxDecodedStreamLength"/>, or the
    /// filters before the last pass along more than it together, and decoding stopped there: the data comes back as the
    /// filters after the cut decode what was kept within the bound. Like every <c>limit.*</c> code, the guard is the
    /// reader's, not damage in the file.
    /// </summary>
    public const string LimitDecodedStream = "limit.decoded-stream";

    /// <summary>
    /// A stream's encoded data runs past <see cref="Documents.PdfReaderLimits.MaxStreamLength"/>, and was read up to it:
    /// what lies within it is decoded as data the reader cut, and handed back as it is where decoding hands its data back
    /// undecoded. Reported once for each stream in the document's diagnostics, when its data is first read, and in
    /// diagnostics of your own each time you decode it. Like every <c>limit.*</c> code, the guard is the reader's, not
    /// damage in the file.
    /// </summary>
    public const string LimitStreamLength = "limit.stream-length";

    /// <summary>
    /// An object is longer than <see cref="Documents.PdfReaderLimits.MaxObjectLength"/>, and only the part
    /// within it was parsed. An object an object stream holds is bounded alike, and reported once for each definition of
    /// its object stream, where that stream's data starts, the object, the object stream and the byte the object starts at
    /// in the message.
    /// </summary>
    public const string LimitObject = "limit.object";

    /// <summary>
    /// A classic cross-reference section is longer than
    /// <see cref="Documents.PdfReaderLimits.MaxXRefSectionLength"/>, and only the entries within it were read.
    /// </summary>
    public const string LimitXRefSectionLength = "limit.xref-section-length";

    /// <summary>
    /// The chain of cross-reference sections is longer than
    /// <see cref="Documents.PdfReaderLimits.MaxXRefSectionCount"/>, and the older sections were not read.
    /// </summary>
    public const string LimitXRefSectionCount = "limit.xref-section-count";

    /// <summary>
    /// A trailer, or a cross-reference stream's dictionary, is longer than
    /// <see cref="Documents.PdfReaderLimits.MaxTrailerLength"/>, and only the part within it was parsed.
    /// </summary>
    public const string LimitTrailer = "limit.trailer";

    /// <summary>
    /// The index holds <see cref="Documents.PdfReaderLimits.MaxIndexEntries"/> object numbers, and took no more: the
    /// objects past them, in the order the reader met them, were not indexed, and read as null.
    /// </summary>
    public const string LimitIndexEntries = "limit.index-entries";

    /// <summary>
    /// A stream's <c>/Filter</c> array names more filters than <see cref="Documents.PdfReaderLimits.MaxFilterChainLength"/>,
    /// and decoding stopped before the first past them: the data is what the filters within the bound decoded.
    /// </summary>
    public const string LimitFilterChain = "limit.filter-chain";
}
