using System.Globalization;
using AdCodicem.Pdf.IO.XRef;

namespace AdCodicem.Pdf.Validation.Rules;

/// <summary>
/// <see cref="PdfValidationRuleIds.XRefChainLoop"/>: the chain of cross-reference sections ends, each <c>/Prev</c>
/// naming an older section.
/// </summary>
/// <remarks>
/// A <c>/Prev</c> that names a section the chain has already read makes a loop a careless reader never leaves. The
/// reader stops there, but the section the chain should have gone on to is unknown: what only it indexed is found,
/// if at all, by rebuilding the index, after which the reader cannot vouch that it reads what was written — an
/// error (ADR 45), as a section that cannot be found is.
/// </remarks>
internal sealed class ChainLoopRule : IValidationRule
{
    /// <inheritdoc/>
    public string Id => PdfValidationRuleIds.XRefChainLoop;

    /// <inheritdoc/>
    public PdfValidationSeverity Severity => PdfValidationSeverity.Error;

    /// <inheritdoc/>
    public void Check(ValidationContext context)
    {
        var structure = context.Structure;

        if (structure.LoopOffset < 0)
        {
            return;
        }

        var namedFrom = structure.LoopNamedFrom;
        var written = context.Document.Reader.DescribeOffset(structure.LoopWrittenOffset);

        // The chain may loop through an offset where it read no section: a section there it could not read, though it declares
        // itself one; or an /XRefStm and a /Prev naming the same offset that holds nothing, in the file, past its end, or past
        // what a long holds once the header's offset is added (#125). It loops all the same, as the reader says.
        var what = structure.LoopTarget switch
        {
            XRefLoopTarget.Read => "a section the chain has already read",
            XRefLoopTarget.Reached => "a section the chain has already reached and could not read",
            _ => structure.LoopOffset < context.Source.Length
                ? "which the chain has already named"
                : "outside the file, which the chain has already named",
        };

        context.Report(
            this,
            namedFrom >= 0 ? PdfValidationLocation.AtPosition(namedFrom) : default,
            namedFrom >= 0
                ? string.Create(
                    CultureInfo.InvariantCulture,
                    $"The {structure.LoopNamedBy} of the cross-reference section at offset {namedFrom} names offset {written}, {what}: the chain loops.")
                : string.Create(
                    CultureInfo.InvariantCulture,
                    $"A {structure.LoopNamedBy} names offset {written}, {what}: the chain loops."),
            "Point the /Prev at the section before it, or remove it from the oldest section.");
    }
}
