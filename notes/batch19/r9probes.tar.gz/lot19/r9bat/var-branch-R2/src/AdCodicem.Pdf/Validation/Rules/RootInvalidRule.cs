using System.Globalization;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.Validation.Rules;

/// <summary>
/// <see cref="PdfValidationRuleIds.FileRootInvalid"/>: the trailer's <c>/Root</c> is a reference to the document
/// catalog.
/// </summary>
/// <remarks>
/// <para>
/// ISO 32000-1 (Table 15) requires it, as an indirect reference. Without it a reader has no way into the document:
/// qpdf finds no catalog, others look for an object typed <c>/Catalog</c> — which the reader does too, among the
/// objects the index holds before rebuilding anything. The catalog it finds is its choice, not the file's: an error
/// (ADR 45).
/// </para>
/// <para>
/// It judges the trailer the file's chain gave, merged across its sections as readers merge them, and <c>/Root</c>
/// as it was before the reader looked for a catalog. A trailer that could not be read at all, or an index the chain
/// did not give, is another rule's to report, and a catalog one of the reader's limits left out of the index
/// <see cref="PdfValidationRuleIds.XRefCheckedInPart"/>'s. A catalog one of them cut is not judged: what it lacks may lie
/// past the cut, and the reader's report names the limit. Nor is a <c>/Root</c> the trailers lack where one of them kept a
/// trailer from being read whole: it may lie past the cut, or in an older trailer the chain stopped short of.
/// </para>
/// </remarks>
internal sealed class RootInvalidRule : IValidationRule
{
    /// <inheritdoc/>
    public string Id => PdfValidationRuleIds.FileRootInvalid;

    /// <inheritdoc/>
    public PdfValidationSeverity Severity => PdfValidationSeverity.Error;

    /// <inheritdoc/>
    public void Check(ValidationContext context)
    {
        var structure = context.Structure;

        if (!structure.ChainRead || !structure.TrailerRead || structure.RootUsable)
        {
            return;
        }

        // A catalog a guard left out of the index as the document opened is unknown, not lacking: xref.checked-in-part says
        // the index was stopped short of it, and raising the guard reads it. So is a /Root the trailers lack where a guard
        // kept one of them from being read whole: it may lie past the cut, or in an older trailer the chain stopped short
        // of. It stays so once a rebuild finds it, as the trailer judged is the one the document opened with, and /Root as
        // it resolved then.
        if (structure.RootHiddenByGuard)
        {
            return;
        }

        // Nor is a catalog a guard cut as the document opened: what it lacks may lie past the cut — its /Type, its /Pages —,
        // and the reader took it as read. The reader's report names the guard — limit.object, or limit.decoded-stream for a
        // catalog in an object stream, cut through or left unread past the cut data (#259) —, and raising it reads the
        // catalog whole.
        if (structure.RootCutByGuard)
        {
            return;
        }

        // The reader's, not the structure's: a rebuild run after the document opened may have taken another.
        var catalog = context.Document.Reader.CatalogFoundAs;
        var found = catalog > 0
            ? string.Create(CultureInfo.InvariantCulture, $" The reader took object {catalog}, which is one, for the catalog.")
            : " No object of the file is a catalog.";
        var trailer = structure.Sections.Count > 0
            ? PdfValidationLocation.AtPosition(structure.Sections[0].TrailerLocation)
            : default;

        // An entry whose value is null is one the dictionary does not have (ISO 32000-1, 7.3.7).
        switch (structure.RootAsWritten)
        {
            case null or PdfNull:
                Report(context, trailer, "The trailer has no /Root." + found);
                break;

            case PdfReference reference:
                Report(
                    context,
                    PdfValidationLocation.OfObject(reference.Id),
                    string.Create(
                        CultureInfo.InvariantCulture,
                        $"The trailer's /Root names object {reference.Id.Number} {reference.Id.Generation}, which {Describe(structure.RootResolved)}.{found}"));
                break;

            default:
                Report(
                    context,
                    trailer,
                    $"The trailer's /Root is {Kind(structure.RootAsWritten)}, not a reference to the document catalog.{found}");
                break;
        }
    }

    private void Report(ValidationContext context, PdfValidationLocation location, string message) =>
        context.Report(this, location, message, "Point /Root at the document catalog, as an indirect reference.");

    private static string Describe(PdfObject? resolved) => resolved switch
    {
        null or PdfNull => "the file does not hold",
        PdfStream => "is a stream, not a document catalog",
        PdfDictionary dictionary when dictionary.GetName(PdfName.Type) is { } type =>
            $"is a dictionary of /Type {FileQuote.Name(type)}, not a document catalog",
        PdfDictionary => "is a dictionary that is not a document catalog",
        _ => $"is {Kind(resolved)}, not a document catalog",
    };

    private static string Kind(PdfObject value) => value switch
    {
        PdfInteger or PdfReal => "a number",
        PdfName => "a name",
        PdfString => "a string",
        PdfArray => "an array",
        PdfDictionary => "a dictionary written in the trailer",
        PdfStream => "a stream written in the trailer",
        PdfBoolean => "a boolean",
        _ => "not an object",
    };
}
