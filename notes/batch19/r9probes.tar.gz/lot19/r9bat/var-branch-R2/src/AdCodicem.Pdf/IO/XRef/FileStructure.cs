using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.IO.XRef;

/// <summary>
/// What the reader saw of a file's own structure while opening it: its header, what <c>startxref</c> gave, each
/// cross-reference section the chain named and what became of it, and the trailer's <c>/Root</c> and <c>/Size</c>
/// before the reader did anything about them.
/// </summary>
/// <remarks>
/// <para>
/// The validation rules judge the file as it was written, not as the reader repaired it, and this is where they
/// find it. It is filled while the document opens and never changes afterwards — a rebuild run later, set off by a read
/// or before a validation's first rule, keeps what it finds to the reader —, so two validations of the same document
/// see the same structure, whatever was read in between.
/// </para>
/// <para>
/// It costs a record per section of the chain — at most <see cref="Documents.PdfReaderLimits.MaxXRefSectionCount"/>
/// of them, and one more for each <c>/XRefStm</c> — and nothing per object.
/// </para>
/// </remarks>
internal sealed class FileStructure
{
    private readonly List<XRefSectionRecord> _sections = [];

    /// <summary>Gets where <c>%PDF-</c> starts, or -1 when the reader did not find it where it looks.</summary>
    public long HeaderPosition { get; set; } = -1;

    /// <summary>
    /// Gets what follows <c>%PDF-</c> up to the white space, the comment or the end of the file that ends it, a
    /// character for each byte as written — empty when nothing does —, or null when there is no header. The reader's
    /// search window bounds it.
    /// </summary>
    public string? HeaderVersion { get; set; }

    /// <summary>
    /// Gets whether the reader's search window ends before what follows <c>%PDF-</c> does: <see cref="HeaderVersion"/>
    /// then holds its start, and the whole is at least that long.
    /// </summary>
    public bool HeaderVersionCut { get; set; }

    /// <summary>Gets where the last <c>startxref</c> keyword of the file's tail starts, or -1 when there is none.</summary>
    public long StartXRefPosition { get; set; } = -1;

    /// <summary>Gets the offset <c>startxref</c> gives, as written, or -1 when it gives none.</summary>
    public long StartXRef { get; set; } = -1;

    /// <summary>
    /// Gets the sections the chain named, newest first, each <c>/XRefStm</c> after the table that named it — one that names
    /// what the chain had reached, or what its table's <c>/Prev</c> names too, recorded as named again
    /// (<see cref="XRefSectionState.NamedAgain"/>), so that each table's naming is there (#156).
    /// </summary>
    public IReadOnlyList<XRefSectionRecord> Sections => _sections;

    /// <summary>
    /// Gets a value indicating whether the chain gave an index — its first section read —, so that the index the
    /// document started from is the file's own.
    /// </summary>
    public bool ChainRead { get; set; }

    /// <summary>
    /// Gets where the chain named again, through <see cref="LoopNamedBy"/>, what it had already reached; -1 when it never
    /// did.
    /// </summary>
    /// <remarks>
    /// A position, the header's offset added; one whose sum a long cannot hold reads as <see cref="long.MaxValue"/>, past
    /// the end of the file (#125). <see cref="LoopWrittenOffset"/> is the offset as written. Where a section the chain
    /// reached starts, past the white space and comments the offset names, whether the chain named that offset before or
    /// not (#188); the offset itself where it reaches no such section.
    /// </remarks>
    public long LoopOffset { get; set; } = -1;

    /// <summary>Gets the offset the chain looped back through, as the file writes it, counted from its header; -1 when it never did.</summary>
    public long LoopWrittenOffset { get; set; } = -1;

    /// <summary>
    /// Gets what the chain had found at <see cref="LoopOffset"/>: a section it read there, one it reached there and could
    /// not read, or only an offset it named; <see cref="XRefLoopTarget.Named"/> when it never looped.
    /// </summary>
    public XRefLoopTarget LoopTarget { get; set; }

    /// <summary>Gets what named the section the chain looped back to.</summary>
    public string? LoopNamedBy { get; set; }

    /// <summary>Gets where what looped back is written: the section whose trailer names the section again.</summary>
    public long LoopNamedFrom { get; set; } = -1;

    /// <summary>
    /// Gets where the chain went on when <see cref="Documents.PdfReaderLimits.MaxXRefSectionCount"/> stopped it,
    /// or -1 when it was read to its end.
    /// </summary>
    /// <remarks>
    /// A position, the header's offset added; one whose sum a long cannot hold reads as <see cref="long.MaxValue"/>, past
    /// the end of the file (#125). <see cref="ChainCutWrittenOffset"/> is the offset as written.
    /// </remarks>
    public long ChainCutAt { get; set; } = -1;

    /// <summary>
    /// Gets a value indicating whether one of the reader's guards kept it from reading a trailer of the chain whole: one it
    /// cut, an older section's it left unread — the chain stopped at a guard short of its end —, or that of a section read
    /// where it may have been moved, which is not looked for past rows a guard cut. A key the trailers lack may lie there.
    /// </summary>
    public bool TrailersHiddenByGuard { get; set; }

    /// <summary>Gets the offset the chain went on at when it was cut, as the file writes it, counted from its header; -1 when it was not cut.</summary>
    public long ChainCutWrittenOffset { get; set; } = -1;

    /// <summary>Gets where the section whose <c>/Prev</c> names <see cref="ChainCutAt"/> starts; -1 when the chain was not cut.</summary>
    public long ChainCutNamedFrom { get; set; } = -1;

    /// <summary>
    /// Gets where the index first had no room for an object number as the document opened,
    /// <see cref="Documents.PdfReaderLimits.MaxIndexEntries"/> reached — the section whose row it was, the header or object
    /// stream a rebuild run at opening found it in, or the chain's newest section for an entry the chain gave that such a
    /// rebuild could not keep, since the index it keeps no longer knows which section gave it —, or -1 while it had room for
    /// every number it met. Where a rebuild run later filled it is the reader's (<see cref="PdfFileReader.IndexFullAt"/>).
    /// </summary>
    public long IndexFullAt { get; set; } = -1;

    /// <summary>Gets a value indicating whether the trailer the chain gave holds any entry at all.</summary>
    public bool TrailerRead { get; set; }

    /// <summary>Gets the trailer's <c>/Root</c> as the chain gave it, before the reader looked for a catalog of its own.</summary>
    public PdfObject? RootAsWritten { get; set; }

    /// <summary>Gets what <see cref="RootAsWritten"/> resolved to when the document opened, or null when it is no reference.</summary>
    public PdfObject? RootResolved { get; set; }

    /// <summary>Gets a value indicating whether <see cref="RootAsWritten"/> led to a catalog when the document opened.</summary>
    public bool RootUsable { get; set; } = true;

    /// <summary>
    /// Gets a value indicating whether <see cref="RootAsWritten"/>, which led to no catalog, names an object a guard left out
    /// of the index when the document opened, or is none where a guard kept a trailer from being read whole
    /// (<see cref="TrailersHiddenByGuard"/>): whether the file holds it was unknown then, whatever a rebuild run since found.
    /// </summary>
    public bool RootHiddenByGuard { get; set; }

    /// <summary>
    /// Gets a value indicating whether <see cref="RootAsWritten"/>, which led to no catalog, names an object a guard cut when
    /// the document opened, or is a catalog written in a trailer a guard cut: what it would have said past the cut was unknown
    /// then, and the reader took it for the catalog as read, looking for no other.
    /// </summary>
    public bool RootCutByGuard { get; set; }

    /// <summary>
    /// Gets the object the reader found to be the catalog as the document opened, <c>/Root</c> leading to none; 0 when it
    /// did not look, or found none. The one a rebuild run later took is the reader's (<see cref="PdfFileReader.CatalogFoundAs"/>).
    /// </summary>
    public int CatalogFoundAs { get; set; }

    /// <summary>Gets the trailer's <c>/Size</c> as the chain gave it.</summary>
    public PdfObject? SizeAsWritten { get; set; }

    /// <summary>Records a section the chain named.</summary>
    public void Add(XRefSectionRecord section) => _sections.Add(section);

    /// <summary>
    /// Puts <paramref name="replacement"/> where <paramref name="section"/>, a section the chain named, is recorded: an
    /// <c>/XRefStm</c>'s reading in the stream's place that becomes the naming of what its table's <c>/Prev</c> read (#156).
    /// </summary>
    /// <param name="section">A record <see cref="Add"/> recorded.</param>
    /// <param name="replacement">The record that takes its place, in the chain's order.</param>
    public void Replace(XRefSectionRecord section, XRefSectionRecord replacement) => _sections[_sections.LastIndexOf(section)] = replacement;
}
