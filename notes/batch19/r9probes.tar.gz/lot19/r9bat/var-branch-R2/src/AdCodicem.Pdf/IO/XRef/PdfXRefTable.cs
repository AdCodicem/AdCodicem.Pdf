using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.IO.XRef;

/// <summary>
/// The index of a document: where every object is, and the trailer that names the roots.
/// </summary>
/// <remarks>
/// <para>
/// The reader keeps one for the whole document. Once it has changed the one the chain gave — an object found away
/// from its entry, or a rebuild —, it also keeps a copy of that one as it was, which
/// <see cref="PdfFileReader.ChainIndex"/> serves.
/// </para>
/// <para>
/// The entries lie in two arrays, in the order the table first recorded their numbers, which is the order it
/// enumerates them in, as the map it replaced did. A number finds its entry through a third array, one slot for each
/// number below its length — where numbers run as most files write them, from 0 up with few gaps —, and past it through
/// a map that hashes numbers through the process's seed (<see cref="SeededComparer"/>): no lookup walks a chain a file
/// chose, whatever numbers it writes (#155). The slots stretch to a number only while they stay no longer than twice the
/// entries the table holds or has made room for, and <see cref="DenseSlack"/> more: the numbers of a file that spreads
/// them out go to the map, which gives back the room of those the slots come to reach once most of it is idle.
/// </para>
/// <para>
/// An entry holds 36 bytes, and its slot 4 more. A section makes room for the rows it holds before they are read, for no
/// more objects than the newest section's <c>/Size</c> numbers (<see cref="Reserve"/>), and the slots are made once for
/// that room: 40 bytes an object numbered in order, allocated and kept, so a hundred thousand objects hold 4 MB whatever
/// the objects themselves weigh. Room left to grow — by a rebuild, or rows written shorter than 19 bytes — doubles,
/// keeping 40 to 80 bytes an object and allocating 80 to 160 on the way, by where the count falls against its steps.
/// Room is made for rows that add no entry too, and the last step for every object the newest <c>/Size</c> numbers, four
/// times what the index held at most: such room holds 40 bytes an entry, about 160 an object where the size numbers four
/// times the objects the sections give. A table of one-row subsections, whose headers make room as rows do, keeps about
/// 1.5 times these figures. A number in the map keeps 20 to about 42 bytes beside its entry and the slot the room makes
/// anyway, by where the map's count falls against .NET's prime steps, so that an object numbered apart from the rest
/// keeps, measured, about 60 to 85 bytes in subsections of ten rows or more, up to about 96 in subsections of two, and 80
/// to 110 in a table of one-row subsections, the more the wider the numbers; a rebuild that grows the table over such
/// numbers allocates about 110 to 220 an object. A
/// copy holds its entries exactly, and slots up to the highest number the slots hold, no more than the table it copies.
/// </para>
/// </remarks>
internal sealed class PdfXRefTable : IEnumerable<KeyValuePair<int, XRefEntry>>
{
    /// <summary>
    /// How many slots past twice the entries the table keeps for numbers it lacks: enough for a small file's free numbers
    /// and gaps, and no more than 4 KB whatever a file numbers.
    /// </summary>
    internal const int DenseSlack = 1024;

    /// <summary>The numbers, in the order the table first recorded them.</summary>
    private int[] _numbers = [];

    /// <summary>The entries, where their numbers lie in <see cref="_numbers"/>.</summary>
    private XRefEntry[] _entries = [];

    private int _count;

    /// <summary>For each number below its length, one more than where its entry lies; 0 for a number the table lacks.</summary>
    private int[] _slots = [];

    /// <summary>Where the entry of each number past <see cref="_slots"/> lies; null until one is.</summary>
    private Dictionary<int, int>? _beyond;

    /// <summary>Changes as a number is added or the table cleared, ending an enumeration begun before.</summary>
    private int _version;

    /// <summary>
    /// How many enumerations of <see cref="Numbers"/> under way read <see cref="_numbers"/> as it is now: while one is, the
    /// table cleared records its numbers in a new array rather than over those it reads (#167). Any array that takes its
    /// place is lent to none.
    /// </summary>
    private int _numbersLent;

    /// <summary>
    /// The offsets of the entries in use written directly, sorted the first time <see cref="FirstOffsetAfter"/> is asked
    /// and kept up to date from then on; null until then, so that an index nothing searches costs nothing more.
    /// </summary>
    private SortedOffsets? _offsets;

    /// <summary>Gets the trailer, merged across every section of the chain.</summary>
    /// <remarks>
    /// What the reader merges into it or sets in it once the document is open, it does in a copy made first
    /// (<see cref="RenewTrailer"/>), which takes its place as a rebuild, or an attempt to finish one, begins, and takes in
    /// what the rebuild merges and sets while it still reads the file. A trailer taken before a rebuild, or after it, is
    /// therefore never changed by the reader (#167); one a caller's own <see cref="PdfFileSource"/> takes from inside the
    /// rebuilding read is that copy, and may still gain the trailers and the <c>/Root</c> the rebuild merges and sets after.
    /// </remarks>
    public PdfDictionary Trailer { get; private set; } = new();

    /// <summary>Gets the number of indexed objects.</summary>
    public int Count => _count;

    /// <summary>Gets how many entries the table holds room for.</summary>
    public int Capacity => _entries.Length;

    /// <summary>Gets how many numbers, from 0, the table finds an entry for in a slot.</summary>
    internal int SlotCount => _slots.Length;

    /// <summary>Gets how many numbers the table finds an entry for in its map, past the slots.</summary>
    internal int MapCount => _beyond?.Count ?? 0;

    /// <summary>Gets how many numbers the map holds room for, past the slots.</summary>
    internal int MapCapacity => _beyond?.EnsureCapacity(0) ?? 0;

    /// <summary>
    /// Gets the indexed object numbers, in the order the table first recorded them: those it held when the enumeration
    /// began, at its first step, whatever is added or cleared meanwhile (#167).
    /// </summary>
    /// <remarks>
    /// Nothing is copied. A number added meanwhile is written past those the enumeration began with, or into a larger
    /// array once the room is full; and a table cleared while an enumeration is under way records its numbers from then
    /// on in an array of its own (<see cref="Clear"/>). An enumeration left before its end and never disposed counts as
    /// under way until the next clearing.
    /// </remarks>
    public IEnumerable<int> Numbers
    {
        get
        {
            var numbers = _numbers;
            var count = _count;
            _numbersLent++;

            try
            {
                for (var at = 0; at < count; at++)
                {
                    yield return numbers[at];
                }
            }
            finally
            {
                // An array the table has stopped recording into is not one it counts as lent.
                if (ReferenceEquals(numbers, _numbers))
                {
                    _numbersLent--;
                }
            }
        }
    }

    /// <summary>Looks up an object number.</summary>
    public bool TryGet(int number, out XRefEntry entry)
    {
        var at = Find(number);

        if (at < 0)
        {
            entry = default;
            return false;
        }

        entry = _entries[at];
        return true;
    }

    /// <summary>
    /// Records an entry unless the object number is already known.
    /// </summary>
    /// <remarks>
    /// Sections are read newest first, so the first definition seen is the current one. This is what makes
    /// incremental updates work: later sections in the chain describe older states of the document.
    /// </remarks>
    public bool TryAdd(int number, XRefEntry entry)
    {
        if (Find(number) >= 0)
        {
            return false;
        }

        Add(number, entry);
        Track(entry);
        return true;
    }

    /// <summary>Records an entry, replacing any existing one, which keeps its place in the order.</summary>
    public void Set(int number, XRefEntry entry)
    {
        var at = Find(number);

        if (at < 0)
        {
            Add(number, entry);
        }
        else
        {
            _entries[at] = entry;
        }

        Track(entry);
    }

    /// <summary>
    /// Makes room for <paramref name="count"/> entries more than the table holds, and no more than
    /// <paramref name="most"/> in all, before they are recorded.
    /// </summary>
    /// <remarks>
    /// A count is a section's claim, which the caller bounds by the rows the section holds and by the entries the index
    /// may take. Room is never added by less than the table holds already, but for the last step to the most asked: a
    /// chain of many sections, each making room for its own rows, would otherwise copy the entries at each one. The most
    /// asked is the newest <c>/Size</c>, or one past the highest number read where the sections number past it, until an
    /// older section numbers past the newer ones: from then on it bounds nothing, so that a chain whose older sections each
    /// number one further doubles the table rather than growing it by one entry at each.
    /// </remarks>
    public void Reserve(int count, int most)
    {
        var capacity = Capacity;
        var needed = (int)Math.Min((long)_count + count, most);

        if (needed > capacity)
        {
            Resize((int)Math.Min(Math.Max(needed, 2L * capacity), most));
        }
    }

    /// <summary>Removes every entry.</summary>
    /// <remarks>
    /// The numbers an enumeration of <see cref="Numbers"/> under way reads are left where they are: the table then records
    /// its numbers from now on in a new array, as long as the one it leaves, 4 bytes an entry of room (#167). Otherwise it
    /// keeps its arrays, and allocates nothing.
    /// </remarks>
    public void Clear()
    {
        if (_numbersLent > 0)
        {
            _numbers = new int[_numbers.Length];
            _numbersLent = 0;
        }

        Array.Clear(_slots);
        _beyond = null;
        _count = 0;
        _version++;
        _offsets = null;
    }

    /// <summary>Removes every entry, and lets go of the room they took, for a table nothing will read again.</summary>
    /// <remarks>
    /// An enumeration of <see cref="Numbers"/> under way keeps reading the array it began with, which the table lets go of
    /// rather than clear: none is made for it.
    /// </remarks>
    public void Release()
    {
        _numbersLent = 0;
        Clear();
        _numbers = [];
        _entries = [];
        _slots = [];
    }

    /// <summary>Copies the indexed object numbers, in the order the table first recorded them.</summary>
    public int[] CopyNumbers() => _numbers.AsSpan(0, _count).ToArray();

    /// <summary>Enumerates the numbers and their entries in the order the table first recorded the numbers.</summary>
    /// <remarks>A number added, or the table cleared, ends the enumeration at its next step.</remarks>
    public Enumerator GetEnumerator() => new(this);

    IEnumerator<KeyValuePair<int, XRefEntry>> IEnumerable<KeyValuePair<int, XRefEntry>>.GetEnumerator() => GetEnumerator();

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();

    /// <summary>Gets where the entry of <paramref name="number"/> lies, or -1.</summary>
    private int Find(int number)
    {
        if ((uint)number < (uint)_slots.Length)
        {
            return _slots[number] - 1;
        }

        return _beyond is not null && _beyond.TryGetValue(number, out var at) ? at : -1;
    }

    /// <summary>Records a number the table lacks, last in the order.</summary>
    private void Add(int number, XRefEntry entry)
    {
        if (_count == _entries.Length)
        {
            Resize(Math.Max(4, (int)Math.Min(2L * _count, Array.MaxLength)));
        }

        var at = _count++;
        _numbers[at] = number;
        _entries[at] = entry;
        _version++;

        if ((uint)number >= (uint)_slots.Length)
        {
            Stretch(number);
        }

        if ((uint)number < (uint)_slots.Length)
        {
            _slots[number] = at + 1;
        }
        else
        {
            (_beyond ??= new Dictionary<int, int>(SeededComparer.Instance)).Add(number, at);
        }
    }

    /// <summary>
    /// Stretches the slots to <paramref name="number"/> while they stay within twice the entries the table holds or has
    /// made room for, and <see cref="DenseSlack"/>: to the room made at once, doubling at least, and moves into them the
    /// numbers of the map they reach.
    /// </summary>
    /// <remarks>
    /// The room counts as entries: a section that made room for its rows has its slots made once, for as many, rather than
    /// doubled up to them, and a chain whose newest sections number the highest objects, as updates do, makes room for the
    /// rows it is about to read before their numbers come down to the slots. Room follows the rows the sections hold
    /// (<see cref="Reserve"/>), but for the last step, which the newest <c>/Size</c> takes to four times what the index
    /// held at most: the slots follow it, 4 bytes for each entry of room, and reach up to twice it where a number lies
    /// that far, within the 40 bytes an entry and 4 more a number the guard lets the index take.
    /// </remarks>
    private void Stretch(int number)
    {
        var most = (2L * Math.Max(_count, _entries.Length)) + DenseSlack;

        if (number < 0 || number >= most)
        {
            return;
        }

        var length = (int)Math.Min(Math.Max(Math.Max(number + 1L, 2L * _slots.Length), _entries.Length), most);
        var slots = new int[length];
        _slots.CopyTo(slots, 0);
        _slots = slots;

        if (_beyond is null)
        {
            return;
        }

        // A number the map holds that the slots now reach moves into them: below their length, a number is in its slot
        // or not in the table. Removing it as the map is enumerated is allowed, and leaves the rest where they are.
        foreach (var (held, at) in _beyond)
        {
            if ((uint)held < (uint)length)
            {
                slots[held] = at + 1;
                _beyond.Remove(held);
            }
        }

        if (_beyond.Count == 0)
        {
            _beyond = null;
        }
        else if (_beyond.Count < _beyond.EnsureCapacity(0) / 4)
        {
            // Removed in place, the numbers that moved leave their room in the map: once they are most of it, the map gives
            // it back, copying those that stay once rather than at every stretch.
            _beyond.TrimExcess();
        }
    }

    /// <summary>Makes room for <paramref name="capacity"/> entries, keeping those held.</summary>
    /// <remarks>
    /// The numbers go into a new array: one an enumeration of <see cref="Numbers"/> under way reads is left as it is, and
    /// the new one is lent to none.
    /// </remarks>
    private void Resize(int capacity)
    {
        Array.Resize(ref _numbers, capacity);
        Array.Resize(ref _entries, capacity);
        _numbersLent = 0;
    }

    /// <summary>
    /// Gets the smallest offset an entry in use written directly — not in an object stream — gives that is greater
    /// than <paramref name="offset"/>, or <see cref="long.MaxValue"/> when none is. A row's negative offset places
    /// nothing, and is left out (#125).
    /// </summary>
    /// <remarks>
    /// The offsets are sorted the first time this is asked, and entries recorded since are sorted in as they come, so
    /// that each lookup costs a logarithm of the index rather than a pass over it. An entry replaced keeps the offset
    /// it gave among them: the answer is always an offset some entry of the table gave, if not the entry it holds now.
    /// </remarks>
    public long FirstOffsetAfter(long offset)
    {
        if (_offsets is null)
        {
            // One array the size of the offsets, sorted in place: sorting a large index costs what it keeps.
            var count = 0;

            var entries = _entries.AsSpan(0, _count);

            foreach (var entry in entries)
            {
                count += PlacesInFile(entry) ? 1 : 0;
            }

            var offsets = new long[count];
            var index = 0;

            foreach (var entry in entries)
            {
                if (PlacesInFile(entry))
                {
                    offsets[index++] = entry.Offset;
                }
            }

            _offsets = new SortedOffsets(offsets);
        }

        return _offsets.FirstAfter(offset);
    }

    /// <summary>
    /// Lets go of the offsets sorted so far, with any an entry replaced since gave: the next lookup, if one comes, sorts
    /// those the entries give then.
    /// </summary>
    public void ForgetSortedOffsets() => _offsets = null;

    /// <summary>Adds the offset an entry gives to the sorted ones, once they are kept.</summary>
    private void Track(XRefEntry entry)
    {
        if (PlacesInFile(entry))
        {
            _offsets?.Add(entry.Offset);
        }
    }

    /// <summary>
    /// Determines whether <paramref name="entry"/> places its object at an offset of the file: a regular one does, but for a
    /// row's negative offset, which lies before the file's start whatever precedes the header (#125); one the reader found
    /// does, before the header though it be.
    /// </summary>
    private static bool PlacesInFile(XRefEntry entry) =>
        entry.Kind == XRefEntryKind.Regular && (entry.Offset >= 0 || entry.FoundByReader);

    /// <summary>
    /// Copies the entries, and not the trailer, into a table of their own, sized to hold them: slots up to the highest
    /// number the slots hold, and the map's numbers in a map of their own.
    /// </summary>
    public PdfXRefTable CopyEntries()
    {
        var highest = -1;

        foreach (var number in _numbers.AsSpan(0, _count))
        {
            if ((uint)number < (uint)_slots.Length && number > highest)
            {
                highest = number;
            }
        }

        return new()
        {
            _numbers = _numbers.AsSpan(0, _count).ToArray(),
            _entries = _entries.AsSpan(0, _count).ToArray(),
            _count = _count,
            _slots = _slots.AsSpan(0, highest + 1).ToArray(),
            _beyond = _beyond is null ? null : new Dictionary<int, int>(_beyond, SeededComparer.Instance),
        };
    }

    /// <summary>
    /// Replaces the trailer by a copy of it, holding the same keys, values and order, which what the reader merges or sets
    /// from then on goes into: a trailer taken before is left as it was (#167).
    /// </summary>
    /// <remarks>
    /// A rebuild calls it as it begins, and again as each attempt to finish it begins when loads in flight left it
    /// unfinished, before either changes the trailer: each allocates a copy the size of what the reader holds already,
    /// so that no bound is added (ADR 34).
    /// </remarks>
    public void RenewTrailer()
    {
        var renewed = new PdfDictionary(Trailer.Count);

        foreach (var (key, value) in Trailer)
        {
            renewed.TryAdd(key, value);
        }

        Trailer = renewed;
    }

    /// <summary>Copies trailer keys that are not already known.</summary>
    public void MergeTrailer(PdfDictionary trailer)
    {
        foreach (var (key, value) in trailer)
        {
            if (!Trailer.ContainsKey(key))
            {
                Trailer.Set(key, value);
            }
        }
    }

    /// <summary>Enumerates a table's numbers and entries in the order it first recorded the numbers.</summary>
    internal struct Enumerator : IEnumerator<KeyValuePair<int, XRefEntry>>
    {
        private readonly PdfXRefTable _table;
        private readonly int _version;
        private int _at;

        internal Enumerator(PdfXRefTable table)
        {
            _table = table;
            _version = table._version;
            _at = -1;
        }

        /// <inheritdoc/>
        public readonly KeyValuePair<int, XRefEntry> Current => new(_table._numbers[_at], _table._entries[_at]);

        readonly object System.Collections.IEnumerator.Current => Current;

        /// <inheritdoc/>
        /// <exception cref="InvalidOperationException">A number was added, or the table cleared, since it began.</exception>
        public bool MoveNext()
        {
            if (_version != _table._version)
            {
                throw new InvalidOperationException("The index changed while it was enumerated.");
            }

            return ++_at < _table._count;
        }

        /// <inheritdoc/>
        public void Reset() => _at = -1;

        /// <inheritdoc/>
        public readonly void Dispose()
        {
        }
    }
}
