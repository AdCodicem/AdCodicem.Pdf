using AdCodicem.Pdf.Documents;

namespace AdCodicem.Pdf.Validation;

/// <summary>
/// Validates documents against a profile, and says what is wrong with them — separately from whether they
/// could be read at all.
/// </summary>
/// <remarks>
/// <para>
/// A validator holds no state beyond its options, so one instance serves any number of threads and can be
/// registered as a singleton. A <see cref="PdfDocument"/>, on the other hand, belongs to one thread at a time,
/// validation included.
/// </para>
/// <para>
/// Validation reads through the document lazily, once it has settled the index as the next paragraph says, and within
/// the document's reader limits: what its rules resolve joins the document's cache — the cross-reference rules read each
/// object stream, and the objects its decoding keys lead through, outside it, where the file's own index places them, or,
/// for the objects written as a stream that only an index the reader rebuilt places, where that index places their
/// stream —, and what the reader notices on the way joins <see cref="PdfDocument.Diagnostics"/>. Opening the document with
/// raised limits lets it check more.
/// </para>
/// <para>
/// Before its first rule, it rebuilds the document's index when a read could still set off that rebuild — the index is
/// incomplete through damage, or an entry places its object where neither its offset nor the 512 bytes either side of it
/// hold its header —, as reading that object would. No rule then reads part of the document before a rebuild and part
/// after it, and two validations of the same document give the same report, whatever the caller read before them (#237).
/// Five things change that: the caller changing the document between them; a rebuild that reaches a guard of a document
/// opened with <see cref="PdfReaderOptions.ThrowOnLimit"/>, which throws once, in the first validation, the index
/// rebuilt whole — a later validation throws only where its rules read what the guard cut or left out, as any read
/// does —; and three files crafted for it. In one, where a damaged stream's data ends depends on which stream was read
/// first (#138). In another, a load lies past the reader's deepest nesting, which the reader cuts there, or serves from
/// its cache when a read before kept the object, so that what was read before decides what that load gives (#163); on a
/// thread with little stack, the reader's stack probe cuts sooner, even with nothing read first, and so does the probe the
/// walks of the object streams make before each level they go down, which the document reports (#312), so the report can
/// also depend on the thread. In the last, an object stream's decoding reads a value — its
/// <c>/Type</c>, <c>/N</c>, <c>/First</c>, <c>/Filter</c> or <c>/DecodeParms</c> — held by a stream that lies on a loop,
/// or the stream lies on a loop itself, and what the reader serves of that value depends on which stream of the loop it
/// decoded first (#313).
/// </para>
/// </remarks>
public sealed class PdfValidator
{
    /// <summary>Initializes a validator.</summary>
    /// <param name="options">How to validate; <see cref="PdfValidatorOptions.Default"/> when null.</param>
    public PdfValidator(PdfValidatorOptions? options = null) => Options = options ?? PdfValidatorOptions.Default;

    /// <summary>Gets how this validator validates.</summary>
    public PdfValidatorOptions Options { get; }

    /// <summary>Validates a document against the profile of <see cref="Options"/>.</summary>
    /// <param name="document">A document the caller opened, and keeps: it is left open.</param>
    /// <returns>What the profile found, which is empty for a sound document.</returns>
    /// <remarks>
    /// A document the reader could open is reported on, never refused: what is wrong with it is what the report
    /// is for.
    /// </remarks>
    /// <exception cref="ArgumentNullException"><paramref name="document"/> is null.</exception>
    /// <exception cref="ObjectDisposedException"><paramref name="document"/> was disposed.</exception>
    /// <exception cref="Diagnostics.PdfLimitExceededException">
    /// Validation reached one of the document's reader limits — in a rule, or in the rebuild it runs before the first —, and
    /// the document was opened with <see cref="PdfReaderOptions.ThrowOnLimit"/>. Without it, a rule reports at most that
    /// what the reader cut was not checked whole.
    /// </exception>
    public PdfValidationReport Validate(PdfDocument document)
    {
        ArgumentNullException.ThrowIfNull(document);
        document.ThrowIfDisposed();

        // A rebuild a read could still set off runs now, before the first rule: every rule then reads the document as it
        // stays, whatever was read before this validation and whatever the rules read (#237).
        document.Reader.SettleIndex();

        var profile = Options.Profile;
        var context = new ValidationContext(document, Options.FindingCapacity);

        for (var index = 0; index < profile.Rules.Count; index++)
        {
            profile.Rules[index].Check(context);
        }

        return context.ToReport(profile);
    }
}
