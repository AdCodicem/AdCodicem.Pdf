using System.Collections.ObjectModel;
using System.Globalization;

namespace AdCodicem.Pdf.Validation;

/// <summary>What a validation profile found in a document: the findings in the order they were found, and
/// how many there were of each severity.</summary>
/// <remarks>
/// <para>
/// The report is bounded: it keeps at most <see cref="PdfValidatorOptions.FindingCapacity"/> findings, so a
/// hostile file with a fault in every object cannot make it grow without limit. The counts by severity, and
/// <see cref="Contains"/>, cover every finding, kept or not; <see cref="SuppressedCount"/> says how many were
/// not kept. What builds it is bounded alike: the validator writes no finding past those the report can keep — it
/// counts them —, so that a lower capacity also makes validating a hostile file cheaper, and the report is the same
/// whatever the capacity, but for the findings it keeps (#168). A count past what an <see langword="int"/> holds stays at
/// <see cref="int.MaxValue"/>, <see cref="SuppressedCount"/> included.
/// </para>
/// <para>
/// Two validations of the same document under the same profile give the same report: rules run in the
/// profile's order and report in the order they find, and nothing in a report depends on the time or on the
/// machine.
/// </para>
/// </remarks>
public sealed class PdfValidationReport
{
    private readonly HashSet<string> _ruleIds;

    internal PdfValidationReport(
        ValidationProfile profile,
        List<PdfValidationFinding> findings,
        HashSet<string> ruleIds,
        int errorCount,
        int warningCount,
        int informationCount,
        int suppressedCount)
    {
        ProfileName = profile.Name;
        ProfileVersion = profile.Version;
        Findings = new ReadOnlyCollection<PdfValidationFinding>(findings);
        _ruleIds = ruleIds;
        ErrorCount = errorCount;
        WarningCount = warningCount;
        InformationCount = informationCount;
        SuppressedCount = suppressedCount;
    }

    /// <summary>Gets the name of the profile the document was validated against, such as <c>structural</c>.</summary>
    public string ProfileName { get; }

    /// <summary>Gets the version of that profile.</summary>
    public int ProfileVersion { get; }

    /// <summary>Gets the findings kept, in the order they were found.</summary>
    public IReadOnlyList<PdfValidationFinding> Findings { get; }

    /// <summary>Gets the number of error findings, kept or not.</summary>
    public int ErrorCount { get; }

    /// <summary>Gets the number of warning findings, kept or not.</summary>
    public int WarningCount { get; }

    /// <summary>Gets the number of information findings, kept or not.</summary>
    public int InformationCount { get; }

    /// <summary>Gets the number of findings not kept because <see cref="PdfValidatorOptions.FindingCapacity"/> was reached.</summary>
    public int SuppressedCount { get; }

    /// <summary>
    /// Gets a value indicating whether any finding is an error: the reader cannot vouch that it reads the document
    /// as it was written.
    /// </summary>
    public bool HasErrors => ErrorCount > 0;

    /// <summary>Gets a value indicating whether any finding is a warning.</summary>
    public bool HasWarnings => WarningCount > 0;

    /// <summary>Determines whether a rule reported anything, whether or not its findings were kept.</summary>
    /// <param name="ruleId">One of <see cref="PdfValidationRuleIds"/>.</param>
    public bool Contains(string ruleId)
    {
        ArgumentNullException.ThrowIfNull(ruleId);
        return _ruleIds.Contains(ruleId);
    }

    /// <inheritdoc/>
    public override string ToString() => string.Create(
        CultureInfo.InvariantCulture,
        $"{ProfileName} {ProfileVersion}: errors {ErrorCount}, warnings {WarningCount}, information {InformationCount}");
}
