using System.Globalization;
using System.Text;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.Validation;

/// <summary>
/// The document's page tree, walked once from the catalog's <c>/Pages</c>: how many pages it lists, where each page
/// lies, and what is wrong with its structure.
/// </summary>
/// <remarks>
/// <para>
/// Pages are counted as the tree lists them, the way qpdf walks it: a kid that is null, names an object the file
/// lacks, or is neither a page nor a node takes the place of a page, one with nothing on it; a node or a page listed
/// twice counts each time it is listed; a kid that loops back to a node above it counts for nothing. A node is a
/// dictionary with a <c>/Kids</c> array or of <c>/Type /Pages</c>; any other dictionary the tree lists is a page. A count
/// past what a <see langword="long"/> holds stays at its greatest, and no <c>/Count</c> is judged past it.
/// </para>
/// <para>
/// The walk is iterative and visits each indirect node, and each array of kids that is an object of its own, once, so it
/// keeps a frame per node on its current path and a few bytes per object it met: nothing is sized by what the file
/// declares. An array of kids is no node: one a node's <c>/Kids</c> names above it loops, one walked already is counted
/// again, and a kid naming one is a kid that is neither a page nor a node. It resolves the tree's nodes and pages
/// through the document, and reads no content. What it cannot judge because the reader could not produce an object —
/// an object stream an encryption hides, an entry that leads nowhere — it leaves to the rules that report those, and
/// says the walk is partial.
/// </para>
/// <para>
/// A frame keeps of its node the <c>/Count</c> it gives, read when the node is entered, and the array of kids the parse
/// made, never the node: what a node holds beside them is the reader's to keep, so that a path of nodes each carrying a
/// large value holds what the reader's cache holds, however deep (#201). The arrays of kids along the path are held, some
/// 40 bytes a kid: a path of nodes that each list many kids holds them all, in proportion to the file (#311). A kid written
/// in an array rather than referred to, which only a file that breaks ISO 32000-1 (7.7.3.2) writes, each such kid
/// reported, is held with its array until its node is left. Reading a node again for each kid instead would read a node of
/// many kids again every few dozen of them once the cache let go of it: a time that grows with the square of its kids.
/// </para>
/// <para>
/// Nor is anything kept of the faults it finds past the room the report has: it is made with that room, writes of each
/// kind of fault the first it finds up to it, and counts the rest, which the report could not keep (#168). A node of a
/// million invalid kids costs it a count. What a finding names — a kid's path, <c>/Kids[12]</c>, its node, what it leads
/// to — is written for a finding only; what a message says that the walk counts, as the pages a node listed again counts
/// again, is counted whether the finding is written or not.
/// </para>
/// <para>
/// Nothing is judged of what is written in an object one of the reader's limits cut, as the Arlington walk leaves it:
/// neither what it lacks — that may lie past the cut — nor what it holds, the value at the cut being perhaps cut itself.
/// A node so cut is taken to give what the pages below it inherit; its <c>/Count</c> is not judged, nor the value of those
/// above it — a missing one still is, and the array of kids of its own the node names, read whole, is counted as any
/// other where listed again —, and the walk is partial; the references its <c>/Kids</c> holds, as read, are walked, each
/// page or node judged as any other, and the values after its last reference, dictionary or stream are not counted, being
/// perhaps what the cut left of a reference.
/// A catalog so cut leaves the walk partial too: its <c>/Pages</c> may lie past the cut.
/// </para>
/// <para>
/// A node or a page written inside another object rather than as an object of its own is named by where it is
/// written, as the Arlington walk and the object graph name such a value: by its path from that object, <c>the page
/// object under /Kids[1] of page tree node 2</c>, and located at that object.
/// </para>
/// <para>
/// M02 counts pages this way, and M06's page API is to materialize the pages it counts.
/// </para>
/// </remarks>
internal sealed class PageTreeWalk
{
    private readonly PdfFileReader _reader;
    private readonly List<Frame> _stack = [];
    private readonly HashSet<int> _visited = new(SeededComparer.Instance);
    private readonly HashSet<int> _onPath = new(SeededComparer.Instance);
    private readonly Dictionary<int, long> _pagesBelow = new(SeededComparer.Instance);

    /// <summary>The nodes and pages, by number, below which the pages could not be counted with confidence.</summary>
    private readonly HashSet<int> _uncountable = new(SeededComparer.Instance);

    /// <summary>
    /// The arrays of kids that are objects of their own the walk has walked, by number: kept apart from the nodes and
    /// pages, which a kid names, so that a kid naming an array is no node walked, and an array a kid named is still walked.
    /// </summary>
    private readonly HashSet<int> _arraysWalked = new(SeededComparer.Instance);

    /// <summary>The arrays of kids of their own being walked on the current path.</summary>
    private readonly HashSet<int> _arraysOnPath = new(SeededComparer.Instance);

    /// <summary>How many pages lie below each array of kids of its own walked, by number.</summary>
    private readonly Dictionary<int, long> _pagesBelowArray = new(SeededComparer.Instance);

    /// <summary>The arrays of kids of their own below which the pages could not be counted with confidence.</summary>
    private readonly HashSet<int> _uncountableArrays = new(SeededComparer.Instance);

    /// <summary>
    /// The pages first listed past the greatest page index, as a tree listing nodes again may list them: kept apart, being
    /// at no index.
    /// </summary>
    private readonly HashSet<int> _pagesPastIndexes = new(SeededComparer.Instance);
    private long _pages;

    /// <summary>
    /// Whether the pages counted ran past what a <see langword="long"/> holds: a tree listing nodes again lists 2^63 pages
    /// with 63 levels, each naming the next twice. The count stays at its greatest, and no node left since is judged. An
    /// internal bound, no guard (ADR 34): a valid tree lists each page once, each an object of its own, and a file holds
    /// fewer than 2^31 objects, so no valid file counts more pages than an <see langword="int"/> holds, let alone a
    /// <see langword="long"/>. Only a tree listing nodes again reaches it, and its count saturates rather than wraps (#167).
    /// </summary>
    private bool _overflowed;

    /// <summary>What a node is called in the findings.</summary>
    private const string NodeKind = "page tree node";

    /// <summary>What a page is called in the findings.</summary>
    private const string PageKind = "page object";

    private PageTreeWalk(PdfFileReader reader, int room)
    {
        _reader = reader;
        Cycles = new(room);
        RepeatedNodes = new(room);
        NodesWithoutKids = new(room);
        InvalidKids = new(room);
        CountMismatches = new(room);
        ParentFaults = new(room);
        MediaBoxFaults = new(room);
        ResourcesMissing = new(room);
    }

    /// <summary>Gets the kids that loop back to the node listing them or to a node above it.</summary>
    public ProbeFindings Cycles { get; }

    /// <summary>Gets the kids that name a node or a page the tree lists elsewhere.</summary>
    public ProbeFindings RepeatedNodes { get; }

    /// <summary>Gets the nodes that have no <c>/Kids</c> array.</summary>
    public ProbeFindings NodesWithoutKids { get; }

    /// <summary>Gets the kids that are neither a page nor a node the tree can read, or that are not referred to.</summary>
    public ProbeFindings InvalidKids { get; }

    /// <summary>Gets the nodes whose <c>/Count</c> is missing or is not the number of pages below them.</summary>
    public ProbeFindings CountMismatches { get; }

    /// <summary>Gets the nodes and pages whose <c>/Parent</c> is missing or is not the node listing them, and a root that has one.</summary>
    public ProbeFindings ParentFaults { get; }

    /// <summary>Gets the pages without a media box, and the media boxes that are no rectangle.</summary>
    public ProbeFindings MediaBoxFaults { get; }

    /// <summary>Gets the pages without resources, their own or inherited.</summary>
    public ProbeFindings ResourcesMissing { get; }

    /// <summary>Gets how many pages the tree lists, each null or missing kid counted as a page.</summary>
    public int PageCount => (int)Math.Min(_pages, int.MaxValue);

    /// <summary>
    /// Gets a value indicating whether part of the tree could not be read for the reader's own reasons: its root, or a
    /// kid, the index holds in use and the reader could not produce; or a node, a page, an array of kids or the catalog
    /// one of the reader's limits cut.
    /// </summary>
    public bool Partial { get; private set; }

    /// <summary>Gets the object numbers of the tree's nodes.</summary>
    public HashSet<int> Nodes { get; } = new(SeededComparer.Instance);

    /// <summary>Gets the object numbers of the arrays of kids the walk read that are objects of their own.</summary>
    public HashSet<int> KidsArrays { get; } = new(SeededComparer.Instance);

    /// <summary>
    /// Gets the object numbers of the nodes one of the reader's limits cut: the walk judged nothing of what they hold, the
    /// kids written in them included.
    /// </summary>
    public HashSet<int> CutNodes { get; } = new(SeededComparer.Instance);

    /// <summary>
    /// Determines whether the walk judged the kids written in object <paramref name="number"/>'s <c>/Kids</c>: a node it
    /// read whole. Another rule judges the references to nothing written in a node a limit cut.
    /// </summary>
    public bool JudgedKidsOf(int number) => Nodes.Contains(number) && !CutNodes.Contains(number);

    /// <summary>
    /// Gets the number of the object a root of the tree written in the catalog's <c>/Pages</c> is written in — the
    /// catalog's, or 0 when the catalog is written in the trailer — when the root is a node whose kids the walk judged, read
    /// whole; -1 otherwise. Another rule judges the references to nothing written in a root a limit cut.
    /// </summary>
    public int JudgedRootIn { get; private set; } = -1;

    /// <summary>
    /// Gets the object numbers of the arrays of kids of their own whose kids the walk judged: walked under a node, and read
    /// whole. Another rule judges the references to nothing written in an array a limit cut.
    /// </summary>
    public HashSet<int> JudgedKidsArrays { get; } = new(SeededComparer.Instance);

    /// <summary>
    /// Gets the object numbers of the nodes and pages whose <c>/Parent</c> the walk could not judge: the node listing them
    /// has no number to be named by — written inside another object, in a <c>/Kids</c> or in the catalog's <c>/Pages</c> —,
    /// or one of the reader's limits cut them. The walk judges the <c>/Parent</c> of every other node and page it entered,
    /// the root's included; the exceptions are kept rather than the rule, so that memory does not grow with the pages.
    /// </summary>
    public HashSet<int> ParentsUnjudged { get; } = new(SeededComparer.Instance);

    /// <summary>Determines whether the walk judged the <c>/Parent</c> of object <paramref name="number"/>.</summary>
    public bool JudgedParent(int number) => (Nodes.Contains(number) || IsPage(number)) && !ParentsUnjudged.Contains(number);

    /// <summary>
    /// Gets the object number of each page of the tree, with the index it is first listed at — every page but those first
    /// listed past the greatest index, which <see cref="IsPage"/> knows.
    /// </summary>
    public Dictionary<int, int> PageIndexes { get; } = new(SeededComparer.Instance);

    /// <summary>Determines whether object <paramref name="number"/> is a page of the tree.</summary>
    public bool IsPage(int number) => PageIndexes.ContainsKey(number) || _pagesPastIndexes.Contains(number);

    /// <summary>
    /// Walks the page tree of <paramref name="document"/>, writing of each kind of fault the first <paramref name="room"/>
    /// it finds and counting the rest: the room the report has when the walk is made, or every fault outside a validation.
    /// </summary>
    public static PageTreeWalk Run(PdfDocument document, int room = int.MaxValue)
    {
        var walk = new PageTreeWalk(document.Reader, room);

        // The catalog is an object of its own, or a dictionary written in the trailer, which file.root-invalid reports.
        var catalogPlace = document.Trailer.GetRaw(PdfName.Root) is PdfReference reference
            ? Place.Of(reference.Target())
            : new Place(default, default, "/Root");

        // A catalog a limit cut may give its /Pages past the cut, or be past the cut whole, unread: the tree read, if any,
        // may not be the whole of it (#259).
        walk.Partial = walk.IsCut(catalogPlace);

        if (document.Catalog is not { } catalog)
        {
            return walk;
        }

        if (catalog.GetRaw(PdfName.Pages) is { } root)
        {
            walk.Walk(root, catalogPlace);
        }

        return walk;
    }

    /// <summary>Gives the location of object <paramref name="id"/>, with its page when it is one of the tree's.</summary>
    public PdfValidationLocation Locate(PdfObjectId id, long? position = null) =>
        PageIndexes.TryGetValue(id.Number, out var page)
            ? PdfValidationLocation.OnPage(page, id, position)
            : PdfValidationLocation.OfObject(id, position);

    private void Walk(PdfObject rootValue, Place catalog)
    {
        var place = rootValue is PdfReference reference ? Place.Of(reference.Target()) : catalog.Inside("/Pages");
        var id = place.Id;
        var root = rootValue.Resolve();
        var node = root switch
        {
            PdfDictionary dictionary => dictionary,
            PdfStream stream => stream.Dictionary,
            _ => null,
        };

        if (node is null)
        {
            // A /Pages that names an object the file lacks is object.reference-missing's to report; one the index holds
            // and the reader could not produce is the index's, and one a guard left out of the index, or cut short of a
            // dictionary — before its value, or in a value such as the "12" of "12 0 R" —, the guard's: either leaves the
            // tree unknown.
            Partial |= id.Number > 0 &&
                ((root is PdfNull && _reader.GetPresence(id.Number) is ObjectPresence.Unproduced or ObjectPresence.Unindexed) ||
                    _reader.IsCutAtLimit(id.Number));
            return;
        }

        if (id.Number > 0)
        {
            _visited.Add(id.Number);
        }

        // A /Parent that names an object a guard kept from the reader is unknown: it may be null, which is absence.
        if (!IsCut(place) && Given(node, PdfName.Parent) is { } rootParent && !NamesHiddenObject(rootParent) && ParentFaults.Take())
        {
            ParentFaults.Keep(new ProbeFinding(
                Location(place),
                $"The root of the page tree, {Where(place)}, has a /Parent, which only the nodes below it may have."));
        }

        if (!IsNode(node))
        {
            // A catalog whose /Pages is a page: a tree of one page, which the shape rules judge.
            EnterPage(node, place, parent: null);
            return;
        }

        if (id.Number <= 0 && !IsCut(place))
        {
            JudgedRootIn = place.Holder.Number;
        }

        EnterNode(node, place, parent: null);

        while (_stack.Count > 0)
        {
            var frame = _stack[^1];

            if (frame.Next >= frame.Kids.Count)
            {
                Leave(frame);
                continue;
            }

            var index = frame.Next++;
            Visit(frame, index, frame.Kids[index]);
        }
    }

    private void Visit(Frame frame, int index, PdfObject kid)
    {
        // A kid is told from one written in the array by being a reference, not by its number: "0 0 R" names object 0,
        // which heads the free list, and reads as null as any object the file lacks does. Through a chain of references,
        // the kid is the object the chain leads to, whose value is read.
        var reference = kid as PdfReference;
        var id = reference?.Target() ?? default;

        // What a node's /Kids holds is not judged where a limit cut the array: the findings on the kid itself are, located
        // at the object it is.
        var judged = !frame.KidsCut;

        if (reference is not null)
        {
            // A chain that does not end — too long to follow, or looping — reads as null wherever it is listed, and leads to
            // no object of the tree: each listing takes a page's place, the object the reader stopped following it at none.
            if (_reader.GetObject(id) is PdfReference)
            {
                if (InvalidSlot(frame, out var page))
                {
                    KeepInvalidSlot(
                        frame,
                        index,
                        page,
                        Invariant($"names object {reference.Id.Number}, whose chain of references is too long to follow or loops, which reads as null"));
                }

                return;
            }

            if (_onPath.Contains(id.Number))
            {
                frame.Uncountable = true;

                if (judged && Cycles.Take())
                {
                    Cycles.Keep(new ProbeFinding(
                        Location(frame.Place),
                        Invariant($"{Kid(frame, index)} names {Named(reference, id)}, {(id.Number == frame.Id.Number ? "which is that node itself" : "a node above it")}: the tree loops back on itself there, and what it should have listed is unknown.")));
                }

                return;
            }

            if (!_visited.Add(id.Number))
            {
                // Counted whether its finding is written or not: the pages it lists are the tree's.
                var counted = CountAgain(frame, id.Number);

                if (judged && RepeatedNodes.Take())
                {
                    RepeatedNodes.Keep(new ProbeFinding(
                        Location(frame.Place),
                        Invariant($"{Kid(frame, index)} names {Named(reference, id)}, which the tree already lists: {CountedAgain(counted)}.")));
                }

                return;
            }
        }
        else if (!judged && index >= frame.FragmentsFrom)
        {
            // A value written in an array a limit cut, after its last reference, dictionary or stream, may be what the cut
            // left of a reference — "12 0" of "12 0 R" —: it is not taken for a kid.
            return;
        }

        switch (kid.Resolve())
        {
            case PdfNull when reference is not null:
                switch (_reader.GetPresence(id.Number))
                {
                    case ObjectPresence.Unproduced or ObjectPresence.Unindexed:
                    case ObjectPresence.Defined when _reader.IsCutAtLimit(id.Number):
                        // The entry's fault, which the cross-reference rules report, or a guard's, which its report names —
                        // one that left the object out of the index, or cut it before its value —: the kid may have been a
                        // node, and the counts above it cannot be judged.
                        CountUnknownKid(frame, id.Number);
                        return;

                    case ObjectPresence.Missing:
                        if (InvalidSlot(frame, out var lacked))
                        {
                            KeepInvalidSlot(frame, index, lacked, Invariant($"names {Named(reference, id)}, which the file lacks"));
                        }

                        return;

                    default:
                        if (InvalidSlot(frame, out var nulled))
                        {
                            KeepInvalidSlot(frame, index, nulled, Invariant($"names {Named(reference, id)}, which is null"));
                        }

                        return;
                }

            case PdfNull:
                if (InvalidSlot(frame, out var nullPage))
                {
                    KeepInvalidSlot(frame, index, nullPage, "is null");
                }

                return;

            case PdfStream stream:
                var streamPlace = reference is not null ? Place.Of(id) : frame.KidPlace(index);

                if ((reference is not null || judged) && InvalidKids.Take())
                {
                    InvalidKids.Keep(new ProbeFinding(
                        Location(reference is not null ? streamPlace : frame.Place),
                        reference is not null
                            ? Invariant($"{Kid(frame, index)} names {Named(reference, id)}, a stream rather than a dictionary: the reader reads the stream's dictionary in its place.")
                            : $"{Kid(frame, index)} is a stream written in the array, where the tree wants an indirect reference to a dictionary: the reader reads the stream's dictionary in its place."));
                }

                Enter(stream.Dictionary, streamPlace, frame);
                return;

            case PdfDictionary dictionary:
                if (reference is null && judged && InvalidKids.Take())
                {
                    InvalidKids.Keep(new ProbeFinding(
                        Location(frame.Place),
                        $"{Kid(frame, index)} is a dictionary written in the array, where the tree wants an indirect reference to one."));
                }

                Enter(dictionary, reference is not null ? Place.Of(id) : frame.KidPlace(index), frame);
                return;

            case not PdfNull when reference is not null && _reader.IsCutAtLimit(id.Number):
                // A guard cut the object short of a dictionary, in a value such as the "12" of "12 0 R": as one cut before
                // its value, it may have been a node.
                CountUnknownKid(frame, id.Number);
                return;

            case var other:
                if (InvalidSlot(frame, out var otherPage))
                {
                    KeepInvalidSlot(
                        frame,
                        index,
                        otherPage,
                        reference is not null
                            ? Invariant($"names {Named(reference, id)}, which is {RuleText.Kind(other)}, neither a page nor a node")
                            : $"is {RuleText.Kind(other)}, neither a page nor a node");
                }

                return;
        }

        // A kid that is a link of a chain is named with the object the chain leads to, which is what the finding is about;
        // the name is written for a finding only, which most kids give none of.
        static string Named(PdfReference reference, PdfObjectId id) =>
            reference.Id.Number == id.Number
                ? Invariant($"object {id.Number}")
                : Invariant($"object {reference.Id.Number}, which leads to object {id.Number}");
    }

    /// <summary>
    /// Counts a kid that names object <paramref name="number"/>, which the tree cannot know — the index could not produce
    /// it, or a guard kept it from the reader in part or whole —, under <paramref name="frame"/>: it takes a page's place,
    /// may have been a node, and leaves the tree read in part and the counts above it unjudged.
    /// </summary>
    private void CountUnknownKid(Frame frame, int number)
    {
        Partial = true;
        frame.Uncountable = true;
        _uncountable.Add(number);
        CountPages(1);
    }

    /// <summary>
    /// Counts again what lies below object <paramref name="number"/>, a page or a node the tree already walked — or, when
    /// <paramref name="array"/>, an array of kids of its own —, under <paramref name="frame"/>: one page, or the pages
    /// counted below it, which a count that could not be trusted leaves the frame's uncountable.
    /// </summary>
    /// <returns>How many pages were counted, or -1 when they could not be counted with confidence.</returns>
    private long CountAgain(Frame frame, int number, bool array = false)
    {
        var counted = (array ? _pagesBelowArray : _pagesBelow).TryGetValue(number, out var below) ? below : 1;
        CountPages(counted);

        if ((array ? _uncountableArrays : _uncountable).Contains(number))
        {
            frame.Uncountable = true;
            return -1;
        }

        return counted;
    }

    /// <summary>
    /// Says what <see cref="CountAgain"/> counted again, <paramref name="counted"/> pages or -1, for a finding: the count is
    /// made whether the finding is written or not.
    /// </summary>
    private static string CountedAgain(long counted) => counted switch
    {
        -1 => "what lies below it is counted again, how many pages that is being unknown",
        1 => "its page is counted again",
        _ => Invariant($"its {CountText.Pages(counted)} are counted again"),
    };

    /// <summary>
    /// Counts <paramref name="pages"/> pages more, at most up to what a <see langword="long"/> holds, and gives how many were
    /// counted before them: the index of the first.
    /// </summary>
    private long CountPages(long pages)
    {
        var before = _pages;

        if (pages > long.MaxValue - _pages)
        {
            _pages = long.MaxValue;
            _overflowed = true;
        }
        else
        {
            _pages += pages;
        }

        return before;
    }

    /// <summary>
    /// Counts a kid that stands for a page the tree cannot read as one with nothing on it, the page counted at
    /// <paramref name="page"/>, and says whether its finding is to be written: one is found where no limit cut the array,
    /// and written while the walk has room for it (<see cref="KeepInvalidSlot"/>).
    /// </summary>
    private bool InvalidSlot(Frame frame, out long page)
    {
        page = CountPages(1);
        return !frame.KidsCut && InvalidKids.Take();
    }

    /// <summary>
    /// Writes the finding of the kid at <paramref name="index"/> that <see cref="InvalidSlot"/> counted at
    /// <paramref name="page"/>, which <paramref name="what"/> says.
    /// </summary>
    private void KeepInvalidSlot(Frame frame, int index, long page, string what) =>
        InvalidKids.Keep(new ProbeFinding(
            PageLocation(page, frame.Place),
            $"{Kid(frame, index)} {what}: it counts as a page with nothing on it."));

    private void Enter(PdfDictionary dictionary, Place place, Frame parent)
    {
        if (IsNode(dictionary))
        {
            CheckParent(dictionary, place, parent, NodeKind);
            EnterNode(dictionary, place, parent);
        }
        else
        {
            EnterPage(dictionary, place, parent);
        }
    }

    private void EnterNode(PdfDictionary node, Place place, Frame? parent)
    {
        var id = place.Id;
        var cut = IsCut(place);

        if (id.Number > 0)
        {
            Nodes.Add(id.Number);
        }

        Partial |= cut;

        var ownBox = Given(node, PdfName.MediaBox);

        if (ownBox is not null && !cut)
        {
            CheckMediaBox(ownBox, Location(place), place, NodeKind);
        }

        var kidsValue = Given(node, PdfName.Kids);

        if (kidsValue?.Resolve() is not PdfArray kids)
        {
            // A /Kids that names an object the file lacks is object.reference-missing's, and one the reader could not
            // produce the index's; either way, nothing below this node can be counted, nor the nodes above it judged. One
            // that names an object a guard kept from the reader — cut short of an array, or left out of the index — lists what
            // is unknown, and leaves the walk partial.
            var kidsCutAway = NamesHiddenObject(kidsValue);
            Partial |= kidsCutAway;

            if (!cut && !kidsCutAway && (kidsValue is null || kidsValue.Resolve() is not PdfNull) && NodesWithoutKids.Take())
            {
                NodesWithoutKids.Keep(new ProbeFinding(
                    Location(place),
                    kidsValue is null
                        ? $"{Subject(place, NodeKind)} has no /Kids: it lists no page."
                        : $"{Subject(place, NodeKind)} has {RuleText.Kind(kidsValue.Resolve())} for /Kids, not an array: it lists no page."));
            }

            if (id.Number > 0)
            {
                _pagesBelow[id.Number] = 0;

                if (kidsCutAway)
                {
                    _uncountable.Add(id.Number);
                }
            }

            if (parent is not null)
            {
                parent.Uncountable = true;
            }

            // It lists no page, and its /Count is still required (ISO 32000-1, 7.7.3.2). One whose /Kids a guard kept from the
            // reader lists what is unknown, and may be no node at all but where it says it is one.
            if (!cut && Given(node, PdfName.Count) is null && (!kidsCutAway || node.GetName(PdfName.Type) == PdfName.Pages))
            {
                CountMissing(place, below: 0, countable: !kidsCutAway);
            }

            return;
        }

        var kidsArray = default(PdfObjectId);
        var walksKids = true;
        var loops = false;
        var kidsReference = kidsValue as PdfReference;

        if (kidsReference is not null)
        {
            kidsArray = kidsReference.Target();
            KidsArrays.Add(kidsArray.Number);

            // An array of kids that is an object of its own is walked once, as a node is: one on the path loops back, and
            // one walked already is counted again, not walked — nodes written in it cannot be told apart by number. The
            // node itself is entered all the same: its own /Count, and what it is counted for where it is listed again,
            // are judged as any node's.
            loops = _arraysOnPath.Contains(kidsArray.Number);
            walksKids = !loops && _arraysWalked.Add(kidsArray.Number);
        }

        // The kids lie in the node, or in their array when it is an object of its own, which a limit may have cut alone.
        var kidsCut = kidsArray.Number > 0 ? _reader.IsCutAtLimit(kidsArray.Number) : cut;
        Partial |= kidsCut;

        if (cut && id.Number > 0)
        {
            CutNodes.Add(id.Number);
        }

        if (walksKids && !kidsCut && kidsArray.Number > 0)
        {
            JudgedKidsArrays.Add(kidsArray.Number);
        }

        // The node's /Count is read now, so that its frame keeps what it gives rather than the node (#201). One that names an
        // object a guard kept from the reader is unknown, whatever was read of it.
        var count = Given(node, PdfName.Count);
        long? declared = count is not null && !NamesHiddenObject(count) && count.Resolve() is PdfInteger { Value: var value } ? value : null;

        // A node a limit cut may give past the cut what its pages inherit, and a /Count of what lies below it.
        var frame = new Frame(place, walksKids ? kids : [], kidsArray)
        {
            CountAbsent = count is null,
            DeclaredCount = declared,
            PagesBefore = _pages,
            GivesMediaBox = ownBox is not null || parent?.GivesMediaBox == true || cut,
            HasResources = Given(node, PdfName.Resources) is not null || parent?.HasResources == true || cut,
            Cut = cut,
            KidsCut = kidsCut,
            WalksKids = walksKids,
            FragmentsFrom = kidsCut ? FragmentsFrom(kids) : kids.Count,
            Uncountable = kidsCut || loops,
        };

        _stack.Add(frame);

        if (id.Number > 0)
        {
            _onPath.Add(id.Number);
        }

        if (walksKids && kidsArray.Number > 0)
        {
            _arraysOnPath.Add(kidsArray.Number);
        }

        if (loops)
        {
            if (!cut && Cycles.Take())
            {
                Cycles.Keep(new ProbeFinding(
                    Location(place),
                    Invariant($"{Subject(place, NodeKind)} gives /Kids {kidsReference!.Id.Number} {kidsReference.Id.Generation} R, an array of kids above it: the tree loops back on itself there, and what it should have listed is unknown.")));
            }
        }
        else if (!walksKids)
        {
            // Counted whether its finding is written or not: the pages the array lists are the tree's.
            var counted = CountAgain(frame, kidsArray.Number, array: true);

            if (!cut && RepeatedNodes.Take())
            {
                RepeatedNodes.Keep(new ProbeFinding(
                    Location(place),
                    Invariant($"{Subject(place, NodeKind)} gives /Kids {kidsReference!.Id.Number} {kidsReference.Id.Generation} R, an array of kids the tree already lists: {CountedAgain(counted)}.")));
            }
        }
    }

    private void Leave(Frame frame)
    {
        _stack.RemoveAt(_stack.Count - 1);
        _onPath.Remove(frame.Id.Number);

        var below = _pages - frame.PagesBefore;

        // Past what a long holds, the pages below a node left since are no number.
        if (_overflowed)
        {
            frame.Uncountable = true;
        }

        if (frame.Id.Number > 0)
        {
            _pagesBelow[frame.Id.Number] = below;

            if (frame.Doubtful)
            {
                _uncountable.Add(frame.Id.Number);
            }
        }

        // An array of kids is recorded by the node that walked it, not by one that found it walked or above it; the doubt
        // a limit's cut of that node casts is on the node, not on the array, read whole with what it lists.
        if (frame.WalksKids && frame.KidsArray.Number > 0)
        {
            _arraysOnPath.Remove(frame.KidsArray.Number);
            _pagesBelowArray[frame.KidsArray.Number] = below;

            if (frame.Uncountable)
            {
                _uncountableArrays.Add(frame.KidsArray.Number);
            }
        }

        if (frame.Doubtful && _stack.Count > 0)
        {
            _stack[^1].Uncountable = true;
        }

        if (frame.CountAbsent)
        {
            // Missing whether or not the pages below can be counted; unknown where a limit cut the node.
            if (!frame.Cut)
            {
                CountMissing(frame.Place, below, countable: !frame.Doubtful);
            }
        }
        else if (!frame.Doubtful && frame.DeclaredCount is { } declared && declared != below && CountMismatches.Take())
        {
            CountMismatches.Keep(new ProbeFinding(
                Location(frame.Place),
                Invariant($"{Subject(frame.Place, NodeKind)} gives /Count {declared}, and {CountText.Pages(below)} {Lie(below)} below it.")));
        }
    }

    /// <summary>Records a node without <c>/Count</c>, saying how many pages lie below it when they can be counted.</summary>
    private void CountMissing(Place place, long below, bool countable)
    {
        if (CountMismatches.Take())
        {
            CountMismatches.Keep(new ProbeFinding(
                Location(place),
                countable
                    ? Invariant($"{Subject(place, NodeKind)} has no /Count; {CountText.Pages(below)} {Lie(below)} below it.")
                    : $"{Subject(place, NodeKind)} has no /Count, and how many pages lie below it is unknown."));
        }
    }

    private void EnterPage(PdfDictionary page, Place place, Frame? parent)
    {
        var id = place.Id;
        var cut = IsCut(place);
        var index = CountPages(1);

        // A page a limit cut may be a node whose /Kids lies past the cut: what lies below it is unknown, and so is the count
        // of the node listing it.
        Partial |= cut;

        if (cut)
        {
            parent?.Uncountable = true;

            // Listed again, it is counted again with the same doubt.
            if (id.Number > 0)
            {
                _uncountable.Add(id.Number);
            }
        }

        if (id.Number > 0 && !PageIndexes.ContainsKey(id.Number))
        {
            if (index <= int.MaxValue)
            {
                PageIndexes.Add(id.Number, (int)index);
            }
            else
            {
                _pagesPastIndexes.Add(id.Number);
            }
        }

        var location = PageLocation(index, place);

        if (parent is not null)
        {
            CheckParent(page, place, parent, PageKind);
        }

        if (cut)
        {
            return;
        }

        var ownBox = Given(page, PdfName.MediaBox);

        if (ownBox is not null)
        {
            CheckMediaBox(ownBox, location, place, PageKind);
        }
        else if (parent?.GivesMediaBox != true && MediaBoxFaults.Take())
        {
            MediaBoxFaults.Keep(new ProbeFinding(
                location,
                $"{Subject(place, PageKind)} has no /MediaBox, and no page tree node above it gives one: the page's size is unknown."));
        }

        if (Given(page, PdfName.Resources) is null && parent?.HasResources != true && ResourcesMissing.Take())
        {
            ResourcesMissing.Keep(new ProbeFinding(
                location,
                $"{Subject(place, PageKind)} has no /Resources, and no page tree node above it gives any."));
        }
    }

    private void CheckParent(PdfDictionary dictionary, Place place, Frame parent, string what)
    {
        var id = place.Id;

        // A kid written in the array, or a node written in its own parent's, has no number to be named by; and one a limit
        // cut may give its /Parent past the cut.
        if (id.Number <= 0 || parent.Id.Number <= 0 || IsCut(place))
        {
            if (id.Number > 0)
            {
                ParentsUnjudged.Add(id.Number);
            }

            return;
        }

        var given = dictionary.GetRaw(PdfName.Parent);

        if ((given is PdfReference listing && listing.Id.Number == parent.Id.Number) || !ParentFaults.Take())
        {
            return;
        }

        var fault = given switch
        {
            null => "has no /Parent",
            PdfReference named => Invariant($"gives /Parent {named.Id.Number} {named.Id.Generation} R"),
            var other => $"has {RuleText.Kind(other)} for /Parent",
        };

        ParentFaults.Keep(new ProbeFinding(
            Locate(id),
            Invariant($"{Subject(place, what)} {fault}, and page tree node {parent.Id.Number} lists it.")));
    }

    /// <summary>
    /// Gives the value of <paramref name="key"/>, or null when the dictionary lacks it or gives it <c>null</c> — written
    /// so, or an object the file defines as <c>null</c> —, which in a dictionary is absence (ISO 32000-1, 7.3.7).
    /// </summary>
    /// <remarks>
    /// A reference to an object the file lacks, or that the reader could not produce, counts as given: the reference
    /// is <c>object.reference-missing</c>'s, the entry the cross-reference rules'. So does one to an object a limit cut before
    /// its value, which may lie past the cut.
    /// </remarks>
    private PdfObject? Given(PdfDictionary dictionary, PdfName key) =>
        dictionary.GetRaw(key) switch
        {
            null or PdfNull => null,
            PdfReference reference when reference.Resolve() is PdfNull &&
                _reader.GetPresence(reference.Id.Number) == ObjectPresence.Defined &&
                !NamesHiddenObject(reference) => null,
            var value => value,
        };

    private void CheckMediaBox(PdfObject box, PdfValidationLocation location, Place place, string what)
    {
        // A /MediaBox that names an object the file lacks is object.reference-missing's, or the index's; one that names an
        // object a guard kept from the reader, or a corner that does, is unknown, whatever was read of it.
        var resolved = box.Resolve();

        if (resolved is PdfNull || NamesHiddenObject(box))
        {
            return;
        }

        if (resolved is not PdfArray { Count: 4 } array)
        {
            if (MediaBoxFaults.Take())
            {
                MediaBoxFaults.Keep(new ProbeFinding(
                    location,
                    resolved is PdfArray other
                        ? Invariant($"{MediaBoxOf(place, what)} is an array of {CountText.Of(other.Count, "value", "values")}, not a rectangle.")
                        : $"{MediaBoxOf(place, what)} is {RuleText.Kind(resolved)}, not a rectangle."));
            }

            return;
        }

        Span<double> corners = stackalloc double[4];

        // A corner that names an object a guard kept from the reader is unknown, whatever was read of it; the others are
        // judged.
        Span<bool> known = stackalloc bool[4];

        for (var index = 0; index < 4; index++)
        {
            if (NamesHiddenObject(array[index]))
            {
                continue;
            }

            switch (array.Resolved(index))
            {
                case PdfInteger integer:
                    corners[index] = integer.Value;
                    break;

                case PdfReal real when double.IsFinite(real.Value):
                    corners[index] = real.Value;
                    break;

                case var other:
                    if (MediaBoxFaults.Take())
                    {
                        MediaBoxFaults.Keep(new ProbeFinding(
                            location,
                            $"{MediaBoxOf(place, what)} holds {RuleText.Kind(other)} among its corners, not a rectangle of four numbers."));
                    }

                    return;
            }

            known[index] = true;
        }

        // Any two opposite corners make a rectangle (ISO 32000-1, 7.9.5), in whichever order they come.
        if (((known[0] && known[2] && corners[0] == corners[2]) || (known[1] && known[3] && corners[1] == corners[3])) &&
            MediaBoxFaults.Take())
        {
            MediaBoxFaults.Keep(new ProbeFinding(
                location,
                Invariant($"{MediaBoxOf(place, what)}, [{Corner(array, 0, known[0])} {Corner(array, 1, known[1])} {Corner(array, 2, known[2])} {Corner(array, 3, known[3])}], encloses no area.")));
        }

        // An unknown corner is named by the reference it is written as.
        static PdfObject Corner(PdfArray array, int index, bool known) => known ? array.Resolved(index) : array[index];
    }

    /// <summary>
    /// Determines whether what lies at <paramref name="place"/> was read only as far as one of the reader's limits let it
    /// be: the object it is, or the one it is written in, was cut — or, written in the trailer, the trailer the catalog was
    /// read from.
    /// </summary>
    private bool IsCut(Place place) =>
        place.Holder.Number > 0 ? _reader.IsCutAtLimit(place.Holder.Number) : _reader.IsWrittenInCutTrailer(PdfName.Root);

    /// <summary>Gives the location of what lies at <paramref name="place"/>: the object it is, or the one it is written in.</summary>
    private PdfValidationLocation Location(Place place) =>
        place.Holder.Number > 0 ? Locate(place.Holder) : TrailerLocation();

    /// <summary>
    /// Gives the location of the page counted at <paramref name="index"/>, written at <paramref name="place"/>: on that page,
    /// at the page's object or the one it is written in.
    /// </summary>
    private PdfValidationLocation PageLocation(long index, Place place) =>
        (index <= int.MaxValue, place.Holder.Number > 0) switch
        {
            (true, true) => PdfValidationLocation.OnPage((int)index, place.Holder),
            (false, true) => PdfValidationLocation.OfObject(place.Holder),
            _ => TrailerLocation(),
        };

    /// <summary>
    /// Locates what is written in the trailer — a page tree under a catalog written there —, as the Arlington walk does:
    /// at the newest trailer the reader merged, or at the document.
    /// </summary>
    private PdfValidationLocation TrailerLocation() =>
        _reader.TrailerLocation is >= 0 and var trailer ? PdfValidationLocation.AtPosition(trailer) : default;

    /// <summary>
    /// Names what lies at <paramref name="place"/>, a <paramref name="what"/>, to open a sentence: <c>Page tree node 2</c>,
    /// <c>The page object under /Kids[1] of page tree node 2</c>.
    /// </summary>
    private string Subject(Place place, string what) => RuleText.Capitalize(Describe(place, what));

    /// <summary>
    /// Names what lies at <paramref name="place"/>, a <paramref name="what"/>: <c>page tree node 2</c> when it is an object
    /// of its own, else by its path from the object it is written in, <c>the page object under /Kids[1] of page tree node
    /// 2</c>.
    /// </summary>
    private string Describe(Place place, string what) =>
        place.Id.Number > 0 ? Invariant($"{what} {place.Id.Number}") : $"the {what} {Where(place)}";

    /// <summary>
    /// Says where what lies at <paramref name="place"/> is: <c>object 2</c>, or, for a value written inside an object, its
    /// path from that object, <c>under /Kids[1] of page tree node 2</c> — <c>at [1] in object 7</c> in an array that is an
    /// object of its own.
    /// </summary>
    private string Where(Place place)
    {
        if (place.Id.Number > 0)
        {
            return Invariant($"object {place.Id.Number}");
        }

        var holder = place.Holder.Number;
        var owner = holder <= 0
            ? "the trailer"
            : Nodes.Contains(holder) ? Invariant($"page tree node {holder}") : Invariant($"object {holder}");
        var path = RuleText.Path(new StringBuilder(place.Path));

        return path.StartsWith('[') ? $"at {path} in {owner}" : $"under {path} of {owner}";
    }

    private string MediaBoxOf(Place place, string what) =>
        place.Id.Number > 0 ? Invariant($"The /MediaBox of object {place.Id.Number}") : $"The /MediaBox of {Describe(place, what)}";

    private string Kid(Frame frame, int index) =>
        Invariant($"The kid at index {index} of {Describe(frame.Place, NodeKind)}");

    private static string Lie(long count) => count == 1 ? "lies" : "lie";

    /// <summary>
    /// Gives the index past the last reference, dictionary or stream of <paramref name="kids"/>: what follows it in an array
    /// a limit cut may be what the cut left of a reference.
    /// </summary>
    private static int FragmentsFrom(PdfArray kids)
    {
        for (var index = kids.Count - 1; index >= 0; index--)
        {
            if (kids[index] is PdfReference or PdfDictionary or PdfStream)
            {
                return index + 1;
            }
        }

        return 0;
    }

    /// <summary>
    /// Determines whether <paramref name="dictionary"/> is a node of the tree: it lists kids, or says it is one. A
    /// <c>/Kids</c> that names an object a guard kept from the reader may list them, and counts as an array.
    /// </summary>
    private bool IsNode(PdfDictionary dictionary) =>
        dictionary.GetRaw(PdfName.Kids) is { } kids && (kids.Resolve() is PdfArray || NamesHiddenObject(kids)) ||
        dictionary.GetName(PdfName.Type) == PdfName.Pages;

    /// <summary>
    /// Determines whether <paramref name="value"/> names an object a guard kept from the reader: one a limit cut, which is
    /// unknown whatever was read of it — nothing, the <c>12</c> of <c>12 0 R</c>, an array cut short —, or one a guard left
    /// out of the index.
    /// </summary>
    private bool NamesHiddenObject(PdfObject? value) =>
        value is PdfReference reference && reference.Target().Number is var number &&
        (_reader.IsCutAtLimit(number) || _reader.GetPresence(number) == ObjectPresence.Unindexed);

    private static string Invariant(FormattableString text) => text.ToString(CultureInfo.InvariantCulture);

    /// <summary>
    /// Where a node or a page of the tree is written: an object of its own, whose <see cref="Id"/> and
    /// <see cref="Holder"/> it is; or a value written inside the object <see cref="Holder"/> names — the trailer when it
    /// names none —, at <see cref="Path"/> from it.
    /// </summary>
    /// <remarks>
    /// A kid written in its node's array is placed by the frame of that node and its index, its path written only when a
    /// finding names it (#168): the walk enters each such kid, and a path written for each cost a string a kid. Any other
    /// value is placed by the path it is written at.
    /// </remarks>
    /// <param name="Id">The object it is, or a number 0 when it is written inside another.</param>
    /// <param name="Holder">The object it is written in, or a number 0 for the trailer.</param>
    /// <param name="Written">Its path from <paramref name="Holder"/>, when it is not a kid placed by its node.</param>
    /// <param name="ListedIn">The frame of the node whose kids it is written among, or null.</param>
    /// <param name="Kid">Its index among the kids of <paramref name="ListedIn"/>.</param>
    private readonly record struct Place(PdfObjectId Id, PdfObjectId Holder, string? Written, Frame? ListedIn = null, int Kid = 0)
    {
        /// <summary>
        /// Gets its path from <see cref="Holder"/>, null for an object of its own: <c>/Kids[1]</c>, <c>[1]</c> in an array of
        /// kids of its own, <c>/Pages</c> under the catalog, the path of its node before its own for a node written inside
        /// another. Written each time it is asked for: by a finding only.
        /// </summary>
        public string? Path => ListedIn is { } node ? node.KidPath(Kid) : Written;

        /// <summary>Gives the place of object <paramref name="id"/>.</summary>
        public static Place Of(PdfObjectId id) => new(id, id, null);

        /// <summary>Gives the place of a value written at <paramref name="step"/> inside what lies here.</summary>
        public Place Inside(string step) => new(default, Holder, Path + step);
    }

    /// <summary>A node of the tree the walk is below, and what the pages under it inherit.</summary>
    /// <remarks>
    /// It keeps of the node what the walk still asks once the node is entered — its <c>/Count</c>, read then, and its array
    /// of kids —, never the node itself: a node holds what it likes beside them, which the reader's cache lets go of while
    /// the walk is below it (#201).
    /// </remarks>
    private sealed class Frame(Place place, PdfArray kids, PdfObjectId kidsArray)
    {
        /// <summary>Gets where the node is written.</summary>
        public Place Place { get; } = place;

        /// <summary>Gets the node's object number, or 0 when it is written inside another object.</summary>
        public PdfObjectId Id => Place.Id;

        /// <summary>
        /// Gets the node's kids, the array the parse made, held while the node is on the path; a kid written in it rather
        /// than referred to, which only an invalid file writes, is held with it.
        /// </summary>
        public PdfArray Kids { get; } = kids;

        /// <summary>Gets the node's array of kids when it is an object of its own, or a number 0.</summary>
        public PdfObjectId KidsArray { get; } = kidsArray;

        /// <summary>Gives the place of the kid written at <paramref name="index"/> of the node's <c>/Kids</c>.</summary>
        /// <remarks>
        /// In an array that is an object of its own, the kid is written in that object; otherwise in the node, under its
        /// <c>/Kids</c>. Its path is written when a finding asks for it (<see cref="KidPath"/>).
        /// </remarks>
        public Place KidPlace(int index) =>
            new(default, KidsArray.Number > 0 ? KidsArray : Place.Holder, null, this, index);

        /// <summary>
        /// Writes the path of the kid at <paramref name="index"/> from the object it is written in: <c>[1]</c> in an array of
        /// kids of its own, else the node's own path and <c>/Kids[1]</c>.
        /// </summary>
        /// <remarks>
        /// <para>
        /// The node's own path is its node's in turn when it is a kid written in an array too: an object of its own, a node
        /// written at a path of its own, as the catalog's <c>/Pages</c>, or an array of kids of its own starts a path.
        /// </para>
        /// <para>
        /// The parser bounds how deep nodes so written nest in an object read from a file; a value a caller built nests as
        /// deep as it was built, and the path is written in a loop whatever its depth: the indexes of the kids on the way are
        /// taken up the nodes, then written outermost first into one builder. Written node by node, each node's path copied
        /// into its kid's, it took a call for each node above — a stack of 1 MB overflowed under some 6,500 nodes a caller
        /// nested — and copied steps in a number that grew with the square of its depth (#168).
        /// </para>
        /// </remarks>
        public string KidPath(int index)
        {
            var kids = new Stack<int>();
            kids.Push(index);
            var node = this;

            // Up the nodes that are kids written in their node's array of kids, to the one whose kids start the path.
            while (node.KidsArray.Number == 0 && node.Place.ListedIn is { } listing)
            {
                kids.Push(node.Place.Kid);
                node = listing;
            }

            var path = node.KidsArray.Number == 0
                ? new StringBuilder(node.Place.Written)
                : new StringBuilder().Append(CultureInfo.InvariantCulture, $"[{kids.Pop()}]");

            // The stack gives the kids outermost first.
            foreach (var kid in kids)
            {
                path.Append(CultureInfo.InvariantCulture, $"/Kids[{kid}]");
            }

            return path.ToString();
        }

        /// <summary>Gets or sets the index of the next kid to visit.</summary>
        public int Next { get; set; }

        /// <summary>
        /// Gets a value indicating whether the node gives no <c>/Count</c>: it lacks one, or gives <c>null</c>, which in a
        /// dictionary is absence.
        /// </summary>
        public bool CountAbsent { get; init; }

        /// <summary>
        /// Gets the <c>/Count</c> the node gives, read when it was entered: null when it is absent, is no integer, or names an
        /// object a guard kept from the reader, which is unknown whatever was read of it.
        /// </summary>
        public long? DeclaredCount { get; init; }

        /// <summary>Gets or sets how many pages the walk had counted when it entered the node.</summary>
        public long PagesBefore { get; init; }

        /// <summary>
        /// Gets a value indicating whether the node gives the pages below it a media box, its own or inherited, or may give
        /// one past a limit's cut.
        /// </summary>
        public bool GivesMediaBox { get; init; }

        /// <summary>
        /// Gets a value indicating whether the node gives the pages below it resources, its own or inherited, or may give
        /// them past a limit's cut.
        /// </summary>
        public bool HasResources { get; init; }

        /// <summary>Gets a value indicating whether a limit cut the object the node is written in.</summary>
        public bool Cut { get; init; }

        /// <summary>Gets a value indicating whether a limit cut the object the node's <c>/Kids</c> is written in.</summary>
        public bool KidsCut { get; init; }

        /// <summary>
        /// Gets a value indicating whether the node walks its kids: not where its array of kids of its own is above it, or
        /// was walked already, the node then listing no kid of its own.
        /// </summary>
        public bool WalksKids { get; init; }

        /// <summary>
        /// Gets the index from which a value of the node's kids is not taken for a kid, being perhaps what a limit's cut left
        /// of a reference: past the last reference, dictionary or stream of an array a limit cut, else past its end.
        /// </summary>
        public int FragmentsFrom { get; init; }

        /// <summary>
        /// Gets or sets a value indicating whether what the node's kids list cannot be counted with confidence: a kid loops
        /// back, could not be read, or may be a node; a limit cut the array; or the count ran past what a
        /// <see langword="long"/> holds.
        /// </summary>
        public bool Uncountable { get; set; }

        /// <summary>
        /// Gets a value indicating whether the node's <c>/Count</c>, and those of the nodes above it, are not judged: what
        /// its kids list cannot be counted, or a limit cut the node itself.
        /// </summary>
        public bool Doubtful => Uncountable || Cut;
    }
}
