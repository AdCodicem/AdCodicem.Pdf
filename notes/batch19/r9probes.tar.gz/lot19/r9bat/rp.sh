#!/bin/bash
# usage: rp.sh TREE GENDIR OUT MODE [CFGS]  -- runs run.py under one process group with a time limit.
B=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/lot19/r9bat
export DOTNET_GCHeapHardLimit=0xC0000000
cd "$B"
start=$(date +%s)
setsid -w timeout -k 15 5400 python3 "$B/run.py" "$@" > "$B/run-$(basename "$3").log" 2>&1
rc=$?
echo "rc=$rc secs=$(( $(date +%s) - start ))"
tail -2 "$B/run-$(basename "$3").log"
