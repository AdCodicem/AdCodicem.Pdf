using System.Globalization;
using System.Text;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.Objects;
using AdCodicem.Pdf.Validation;

var sb = new StringBuilder();
for (var a = 0; a < args.Length - 1; a++)
{
    foreach (var file in Directory.GetFiles(args[a], "*.pdf").Order(StringComparer.Ordinal))
    {
        sb.Append("@@FILE ").AppendLine(Path.GetFileName(file));
        using (var document = PdfDocument.Open(file))
        {
            foreach (var s in document.Reader.Structure.Sections)
            {
                sb.AppendLine(string.Create(CultureInfo.InvariantCulture, $"  SEC {s.NamedBy} {s.State} {s.Kind} at {s.Offset}"));
            }

            sb.AppendLine(string.Create(CultureInfo.InvariantCulture, $"  OPEN repaired={document.WasRepaired}"));
            foreach (var d in document.Diagnostics)
            {
                sb.Append("  DIAG ").AppendLine(d.ToString());
            }

            for (var n = 1; n <= 11; n++)
            {
                var o = document.GetObject(new PdfObjectId(n));
                var t = o is PdfString str ? "\"" + str.ToText() + "\"" : o.GetType().Name;
                sb.AppendLine(string.Create(CultureInfo.InvariantCulture, $"  OBJ {n} = {t}; repaired={document.WasRepaired}"));
            }

            foreach (var d in document.Diagnostics)
            {
                sb.Append("  DIAG-AFTER ").AppendLine(d.ToString());
            }
        }

        using var validated = PdfDocument.Open(file);
        foreach (var f in new PdfValidator().Validate(validated).Findings)
        {
            sb.AppendLine(string.Create(CultureInfo.InvariantCulture, $"  FIND {f.Severity} {f.RuleId} at {f.Location}: {f.Message}"));
        }
    }
}

File.WriteAllText(args[^1], sb.ToString());
