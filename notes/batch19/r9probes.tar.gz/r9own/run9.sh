#!/bin/bash
# usage: run9.sh WORKTREE MANIFEST OUT
set -u
W=$1
M=$2
O=$3
cd "$W" || exit 2
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_R9_MANIFEST="$M"
export ZZ_R9_OUT="$O"
export ZZ_R9_THREADS=3
setsid timeout -k 15 1500 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*ZzR9Diff*" > "$O.log" 2>&1
echo "exit $?"
tail -3 "$O.log"
