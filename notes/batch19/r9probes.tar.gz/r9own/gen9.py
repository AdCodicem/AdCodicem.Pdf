"""Round 9 seeded hybrid files (own-stream lens). Base seed taken from the minute the run started: 202611080326.

Extends r8own/gen.py: more /Prev forms for the streams near the hybrid table's /Prev (reals with and without a fraction,
references to an integer, to a real, to a reference, chains of 32 and 33 objects, a cycle, a stream, an object no section
read yet places, an object past a lowered MaxObjectLength whose value is a reference), -1, past the file, the stream's own
offset; an extra stream inside the window; a first update that is itself hybrid; a newer table copying the hybrid table's
/XRefStm (the named-again branch), its own /Prev correct or off; S written before every revision ("early").

usage: gen9.py OUTDIR N [SEED0]
"""
import json
import os
import random
import sys

OUT = sys.argv[1]
N = int(sys.argv[2])
SEED0 = int(sys.argv[3]) if len(sys.argv) > 3 else 202611080326
os.makedirs(OUT, exist_ok=True)


def row(off, gen=0, kind='n'):
    return "%010d %05d %s \n" % (off, gen, kind)


def srows(rows):
    out = []
    for t, off, gen in rows:
        out.append(chr(t) + chr((off >> 24) & 255) + chr((off >> 16) & 255) + chr((off >> 8) & 255) + chr(off & 255)
                   + chr((gen >> 8) & 255) + chr(gen & 255))
    return "".join(out)


def pad(rnd):
    n = rnd.choice([0, 0, 30, 80, 150, 250, 350, 450, 600, 900, 1300]) + rnd.randint(0, 40)
    return "" if n == 0 else "%" + "-" * n + "\n"


class F:
    def __init__(self):
        self.t = "%PDF-1.7\n%\xe2\xe3\xcf\xd3\n"

    @property
    def pos(self):
        return len(self.t)

    def obj(self, n, body):
        p = self.pos
        self.t += "%d 0 obj\n%s\nendobj\n" % (n, body)
        return p

    def raw(self, s):
        self.t += s


PREVKINDS = ["none", "P", "correct", "rev0", "real", "realfrac", "ref", "ref2", "refreal", "chain32", "chain33", "cycle",
             "refstream", "reffwd", "objbig", "m1", "past", "self", "null", "huge", "name", "negzero"]
WEIGHTS = [6, 6, 4, 1, 2, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
REFKINDS = {"ref", "ref2", "refreal", "chain32", "chain33", "cycle", "refstream", "reffwd", "objbig"}


def gen(seed):
    rnd = random.Random(seed)
    meta = {"seed": seed}
    f = F()
    pos = {}
    tokens = {}  # placeholder -> function(final) giving 10-char-wide replacement text

    pos[1] = f.obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    pos[2] = f.obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    pos[3] = f.obj(3, "(three r0)")
    pos[5] = f.obj(5, "(five r0)")
    pos[8] = f.obj(8, "(eight r0)")
    sections = {}
    early = rnd.random() < 0.15
    meta["earlyS"] = early
    if early:
        pos[19] = f.obj(19, "(nineteen early)")
        es = f.pos
        rows = srows([(1, es, 0), (1, pos[19], 0)])
        f.obj(18, "<< /Type /XRef /Size 40 /W [1 4 2] /Index [18 2] @@PVEARLY@@@@@@@@@@@@@@/Length %d >>\nstream\n%s\nendstream" % (len(rows), rows))
        sections["early"] = (es, "stream")
    kind0 = rnd.choice(["table", "table", "stream"])
    meta["kind0"] = kind0
    rev0 = f.pos
    fwd = kind0 == "table" and rnd.random() < 0.5
    meta["fwd"] = fwd
    if kind0 == "table":
        extra = "25 1\n@@@@ROW25@@@@@@@@@@\n" if fwd else ""
        f.raw("xref\n0 4\n" + row(0, 65535, 'f') + row(pos[1]) + row(pos[2]) + row(pos[3]) + "5 1\n" + row(pos[5])
              + "8 1\n" + row(pos[8]) + extra + "trailer\n<< /Size 40 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % rev0)
    else:
        rows = srows([(0, 0, 65535), (1, pos[1], 0), (1, pos[2], 0), (1, pos[3], 0), (1, pos[5], 0), (1, pos[8], 0),
                      (1, rev0, 0)])
        f.obj(9, "<< /Type /XRef /Size 40 /W [1 4 2] /Index [0 4 5 1 8 2] /Root 1 0 R /Length %d >>\nstream\n%s\nendstream"
              % (len(rows), rows))
        f.raw("startxref\n%d\n%%%%EOF\n" % rev0)
    sections["rev0"] = (rev0, kind0)
    f.raw(pad(rnd))
    has1 = rnd.random() < 0.7
    meta["has1"] = has1
    if has1:
        pos[3] = f.obj(3, "(three r1)")
        pos[7] = f.obj(7, "(seven r1)")
        kind1 = rnd.choice(["table", "stream", "hybrid"])
        meta["kind1"] = kind1
        if kind1 == "hybrid":
            s1 = f.pos
            p1 = rnd.choice(["correct", "none", "none"])
            meta["prev1"] = p1
            rows = srows([(1, pos[7], 0), (1, s1, 0)])
            pv = "/Prev %d " % rev0 if p1 == "correct" else ""
            f.obj(14, "<< /Type /XRef /Size 40 /W [1 4 2] /Index [7 1 14 1] %s/Length %d >>\nstream\n%s\nendstream"
                  % (pv, len(rows), rows))
            sections["s1"] = (s1, "stream")
            if rnd.random() < 0.3:
                f.raw(pad(rnd))
            rev1 = f.pos
            f.raw("xref\n0 1\n" + row(0, 65535, 'f') + "3 1\n" + row(pos[3]) + "5 1\n" + row(0, 1, 'f')
                  + "trailer\n<< /Size 40 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n" % (rev0, s1, rev1))
            sections["rev1"] = (rev1, "table")
        elif kind1 == "table":
            rev1 = f.pos
            f.raw("xref\n0 1\n" + row(0, 65535, 'f') + "3 1\n" + row(pos[3]) + "5 1\n" + row(0, 1, 'f') + "7 1\n"
                  + row(pos[7]) + "trailer\n<< /Size 40 /Root 1 0 R /Prev %d >>\nstartxref\n%d\n%%%%EOF\n" % (rev0, rev1))
            sections["rev1"] = (rev1, "table")
        else:
            p1 = rnd.choice(["correct", "correct", "correct", "none"])
            meta["prev1"] = p1
            rev1 = f.pos
            rows = srows([(1, pos[3], 0), (0, 0, 1), (1, pos[7], 0), (1, rev1, 0)])
            pv = "/Prev %d " % rev0 if p1 == "correct" else ""
            f.obj(13, "<< /Type /XRef /Size 40 /W [1 4 2] /Index [3 1 5 1 7 1 13 1] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream"
                  % (pv, len(rows), rows))
            f.raw("startxref\n%d\n%%%%EOF\n" % rev1)
            sections["rev1"] = (rev1, "stream")
    if rnd.random() < 0.12:
        f.raw(pad(rnd))
        pos[6] = f.obj(6, "(six stale)")
        f.raw("xref\n0 1\n" + row(0, 65535, 'f') + "6 1\n" + row(pos[6]) + "trailer\n<< /Size 40 /Root 1 0 R >>\n")
        meta["stale"] = True
    f.raw(pad(rnd))
    pos[3] = f.obj(3, "(three r2)")
    hasB = rnd.random() < 0.75
    hasC = rnd.random() < 0.35
    order = ["A", "B"] if hasB else ["A"]
    if hasB and rnd.random() < 0.5:
        order = ["B", "A"]
    if hasC:
        order.insert(rnd.randint(0, len(order)), "C")
    meta["order"] = order
    target = "rev1" if has1 else "rev0"
    if rnd.random() < 0.2:
        target = rnd.choice(order)
    if "s1" in sections and rnd.random() < 0.3:
        target = "s1"
    meta["target"] = target
    delta = rnd.choice([0, rnd.randint(-12, -1), rnd.randint(-12, -1), rnd.randint(1, 40), rnd.randint(1, 40),
                        rnd.choice([-300, -100, 100, 300, 600])])
    meta["delta"] = delta
    xs_choices = list(order)
    for k in ("rev1", "rev0", "s1"):
        if k in sections and sections[k][1] == "stream":
            xs_choices.append(k)
    if early:
        xs_choices += ["early"] * 3
    xs = rnd.choice(xs_choices + [order[0]] * 2)
    meta["xrefstm"] = xs
    keys = list(order) + (["early"] if early else [])
    sprev = {k: rnd.choices(PREVKINDS, WEIGHTS)[0] for k in keys}
    if early and sprev["early"] in REFKINDS:
        sprev["early"] = rnd.choice(["none", "P", "correct", "real", "m1"])
    meta["sprev"] = sprev
    refs = {}
    nums = {"A": (11, 4), "B": (12, 10), "C": (15, 16)}

    def prev_text(k):
        kindp = sprev[k]
        if kindp == "none":
            return ""
        if kindp in ("P", "correct"):
            return "/Prev @@P%s@@@@@@ " % k
        if kindp == "rev0":
            return "/Prev %010d " % rev0
        if kindp == "real":
            return "/Prev @@P%s@@@@@@.0 " % k
        if kindp == "realfrac":
            return "/Prev @@P%s@@@@@@.5 " % k
        if kindp == "negzero":
            return "/Prev -0.0 "
        if kindp == "m1":
            return "/Prev -1 "
        if kindp == "past":
            return "/Prev 0099999990 "
        if kindp == "self":
            return "/Prev @@S%s@@@@@@ " % k
        if kindp == "null":
            return "/Prev null "
        if kindp == "huge":
            return "/Prev 99999999999999 "
        if kindp == "name":
            return "/Prev /Nowhere "
        first = 20 + 4 * len(refs)
        refs[k] = (kindp, first)
        if kindp == "reffwd":
            return "/Prev %d 0 R " % (25 if fwd else 39)
        return "/Prev %d 0 R " % first

    for i, k in enumerate(order):
        if i > 0:
            f.raw(pad(rnd))
        num, objn = nums[k]
        pos[objn] = f.obj(objn, "(obj %d r2)" % objn)
        here = f.pos
        sections[k] = (here, "stream")
        rows = srows([(1, pos[objn], 0), (1, here, 0)])
        f.obj(num, "<< /Type /XRef /Size 40 /W [1 4 2] /Index [%d 1 %d 1] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream"
              % (objn, num, prev_text(k), len(rows), rows))
    tgt = sections[target][0]
    P = tgt + delta
    meta["P"] = P
    reftable = []
    chain_base = 100
    for k, (kindp, first) in refs.items():
        if kindp == "ref":
            reftable.append((first, f.obj(first, "%010d" % P)))
        elif kindp == "refreal":
            reftable.append((first, f.obj(first, "%010d.0" % P)))
        elif kindp == "ref2":
            reftable.append((first, f.obj(first, "%d 0 R" % (first + 1))))
            reftable.append((first + 1, f.obj(first + 1, "%010d" % P)))
        elif kindp in ("chain32", "chain33"):
            n = 32 if kindp == "chain32" else 33
            numbers = [first] + [chain_base + j for j in range(n - 1)]
            chain_base += 40
            for j, number in enumerate(numbers):
                body = "%d 0 R" % numbers[j + 1] if j < n - 1 else "%010d" % P
                reftable.append((number, f.obj(number, body)))
        elif kindp == "cycle":
            reftable.append((first, f.obj(first, "%d 0 R" % (first + 1))))
            reftable.append((first + 1, f.obj(first + 1, "%d 0 R" % first)))
        elif kindp == "refstream":
            reftable.append((first, f.obj(first, "<< /Length 10 >>\nstream\n%010d\nendstream" % P)))
        elif kindp == "objbig":
            reftable.append((first, f.obj(first, "%d 0 R\n%%%s" % (first + 1, "=" * 120))))
            reftable.append((first + 1, f.obj(first + 1, "%010d" % P)))
    f.raw(pad(rnd))
    t2 = f.pos
    ent = "3 1\n" + row(pos[3])
    for number, at in sorted(reftable):
        ent += "%d 1\n" % number + row(at)
    if rnd.random() < 0.5:
        ent += "11 1\n" + row(sections["A"][0])
    f.raw("xref\n0 1\n" + row(0, 65535, 'f') + ent + "trailer\n<< /Size 400 /Root 1 0 R /Prev %d /XRefStm %010d >>\nstartxref\n%d\n%%%%EOF\n"
          % (P, sections[xs][0], t2))
    t3 = None
    if rnd.random() < 0.3:
        t3prev = rnd.choice(["correct", "correct", "off"])
        meta["t3prev"] = t3prev
        if rnd.random() < 0.5:
            f.raw(pad(rnd))
        pos[17] = f.obj(17, "(seventeen r3)")
        t3 = f.pos
        pv3 = t2 if t3prev == "correct" else t2 + rnd.choice([-7, -3, 5])
        f.raw("xref\n0 1\n" + row(0, 65535, 'f') + "17 1\n" + row(pos[17])
              + "trailer\n<< /Size 400 /Root 1 0 R /Prev %d /XRefStm %010d >>\nstartxref\n%d\n%%%%EOF\n" % (pv3, sections[xs][0], t3))
    meta["t3"] = t3
    text = f.t
    true_prev = sections["rev1" if has1 else "rev0"][0]
    for k in order:
        if sprev[k] in ("P", "real", "realfrac"):
            text = text.replace("@@P%s@@@@@@" % k, "%010d" % P)
        elif sprev[k] == "correct":
            text = text.replace("@@P%s@@@@@@" % k, "%010d" % true_prev)
        text = text.replace("@@S%s@@@@@@" % k, "%010d" % sections[k][0])
    if early:
        kindp = sprev["early"]
        pv = {"none": "", "P": "/Prev %010d " % P, "correct": "/Prev %010d " % true_prev, "real": "/Prev %010d.0 " % P,
              "realfrac": "/Prev %010d.5 " % P, "m1": "/Prev -1 ", "rev0": "/Prev %010d " % rev0, "negzero": "/Prev -0.0 ",
              "past": "/Prev 0099999990 ", "null": "/Prev null ", "huge": "/Prev 99999999999999 ", "name": "/Prev /Nowhere ",
              "self": "/Prev %010d " % sections["early"][0]}[kindp]
        # the placeholder is 12 characters wide; the replacement is shorter or longer: pad it with spaces before /Length,
        # inside the dictionary, so that no offset moves
        width = len("@@PVEARLY@@@@@@@@@@@@@@")
        if len(pv) > width:
            # too long to fit: fall back to a shorter form of the same kind where one exists
            pv = pv.replace("/Prev 00", "/Prev ").replace("/Prev 0", "/Prev ")
        if len(pv) > width:
            return None, meta
        text = text.replace("@@PVEARLY@@@@@@@@@@@@@@", pv + " " * (width - len(pv)))
    if fwd:
        p25 = len(text)
        text += "25 0 obj\n%010d\nendobj\n" % P
        text = text.replace("@@@@ROW25@@@@@@@@@@\n", row(p25))
    meta["sections"] = {k: v[0] for k, v in sections.items()}
    meta["t2"] = t2
    return text, meta


manifest = []
written = 0
skipped = 0
i = 0
while written < N:
    seed = SEED0 + i
    i += 1
    text, meta = gen(seed)
    if text is None:
        skipped += 1
        continue
    name = "h%012d.pdf" % seed
    with open(os.path.join(OUT, name), "wb") as fh:
        fh.write(text.encode("latin-1"))
    meta["name"] = name
    manifest.append(meta)
    written += 1
with open(os.path.join(OUT, "manifest.jsonl"), "w") as fh:
    for m in manifest:
        fh.write(json.dumps(m) + "\n")
print("wrote", written, "skipped", skipped)
