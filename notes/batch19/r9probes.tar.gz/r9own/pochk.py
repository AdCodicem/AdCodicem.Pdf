import collections
import re
import sys

txt = open(sys.argv[1]).read()
c = collections.Counter()
for b in re.split(r'(?m)^(?==== )', txt):
    if not b.startswith('==='):
        continue
    lines = b.splitlines()
    po = [int(l.split('\t')[3]) for l in lines if l.startswith('D\t') and '\txref.stream-passed-over\t' in l]
    if not po:
        continue
    c['blocks with passed-over'] += 1
    offs = set()
    for l in lines:
        f = l.split('\t')
        if f[0] == 'S':
            offs.add(int(f[3]))
    others = collections.defaultdict(list)
    for l in lines:
        f = l.split('\t')
        if f[0] == 'D' and f[2] != 'xref.stream-passed-over':
            others[int(f[3])].append(f[2])
    limited = any(l.startswith('D\t') and '\tlimit.' in l for l in lines)
    if limited:
        c['passed-over beside a limit report'] += 1
        print('LIMIT', lines[0], po)
    for p in po:
        if p in offs:
            c['passed-over at a section offset'] += 1
            print('SECTION', lines[0], p)
        if p in others:
            c['passed-over beside another report there'] += 1
            print('BESIDE', lines[0], p, others[p])
    if len(po) != len(set(po)):
        c['duplicate'] += 1
        print('DUP', lines[0])
print(c)
