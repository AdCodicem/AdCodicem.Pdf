"""Groups the blocks classify.py calls worse (head against a baseline) by what the /Prev search of the hybrid table took on
each side. usage: cat9.py CLS.tsv HEAD.txt BASE.txt MANIFEST.jsonl"""
import collections
import json
import re
import sys

cls, head, base, man = sys.argv[1:5]


def blocks(path):
    out = {}
    for b in re.split(r'(?m)^(?==== )', open(path).read()):
        if b.startswith('==='):
            out[b.splitlines()[0][4:]] = b
    return out


H = blocks(head)
B = blocks(base)
meta = {}
for line in open(man):
    m = json.loads(line)
    meta[m['name']] = m


def taken(block, m):
    """(named offset, offset, state) of every /Prev section found moved or not found, by key."""
    res = []
    for line in block.splitlines():
        f = line.split('\t')
        if f[0] == 'S' and f[1] == '/Prev':
            res.append((int(f[2]), int(f[3]), f[5]))
        if f[0] == 'T' and f[1] == 'open':
            res.append(('THROW', f[2], ''))
    return res


def key_of(m, off):
    for k, v in m['sections'].items():
        if v == off:
            return k
    if off == m.get('t2'):
        return 't2'
    if off == m.get('t3'):
        return 't3'
    return str(off)


groups = collections.defaultdict(list)
for line in open(cls):
    f = line.rstrip('\n').split('\t')
    if len(f) < 2 or f[1] != 'worse':
        continue
    k = f[0]
    name = k.split('/')[-1].split(' ')[0]
    limits = k.split(' ')[1]
    m = meta[name]
    S = m['sections'][m['xrefstm']]
    na = m['t3'] is not None and m.get('t3prev') == 'correct'
    th = taken(H[k], m)
    tb = taken(B[k], m)

    def desc(t):
        out = []
        for named, off, state in t:
            if named == 'THROW':
                out.append('THROW')
                continue
            kk = key_of(m, off)
            pos = '' if off < 0 else ('<S' if off < S else ('=S' if off == S else '>S'))
            kind = m['sprev'].get(kk, '')
            out.append('%s%s[%s]%s' % (kk, pos, kind, state[0]))
        return ' '.join(out)

    g = (limits if limits in ('trailer100', 'count2', 'index4') else 'dflt/obj', 'NA' if na else '', desc(tb), '->', desc(th))
    groups[g].append(name)

for g, names in sorted(groups.items(), key=lambda x: -len(x[1])):
    print(len(names), ' '.join(g), ' e.g.', ' '.join(names[:3]))
