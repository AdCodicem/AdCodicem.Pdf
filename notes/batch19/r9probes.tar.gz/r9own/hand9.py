"""Round 9 hand-made shapes (own-stream lens). usage: hand9.py OUTDIR"""
import os
import sys

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)


def row(off, gen=0, kind='n'):
    return "%010d %05d %s \n" % (off, gen, kind)


def srows(rows):
    out = []
    for t, off, gen in rows:
        out.append(chr(t) + chr((off >> 24) & 255) + chr((off >> 16) & 255) + chr((off >> 8) & 255) + chr(off & 255)
                   + chr((gen >> 8) & 255) + chr(gen & 255))
    return "".join(out)


class F:
    def __init__(self, version="1.5"):
        self.t = "%%PDF-%s\n%%\xe2\xe3\xcf\xd3\n" % version

    @property
    def pos(self):
        return len(self.t)

    def obj(self, n, body):
        p = self.pos
        self.t += "%d 0 obj\n%s\nendobj\n" % (n, body)
        return p

    def raw(self, s):
        self.t += s


def fill(text, **values):
    for k, v in values.items():
        token = "@@" + k + "@@"
        token = token + "@" * (10 - len(token)) if len(token) < 10 else token
        assert len(token) == 10, token
        text = text.replace(token, "%010d" % v)
    return text


def own_shape(oldest_names, own_type="/Type /XRef ", own_widths="[1 4 2]", own_prev=""):
    """As HybridFiles.PrevFallingShortOfTheStreamBeforeTheTablesOwn("nothing", shortOfOwn: true, "the oldest table"), the
    oldest table naming stream 11 through oldest_names: "" (nothing), "xrefstm" or "prev"."""
    f = F()
    c = f.obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    p = f.obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    three = f.obj(3, "(three as the oldest has it)")
    eight = f.obj(8, "(eight, which stream 6 frees)")
    oldest = f.pos
    names = {"": "", "xrefstm": "/XRefStm @@OWN@@@@@ ", "prev": "/Prev @@OWN@@@@@ "}[oldest_names]
    f.raw("xref\n0 4\n" + row(0, 65535, 'f') + row(c) + row(p) + row(three) + "8 1\n" + row(eight)
          + "trailer\n<< /Size 9 /Root 1 0 R %s>>\nstartxref\n%d\n%%%%EOF\n" % (names, oldest))
    f.raw("%" + "-" * 1200 + "\n")
    four = f.obj(4, "(four)")
    stream = f.pos
    rows = srows([(1, four, 0), (1, stream, 0), (0, 0, 1)])
    f.obj(6, "<< /Type /XRef /Size 9 /W [1 4 2] /Index [4 1 6 1 8 1] /Root 1 0 R /Prev %d /Length %d >>\nstream\n%s\nendstream"
          % (oldest, len(rows), rows))
    five = f.obj(5, "(five)")
    ten = f.obj(10, "(ten)")
    own = f.pos
    orows = srows([(1, ten, 0)])
    f.obj(11, "<< %s/Size 12 /W %s /Index [10 1] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream"
          % (own_type, own_widths, own_prev, len(orows), orows))
    f.raw("%" + "-" * 600 + "\n")
    newest = f.pos
    f.raw("xref\n0 1\n" + row(0, 65535, 'f') + "5 1\n" + row(five) + "11 1\n" + row(own)
          + "trailer\n<< /Size 12 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n" % (own - 7, stream, newest))
    return fill(f.t, OWN=own), dict(oldest=oldest, stream=stream, own=own, newest=newest)


def s_judged_through_big(which):
    """The newest table's /XRefStm reads stream 6 (S); its /Prev falls 7 bytes short of S ('S') or of stream 11, past S
    ('X'). The stream judged gives /Prev 20 0 R: object 20 holds the reference 21 0 R and a comment of 120 bytes (past a
    MaxObjectLength of 64), object 21 the offset the table's /Prev names. The oldest table lies within the window: it is
    the other place, taken first."""
    f = F()
    c = f.obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    p = f.obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    three = f.obj(3, "(three old)")
    oldest = f.pos
    f.raw("xref\n0 4\n" + row(0, 65535, 'f') + row(c) + row(p) + row(three)
          + "trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % oldest)
    four = f.obj(4, "(four)")
    stream = f.pos
    sprev = "/Prev 20 0 R " if which == "S" else "/Prev %010d " % oldest
    # stream 6 indexes 4, itself, 20 and 21; 20 and 21 are written after the streams, their rows known then
    f.raw("@@STREAM6@@")
    x = f.pos
    xprev = "/Prev 20 0 R " if which == "X" else "/Prev %010d " % oldest
    f.raw("@@STREAM11@@")
    o20 = f.obj(20, "21 0 R\n%" + "=" * 120)
    o21 = f.obj(21, "@@NAMED@@@")
    named = (stream if which == "S" else x) - 7
    newest = f.pos
    text = f.t
    # build the streams now, of fixed width, offsets known
    rows6 = srows([(1, four, 0), (1, stream, 0), (1, o20, 0), (1, o21, 0)])
    s6 = "6 0 obj\n<< /Type /XRef /Size 22 /W [1 4 2] /Index [4 1 6 1 20 2] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream\nendobj\n" % (
        sprev, len(rows6), rows6)
    rows11 = srows([(1, x, 0)])
    s11 = "11 0 obj\n<< /Type /XRef /Size 22 /W [1 4 2] /Index [11 1] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream\nendobj\n" % (
        xprev, len(rows11), rows11)
    return text, dict(stream=stream, x=x, o20=o20, o21=o21, oldest=oldest, newest=newest, s6=s6, s11=s11, named=named)


def build_big(which):
    # two passes: lay the file out with the streams' real lengths
    text, m = s_judged_through_big(which)
    # the placeholders are replaced by the streams; every offset after them moves: lay out again with known lengths
    f = F()
    c = f.obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    p = f.obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    three = f.obj(3, "(three old)")
    oldest = f.pos
    f.raw("xref\n0 4\n" + row(0, 65535, 'f') + row(c) + row(p) + row(three)
          + "trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % oldest)
    four = f.obj(4, "(four)")
    stream = f.pos
    len6 = len(m["s6"])
    x = stream + len6
    len11 = len(m["s11"])
    o20 = x + len11
    o21 = o20 + len("20 0 obj\n21 0 R\n%" + "=" * 120 + "\nendobj\n")
    named = (stream if which == "S" else x) - 7
    sprev = "/Prev 20 0 R " if which == "S" else "/Prev %010d " % oldest
    xprev = "/Prev 20 0 R " if which == "X" else "/Prev %010d " % oldest
    rows6 = srows([(1, four, 0), (1, stream, 0), (1, o20, 0), (1, o21, 0)])
    s6 = "6 0 obj\n<< /Type /XRef /Size 22 /W [1 4 2] /Index [4 1 6 1 20 2] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream\nendobj\n" % (
        sprev, len(rows6), rows6)
    rows11 = srows([(1, x, 0)])
    s11 = "11 0 obj\n<< /Type /XRef /Size 22 /W [1 4 2] /Index [11 1] /Root 1 0 R %s/Length %d >>\nstream\n%s\nendstream\nendobj\n" % (
        xprev, len(rows11), rows11)
    if len(s6) != len6 or len(s11) != len11:
        # /Prev widths differ between passes: pad the shorter /Prev
        raise SystemExit("layout changed: %d/%d %d/%d" % (len(s6), len6, len(s11), len11))
    f.raw(s6)
    assert f.pos == x
    f.raw(s11)
    assert f.pos == o20
    f.obj(20, "21 0 R\n%" + "=" * 120)
    assert f.pos == o21
    f.obj(21, "%010d" % named)
    newest = f.pos
    f.raw("xref\n0 1\n" + row(0, 65535, 'f') + "trailer\n<< /Size 22 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n"
          % (named, stream, newest))
    return f.t, dict(stream=stream, x=x, oldest=oldest, newest=newest, named=named)


shapes = {}
shapes["guard-own-xrefstm"] = own_shape("xrefstm")
shapes["guard-own-none"] = own_shape("")
shapes["lostprev-own-negwidth"] = own_shape("prev", own_widths="[1 -4 2]")
shapes["lostprev-own-ok"] = own_shape("prev")
shapes["lostxs-own-negwidth"] = own_shape("xrefstm", own_widths="[1 -4 2]")
shapes["lostxs-own-notype-negwidth"] = own_shape("xrefstm", own_type="", own_widths="[1 -4 2]")
shapes["lostprev-own-notype-negwidth"] = own_shape("prev", own_type="", own_widths="[1 -4 2]")
shapes["lostprev-own-undecodable"] = own_shape("prev", own_prev="/Filter /Foo ")
shapes["big-S"] = build_big("S")
shapes["big-X"] = build_big("X")

with open(os.path.join(OUT, "hand9.tsv"), "w") as fh:
    for name, (text, meta) in shapes.items():
        path = os.path.join(OUT, name + ".pdf")
        with open(path, "wb") as out:
            out.write(text.encode("latin-1"))
        fh.write("%s\t%s\n" % (name, meta))
print("\n".join(sorted(shapes)))
