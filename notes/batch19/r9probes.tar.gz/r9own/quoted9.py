"""A stream an attached file's data quotes near a hybrid table's /Prev. usage: quoted9.py OUTDIR"""
import os
import sys

OUT = sys.argv[1]


def row(off, gen=0, kind='n'):
    return "%010d %05d %s \n" % (off, gen, kind)


def srows(rows):
    return "".join(chr(t) + chr((o >> 24) & 255) + chr((o >> 16) & 255) + chr((o >> 8) & 255) + chr(o & 255)
                   + chr((g >> 8) & 255) + chr(g & 255) for t, o, g in rows)


def obj(n, body):
    return "%d 0 obj\n%s\nendobj\n" % (n, body)


def build():
    t = "%PDF-1.5\n%\xe2\xe3\xcf\xd3\n"
    c = len(t); t += obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    p = len(t); t += obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    three = len(t); t += obj(3, "(three old)")
    oldest = len(t)
    t += ("xref\n0 4\n" + row(0, 65535, 'f') + row(c) + row(p) + row(three)
          + "trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % oldest)
    t += "%" + "-" * 1200 + "\n"
    four = len(t); t += obj(4, "(four)")
    stream = len(t)
    # stream 6's length does not depend on the offsets it holds (fixed-width rows, /Prev written in ten digits)
    probe = "6 0 obj\n<< /Type /XRef /Size 13 /W [1 4 2] /Index [4 1 6 2] /Root 1 0 R /Prev %010d /Length %d >>\nstream\n%s\nendstream\nendobj\n"
    length6 = len(probe % (oldest, 21, "x" * 21))
    seven = stream + length6
    inner = srows([(1, 15, 0)])
    quoted = "12 0 obj\n<< /Type /XRef /Size 13 /W [1 4 2] /Index [12 1] /Length %d >>\nstream\n%s\nendstream\nendobj\n" % (len(inner), inner)
    data = "%PDF-1.5 an attached file\n" + quoted + "%%EOF\n"
    head7 = "7 0 obj\n<< /Type /EmbeddedFile /Length %d >>\nstream\n" % len(data)
    q = seven + len(head7) + len("%PDF-1.5 an attached file\n")
    rows6 = srows([(1, four, 0), (1, stream, 0), (1, seven, 0)])
    s6 = probe % (oldest, len(rows6), rows6)
    assert len(s6) == length6
    t += s6
    assert len(t) == seven
    t += head7 + data + "\nendstream\nendobj\n"
    newest = len(t)
    t += ("xref\n0 1\n" + row(0, 65535, 'f') + "trailer\n<< /Size 13 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n"
          % (q - 7, stream, newest))
    assert t[q:q + 8] == "12 0 obj"
    return t, dict(stream=stream, quoted=q, oldest=oldest, newest=newest)


text, meta = build()
with open(os.path.join(OUT, "quoted-in-data.pdf"), "wb") as fh:
    fh.write(text.encode("latin-1"))
print(meta)
