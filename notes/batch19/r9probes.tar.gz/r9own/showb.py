import re
import sys


def blocks(path):
    txt = open(path).read()
    out = {}
    for b in re.split(r'(?m)^(?==== )', txt):
        if b.startswith('==='):
            out[b.splitlines()[0][4:]] = b
    return out


key = sys.argv[1]
width = 240
for p in sys.argv[2:]:
    b = blocks(p).get(key)
    print('#####', p)
    print('\n'.join(l[:width] for l in (b or 'MISSING').splitlines()))
