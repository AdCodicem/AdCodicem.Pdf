#!/bin/bash
# usage: runtests.sh WORKTREE LOG CLASSFILTER...
set -u
W=$1
LOG=$2
shift 2
cd "$W" || exit 2
export DOTNET_GCHeapHardLimit=0xC0000000
args=()
for c in "$@"; do
  args+=(--filter-class "$c")
done
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- "${args[@]}" > "$LOG" 2>&1
echo "exit $?"
tail -8 "$LOG"
