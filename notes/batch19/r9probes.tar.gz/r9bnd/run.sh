#!/bin/bash
# usage: run.sh <worktree> <filter>
cd "$1" || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
rm -f /tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9bnd-out.txt
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "$2" 2>&1 | tail -6
