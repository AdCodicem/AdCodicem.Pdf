"""Refuter's own shapes for passed-over-lost-section-false. usage: gen.py OUTDIR"""
import os
import sys

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)


def row(off, gen=0, kind='n'):
    return "%010d %05d %s \n" % (off, gen, kind)


def srows(rows):
    return "".join(chr(t) + "".join(chr((off >> s) & 255) for s in (24, 16, 8, 0)) + chr((g >> 8) & 255) + chr(g & 255)
                   for t, off, g in rows)


def build(link, own_type="/Type /XRef ", widths="[1 4 2]", extra="", own_prev_mode="none"):
    """link: how the oldest table names stream 11: 'prev', 'xrefstm', 'none'.
    own_prev_mode: 'none' (no /Prev), 'tableprev' (stream 11's /Prev names the newest table's /Prev offset)."""
    parts = ["%PDF-1.5\n%\xe2\xe3\xcf\xd3\n"]

    def pos():
        return sum(len(x) for x in parts)

    def obj(n, body):
        p = pos()
        parts.append("%d 0 obj\n%s\nendobj\n" % (n, body))
        return p

    c = obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    p = obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    three = obj(3, "(old three)")
    eight = obj(8, "(eight freed by stream 6)")
    oldest = pos()
    link_text = {"prev": "/Prev #OWN###### ", "xrefstm": "/XRefStm #OWN###### ", "none": ""}[link]
    parts.append("xref\n0 4\n" + row(0, 65535, 'f') + row(c) + row(p) + row(three) + "8 1\n" + row(eight)
                 + "trailer\n<< /Size 9 /Root 1 0 R %s>>\nstartxref\n%d\n%%%%EOF\n" % (link_text, oldest))
    parts.append("%" + "-" * 1200 + "\n")
    four = obj(4, "(four)")
    s6 = pos()
    r6 = srows([(1, four, 0), (1, s6, 0), (0, 0, 1)])
    obj(6, "<< /Type /XRef /Size 9 /W [1 4 2] /Index [4 1 6 1 8 1] /Root 1 0 R /Prev %d /Length %d >>\nstream\n%s\nendstream"
        % (oldest, len(r6), r6))
    five = obj(5, "(five)")
    ten = obj(10, "(ten)")
    own = pos()
    r11 = srows([(1, ten, 0)])
    prev11 = "/Prev #NAMED#### " if own_prev_mode == "tableprev" else ""
    obj(11, "<< %s/Size 12 /W %s /Index [10 1] /Root 1 0 R %s%s/Length %d >>\nstream\n%s\nendstream"
        % (own_type, widths, prev11, extra, len(r11), r11))
    parts.append("%" + "-" * 600 + "\n")
    newest = pos()
    named = own - 7
    parts.append("xref\n0 1\n" + row(0, 65535, 'f') + "5 1\n" + row(five) + "11 1\n" + row(own)
                 + "trailer\n<< /Size 12 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n" % (named, s6, newest))
    t = "".join(parts).replace("#OWN######", "%010d" % own).replace("#NAMED####", "%010d" % named)
    return t, dict(oldest=oldest, s6=s6, own=own, named=named, newest=newest)


shapes = {
    "a-prev-typed-negw": build("prev", widths="[1 -4 2]"),
    "b-prev-typed-foo": build("prev", extra="/Filter /Foo "),
    "c-prev-untyped-negw": build("prev", own_type="", widths="[1 -4 2]"),
    "d-xs-untyped-negw": build("xrefstm", own_type="", widths="[1 -4 2]"),
    "e-xs-typed-negw": build("xrefstm", widths="[1 -4 2]"),
    "f-prev-typed-ok": build("prev"),
    "g-prev-typed-negw-tableprev": build("prev", widths="[1 -4 2]", own_prev_mode="tableprev"),
    "h-none-typed-negw": build("none", widths="[1 -4 2]"),
    "i-none-typed-ok": build("none"),
    "j-xs-untyped-foo": build("xrefstm", own_type="", extra="/Filter /Foo "),
}
with open(os.path.join(OUT, "meta.tsv"), "w") as fh:
    for name, (text, meta) in shapes.items():
        with open(os.path.join(OUT, name + ".pdf"), "wb") as f:
            f.write(text.encode("latin-1"))
        fh.write("%s\t%s\n" % (name, meta))
with open(os.path.join(OUT, "meta.tsv")) as fh:
    print(fh.read())
