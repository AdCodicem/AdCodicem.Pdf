#!/bin/bash
# usage: run.sh REPO OUTFILE
cd "$1" || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_POL_DIR=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9refute-pol/files
export ZZ_POL_OUT="$2"
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*ZzRefutePol*" 2>&1 | tail -4
