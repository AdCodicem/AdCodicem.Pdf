#!/bin/bash
cd /home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-32 || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*ZzR9PlaceName*" --filter-method "*A_place_the_search_near_a_hybrid_table_s_prev_passes_over*" > /tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9ref-placename/test-out.txt 2>&1
