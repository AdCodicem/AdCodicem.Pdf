using System.Globalization;
using System.Text;
using AdCodicem.Pdf.Diagnostics;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.IO.XRef;
using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.Tests;

public class ZzR9tCovTests
{
    private const string Out = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9t/cov-probe.txt";

    private static readonly PdfReaderOptions ObjectGuard = new() { Limits = PdfReaderLimits.Default with { MaxObjectLength = 1024 } };

    private static void Line(string s) => File.AppendAllText(Out, s + "\n");

    private static void Show(string title, byte[] file, PdfReaderOptions options)
    {
        using var document = PdfDocument.Open(file, options);
        Line("=== " + title);
        foreach (var s in document.Reader.Structure.Sections)
        {
            Line($"  S {s.NamedBy} {s.State} {s.Kind} at={s.Offset} cut={s.CutByLimit} fault={s.Fault}");
        }

        foreach (var d in document.Diagnostics)
        {
            Line($"  D {d.Severity} {d.Code} @{d.Position}: {d.Message}");
        }

        object? eight;
        try
        {
            eight = document.GetObject(new PdfObjectId(8));
        }
        catch (Exception e)
        {
            eight = e.GetType().Name;
        }

        Line($"  eight={eight} repaired={document.WasRepaired}");
        foreach (var d in document.Diagnostics)
        {
            Line($"  D' {d.Severity} {d.Code} @{d.Position}: {d.Message}");
        }
    }

    [Theory]
    [InlineData("/W [1 4 2] /Size 5 0 R", "8", "/Foo", "2 0 R")]
    [InlineData("/W [1 4 2] /Index 5 0 R", "[0 8]", "/Foo", "2 0 R")]
    [InlineData("/W [1 4 2] /Size 5 0 R", "8", "/Foo", "7")]
    public void ZzReachUndecodedFaultWithoutStream(string values, string five, string filter, string length)
    {
        var built = ChainFiles.UnderAnUpdate(
            "/Type /XRef /Size 8 /W [1 4 2] /Length {length}",
            five + new string(' ', 1100),
            compressed: false,
            predicted: false,
            placed: true,
            six: "<< /Type /XRef " + values + " /Filter " + filter + " /Length " + length + " >>\nstream\nxxxxxxx\nendstream",
            placedToo: new Dictionary<int, string> { [8] = "(eight)" });
        var text = Encoding.Latin1.GetString(built);
        var stream = text.IndexOf("\n7 0 obj", StringComparison.Ordinal) + 1;
        var sixAt = text.IndexOf("\n6 0 obj", StringComparison.Ordinal) + 1;
        var file = Encoding.Latin1.GetBytes(text.Replace(string.Create(CultureInfo.InvariantCulture, $"/Prev {stream} "), string.Create(CultureInfo.InvariantCulture, $"/Prev {sixAt} "), StringComparison.Ordinal));
        Show($"{values} {filter} /Length {length} WHOLE", file, new PdfReaderOptions());
        Show($"{values} {filter} /Length {length} GUARD", file, ObjectGuard);
    }
}
