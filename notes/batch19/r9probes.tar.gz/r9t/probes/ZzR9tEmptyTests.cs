using System.Globalization;
using System.Text;
using AdCodicem.Pdf.Diagnostics;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.IO.XRef;
using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.Tests;

public class ZzR9tEmptyTests
{
    private const string Out = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9t/empty.txt";

    private static string Inv(FormattableString s) => s.ToString(CultureInfo.InvariantCulture);

    private static (byte[] File, long Own) Build(bool rows)
    {
        var file = new HandWrittenFile(version: "1.5");
        file.Object(1, "<< /Type /Catalog /Pages 2 0 R >>");
        file.Object(2, "<< /Type /Pages /Kids [] /Count 0 >>");
        file.Raw("%" + new string('-', 1200) + "\n");
        var old = file.Position;
        file.Raw(rows ? "xref\n0 1\n0000000000 65535 f \ntrailer\n<< /Size 3 /Root 1 0 R >>\n" : "xref\n0 0\ntrailer\n<< /Size 3 /Root 1 0 R >>\n");
        file.Object(4, "(four)");
        var stream = file.Position;
        file.Object(6, "<< /Type /XRef /Size 7 /W [1 4 2] /Index [4 0] /Root 1 0 R /Length 0 >>\nstream\n\nendstream");
        file.Object(10, "(ten)");
        var own = file.Position;
        file.Object(11, "<< /Type /XRef /Size 12 /W [1 4 2] /Index [10 0] /Root 1 0 R /Length 0 >>\nstream\n\nendstream");
        file.Raw("%" + new string('-', 600) + "\n");
        var newest = file.Position;
        file.Raw(Inv($"xref\n0 0\ntrailer\n<< /Size 12 /Root 1 0 R /Prev {own - 7} /XRefStm {stream} >>\nstartxref\n{newest}\n%%EOF\n"));
        _ = old;
        return (file.Bytes, own);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ZzEmptyChainPassedOver(bool rows)
    {
        var (file, own) = Build(rows);
        using var document = PdfDocument.Open(file);
        File.AppendAllText(Out, $"=== rows={rows} own={own} count={document.Reader.ObjectCount}\n");
        foreach (var s in document.Reader.Structure.Sections)
        {
            File.AppendAllText(Out, $"  S {s.NamedBy} {s.State} {s.Kind} at={s.Offset} fault={s.Fault}\n");
        }

        foreach (var d in document.Diagnostics)
        {
            File.AppendAllText(Out, $"  D {d.Severity} {d.Code} @{d.Position}: {d.Message[..Math.Min(160, d.Message.Length)]}\n");
        }

        File.AppendAllText(Out, $"  repaired={document.WasRepaired}\n");
    }
}
