using System.Text;

namespace AdCodicem.Pdf.Tests;

public class ZzR9tDumpTests
{
    private const string Dir = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9t/dumps";

    private static void Save(string name, byte[] file, string offsets)
    {
        File.WriteAllBytes(Path.Combine(Dir, name + ".pdf"), file);
        File.WriteAllText(Path.Combine(Dir, name + ".txt"), offsets);
    }

    [Fact]
    public void ZzDumpAll()
    {
        Directory.CreateDirectory(Dir);

        foreach (var (w, f, l, n) in new (string, string, int?, string)[]
        {
            ("[1 4 2] ]", "/Foo", null, "a1"), ("[1 -4 2] ]", "", null, "a2"), ("[1 4 2] /W [1 4 2]", "/Foo", null, "a3"),
            ("[1 4 2] /W [1 4 2]", "/FlateDecode", null, "a4"), ("[1 4 2]", "/Foo", 3, "a5"), ("[1 -4 2]", "", 3, "a6"),
        })
        {
            var r = HybridFiles.PrevNamingAStreamBesideTheOldestTable(string.Empty, widths: w, filter: f, length: l);
            Save("undec-" + n, r.File, $"oldest={r.Oldest} four={r.Four} named={r.Named}");
        }

        foreach (var (t, n) in new[] { ("/Type /XRef ", "typed"), (string.Empty, "untyped") })
        {
            var r = HybridFiles.PrevNamingAStreamBesideTheOldestTable(t, padding: 100_000);
            Save("look-" + n, r.File, $"oldest={r.Oldest} four={r.Four} named={r.Named}");
        }

        var own = 0;
        foreach (var (op, so, sp, on, ow) in new (string, bool, string, bool, string)[]
        {
            ("nothing", true, "the oldest table", false, "[1 4 2]"), ("nothing", false, "the oldest table", false, "[1 4 2]"),
            ("the table's /Prev", true, "the oldest table", false, "[1 4 2]"),
            ("nothing", true, "nothing", false, "[1 4 2]"), ("nothing", false, "nothing", false, "[1 4 2]"),
            ("nothing", true, "the table's /Prev", false, "[1 4 2]"), ("nothing", false, "the table's /Prev", false, "[1 4 2]"),
            ("nothing", true, "the oldest table", true, "[1 4 2]"), ("nothing", true, "nothing", false, "[1 -4 2]"),
        })
        {
            var r = HybridFiles.PrevFallingShortOfTheStreamBeforeTheTablesOwn(op, so, sp, on, ow);
            Save("own-" + own++, r.File, $"ownPrev={op} shortOfOwn={so} streamPrev={sp} oldestNamesOwn={on} ownWidths={ow}\noldest={r.Oldest} stream={r.Stream} own={r.Own} newest={r.Newest}");
        }

        var place = 0;
        foreach (var (near, extra, sp, pf) in new (string, string, string, bool)[]
        {
            ("stream 11", "/Junk } ", "nothing", false), ("an outline item", "/Junk } ", "nothing", false),
            ("stream 11", "/Pad (" + new string('.', 300) + ") ", "nothing", false),
            ("stream 11", "/Pad (" + new string('.', 70_000) + ") ", "the oldest table", false),
            ("stream 11", "/Pad (" + new string('.', 70_000) + ") ", "the oldest table", true),
        })
        {
            var r = HybridFiles.PrevFallingShortOfAPlaceBesideTheStream(near, extra, sp, pf);
            Save("place-" + place++, r.File, $"near={near} extraLen={extra.Length} streamPrev={sp} prevFirst={pf}\noldest={r.Oldest} stream={r.Stream} near={r.Near} newest={r.Newest}");
        }

        foreach (var sp in new[] { "nothing", "offset 0", "the first revision's stream" })
        {
            var r = HybridFiles.PrevOfZeroNearTheStream(sp);
            Save("zero-" + sp.Replace(' ', '_').Replace("'", string.Empty, StringComparison.Ordinal), r.File, $"first={r.First} stream={r.Stream} newest={r.Newest}");
        }

        foreach (var op in new[] { "the table's /Prev", "the table's /Prev, as a real", "the table's /Prev, through a reference", "the table's /Prev, through two references", "nothing", "the table before", "outside the file", "a negative offset", "a name" })
        {
            var r = HybridFiles.PrevFallingInsideTheTablesOwnStream(op);
            Save("inside-" + Slug(op), r.File, $"oldest={r.Oldest} previous={r.Previous} stream={r.Stream} newest={r.Newest}");
        }

        foreach (var sp in new[] { "the first revision's stream", "a reference", "another offset", "the table's /Prev, as a real" })
        {
            var r = HybridFiles.PrevFallingShortOfTheFirstRevisionsStream(sp);
            Save("firstrev-" + Slug(sp), r.File, $"first={r.First} stream={r.Stream} newest={r.Newest}");
        }

        var m = HybridFiles.PrevFallingShortOfAMiddleRevisionsStream();
        Save("middlerev", m.File, $"oldest={m.Oldest} middle={m.Middle} stream={m.Stream} newest={m.Newest}");
        var o = HybridFiles.PrevFallingShortOfAnOlderRevisionsStream();
        Save("olderrev", o.File, $"older={o.Older} previous={o.Previous} stream={o.Stream} newest={o.Newest}");

        foreach (var (again, op, shortBy, lost) in new (bool, string, int, bool)[]
        {
            (false, "nothing", 0, false), (false, "the table's /Prev", 0, false), (true, "nothing", 0, false), (true, "the table's /Prev", 0, false),
            (true, "nothing", 7, false), (false, "nothing", 0, true), (true, "nothing", 0, true),
        })
        {
            var r = HybridFiles.CopyingTheXRefStmIntoLaterTrailers(again, op, shortBy, lost);
            Save($"copy-{again}-{Slug(op)}-{shortBy}-{lost}", r.File, $"oldest={r.Oldest} stream={r.Stream} previous={r.Previous} own={r.Own} hybrid={r.Hybrid} newest={r.Newest}");
        }

        foreach (var (objects, spent) in new[] { (14, 0), (16, 0), (0, 28) })
        {
            var r = HybridFiles.PrevFallingShortOfTheTablesOwnStreamAmongObjects(objects, spent);
            Save($"among-{objects}-{spent}", r.File, $"stream={r.Stream} own={r.Own} hybrid={r.Hybrid} newest={r.Newest}");
        }

        var p = HybridFiles.PassingOverOneStreamTwice();
        Save("twice", p.File, $"oldest={p.Oldest} stream={p.Stream} older={p.Older} own={p.Own} middle={p.Middle} newest={p.Newest}");
        var a = HybridFiles.NamingAStreamAgainAboveATableThatNamesNone();
        Save("againnone", a.File, $"previous={a.Previous} own={a.Own} middle={a.Middle} newest={a.Newest}");
        var b = HybridFiles.NamingAStreamOneByteIntoItsNumber();
        Save("onebyte", b.File, $"stream={b.Stream} newest={b.Newest}");

        var (built, _, _, _, newest) = HybridFiles.NamingAnObjectBesideTheStream(
            "<< /Pad (" + new string('-', 70_000) + ") /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
        Save("bound-0", built, $"newest={newest}");
        var (spentFile, spentNewest) = HybridFiles.UnderPlacesSpent(built, newest, 32);
        Save("bound-32", spentFile, $"newest={spentNewest}");

        foreach (var spent in new[] { 0, 28 })
        {
            var (b2, _, stream, own2, hybrid) = HybridFiles.PrevFallingShortOfTheStreamBeforeTheTablesOwn("nothing", shortOfOwn: false, "the table's /Prev");
            var (f2, n2) = spent > 0 ? HybridFiles.UnderPlacesSpent(b2, hybrid, spent) : (b2, hybrid);
            Save($"putback-{spent}", f2, $"stream={stream} own={own2} hybrid={hybrid} newest={n2}");
        }
    }

    private static string Slug(string s)
    {
        var sb = new StringBuilder();
        foreach (var c in s)
        {
            sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        }

        return sb.ToString();
    }
}
