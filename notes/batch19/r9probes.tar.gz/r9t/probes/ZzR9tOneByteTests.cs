using System.Globalization;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.IO.XRef;
using AdCodicem.Pdf.Objects;
using AdCodicem.Pdf.Validation;

namespace AdCodicem.Pdf.Tests;

public class ZzR9tOneByteTests
{
    private const string Out = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9t/onebyte-OUT.txt";

    private static string Inv(FormattableString s) => s.ToString(CultureInfo.InvariantCulture);

    private static string Row(long offset) => Inv($"{offset:D10} 00000 n \n");

    private static string Rows(params (int Type, long Field2, int Field3)[] rows)
    {
        var data = new System.Text.StringBuilder();
        foreach (var (type, field2, field3) in rows)
        {
            data.Append((char)type).Append((char)((field2 >> 24) & 0xFF)).Append((char)((field2 >> 16) & 0xFF))
                .Append((char)((field2 >> 8) & 0xFF)).Append((char)(field2 & 0xFF)).Append((char)((field3 >> 8) & 0xFF)).Append((char)(field3 & 0xFF));
        }

        return data.ToString();
    }

    // The update's own stream, stream 13, indexes object 4 and itself and gives no /Prev; the oldest table, which alone
    // indexes the catalog, lies within reach (no long comment); the newest table's /XRefStm names 1 byte into stream 13's
    // number and its /Prev 7 bytes before the stream's header.
    private static (byte[] File, long Oldest, long Stream, long Newest) Build(string xrefStmShift)
    {
        var file = new HandWrittenFile(version: "1.5");
        var catalog = file.Object(1, "<< /Type /Catalog /Pages 2 0 R >>");
        var pages = file.Object(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        var page = file.Object(3, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << >> >>");
        var oldest = file.Position;
        file.Raw(Inv($"xref\n0 4\n0000000000 65535 f \n{Row(catalog)}{Row(pages)}{Row(page)}trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n{oldest}\n%%EOF\n"));
        var four = file.Object(4, "(four)");
        var stream = file.Position;
        var rows = Rows((1, four, 0), (1, stream, 0));
        file.Object(13, Inv($"<< /Type /XRef /Size 14 /W [1 4 2] /Index [4 1 13 1] /Root 1 0 R /Length {rows.Length} >>\nstream\n{rows}\nendstream"));
        file.Raw("%" + new string('-', 600) + "\n");
        var newest = file.Position;
        var named = xrefStmShift == "one byte in" ? stream + 1 : stream;
        file.Raw(Inv($"xref\n0 1\n0000000000 65535 f \ntrailer\n<< /Size 14 /Root 1 0 R /Prev {stream - 7} /XRefStm {named} >>\nstartxref\n{newest}\n%%EOF\n"));
        return (file.Bytes, oldest, stream, newest);
    }

    [Theory]
    [InlineData("one byte in")]
    [InlineData("exact")]
    public void ZzOneByteIn(string shift)
    {
        var (file, oldest, stream, newest) = Build(shift);
        using (var document = PdfDocument.Open(file))
        {
            File.AppendAllText(Out, $"=== {shift} oldest={oldest} stream={stream} newest={newest}\n");
            foreach (var s in document.Reader.Structure.Sections)
            {
                File.AppendAllText(Out, $"  S {s.NamedBy} {s.State} {s.Kind} at={s.Offset} named={s.NamedOffset}\n");
            }

            foreach (var d in document.Diagnostics)
            {
                File.AppendAllText(Out, $"  D {d.Severity} {d.Code} @{d.Position}: {d.Message[..Math.Min(150, d.Message.Length)]}\n");
            }

            File.AppendAllText(Out, $"  repaired={document.WasRepaired} four={document.GetObject(new PdfObjectId(4))}\n");
        }

        using var validated = PdfDocument.Open(file);
        var errors = new PdfValidator().Validate(validated).Findings.Where(f => f.Severity == PdfValidationSeverity.Error).Select(f => f.RuleId);
        File.AppendAllText(Out, $"  errors=[{string.Join(", ", errors)}]\n");
    }
}
