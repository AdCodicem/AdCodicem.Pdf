using System.Text;
using AdCodicem.Pdf.Diagnostics;
using AdCodicem.Pdf.IO.Filters;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.Objects;

namespace AdCodicem.Pdf.Tests;

public class ZzR9tFilterTests
{
    private const string Out = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9t/filter.txt";

    [Fact]
    public void ZzShowEmptyThenUnsupported()
    {
        foreach (var (filter, data) in new[] { ("[/ASCIIHexDecode /Foo]", ">"), ("[/ASCIIHexDecode /Foo /Bar]", ">"), ("/LZWDecode", "\u0096\u0000"), ("/ASCIIHexDecode", "zzzzzz>"), ("[/ASCIIHexDecode 5]", ">") })
        {
            var dictionary = new PdfObjectParser(Encoding.ASCII.GetBytes($"<< /Filter {filter} >>")).ParseObject().AsDictionary().Required();
            var diagnostics = new PdfDiagnostics();
            var output = PdfFilterPipeline.Decode(
                new PdfStream(dictionary, PdfStreamData.FromMemory(Encoding.Latin1.GetBytes(data))), diagnostics, endHidden: false, reachedBefore: false,
                out var leftEncoded, out var cut, out var said);
            File.AppendAllText(Out, $"{filter} {data}: said={said} out='{Encoding.Latin1.GetString(output.Span)}' codes=[{string.Join(", ", diagnostics.Select(d => d.Code + ": " + d.Message))}]\n");
        }
    }
}
