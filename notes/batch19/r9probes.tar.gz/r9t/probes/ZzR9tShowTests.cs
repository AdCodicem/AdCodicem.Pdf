using AdCodicem.Pdf.Diagnostics;
using AdCodicem.Pdf.Documents;
using AdCodicem.Pdf.IO;
using AdCodicem.Pdf.IO.XRef;
using AdCodicem.Pdf.Objects;
using AdCodicem.Pdf.Validation;

namespace AdCodicem.Pdf.Tests;

public class ZzR9tShowTests
{
    private const string Out = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9t/show.txt";



    private static void Line(string s) => File.AppendAllText(Out, s + "\n");

    private static void Show(string title, byte[] file, PdfReaderOptions? options = null)
    {
        using var document = PdfDocument.Open(file, options ?? new PdfReaderOptions());
        Line("=== " + title);
        foreach (var s in document.Reader.Structure.Sections)
        {
            Line($"  S {s.NamedBy} {s.State} {s.Kind} at={s.Offset} named={s.NamedOffset} from={s.NamedFrom} fault={s.Fault}");
        }

        foreach (var d in document.Diagnostics)
        {
            Line($"  D {d.Severity} {d.Code} @{d.Position}: {d.Message}");
        }

        Line($"  repaired={document.WasRepaired}");
    }

    [Fact]
    public void ZzShowNoOffset()
    {
        foreach (var p in new[] { "outside the file", "a negative offset", "a name" })
        {
            var (file, _, _, stream, newest) = HybridFiles.PrevFallingInsideTheTablesOwnStream(p);
            Show($"{p} stream={stream} newest={newest}", file);
        }
    }
}
