#!/bin/bash
# usage: r9ref-run.sh <worktree> <outfile> <filter>
cd "$1" || exit 1
rm -f "$2"
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_REF_OUT="$2"
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "$3" 2>&1 | tail -4
