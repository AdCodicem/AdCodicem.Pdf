#!/bin/bash
# usage: run.sh <worktree> <outfile>
cd "$1" || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_OUT="$2"
rm -f "$ZZ_OUT"
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*ZzR9Ref*" 2>&1 | tail -6
cat "$ZZ_OUT"
