#!/bin/bash
# usage: classes.sh <worktree>
cd "$1" || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
setsid timeout -k 15 1500 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- \
  --filter-class "*GuardCutValueTests" --filter-class "*HostileInputTests" --filter-class "*CrossReferenceChainTests" \
  --filter-class "*CrossReferenceRuleTests" --filter-class "*FilterTests" 2>&1 | tail -15
