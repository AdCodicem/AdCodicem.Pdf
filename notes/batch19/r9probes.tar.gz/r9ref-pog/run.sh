#!/bin/bash
# Runs the ZzR9Ref probes in the worktree given as $1.
cd "$1" || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
dotnet test --project "$1/tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj" -c Release --no-build -- --filter-method '*ZzR9Ref_*' 2>&1 | tail -6
