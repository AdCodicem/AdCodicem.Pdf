import re
import sys

path = sys.argv[1]
names = sys.argv[2:]
want = set()
for n in names:
    want.add(('files/' + n, 'default'))
    want.add(('files/' + n, 'count2'))
cur = None
for line in open(path, encoding='utf-8', errors='replace'):
    m = re.match(r'=== (\S+) (\S+)', line)
    if m:
        cur = (m.group(1), m.group(2))
    if cur in want:
        print(line.rstrip()[:300])
