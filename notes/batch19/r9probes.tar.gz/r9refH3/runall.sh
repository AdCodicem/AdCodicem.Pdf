#!/bin/bash
# Usage: runall.sh <log file>
cd /home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-11 || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_OUT=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9refH3/all-zz.txt
setsid timeout -k 15 1700 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build > "$1" 2>&1
echo "exit $?" >> "$1"
