#!/bin/bash
# Usage: run.sh <out file> <filter>
cd /home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-11 || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_OUT="$1"
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "$2" 2>&1 | tail -8
