#!/bin/bash
# Runs the probe methods matching $2 in the worktree $1, one dotnet process, bounded.
cd "$1" || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "$2" 2>&1 | tail -8
