#!/bin/bash
# usage: run.sh <filter-method or ALL>
cd /home/user/AdCodicem.Pdf/.claude/worktrees/wf_a01bab38-4ae-28 || exit 1
export DOTNET_GCHeapHardLimit=0xC0000000
if [ "$1" = "ALL" ]; then
  exec setsid timeout -k 15 1500 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build
else
  exec setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "$1"
fi
