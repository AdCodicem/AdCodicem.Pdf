#!/bin/bash
# usage: run.sh REPO OUTFILE
D=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r9ref-quoted
REPO="$1"
export DOTNET_GCHeapHardLimit=0xC0000000
export ZZ_REF_OUT="$2"
files=""
for f in quoted-in-data.pdf v2-after-s-noprev.pdf v3-after-s-noprev-control.pdf v4-before-s-noprev.pdf v5-after-s-rightprev.pdf $EXTRA; do
  files="$files;$D/files/$f"
done
export ZZ_REF_FILES="$files"
cd "$REPO" || exit 1
setsid timeout -k 15 900 dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- --filter-method "*ZzRefQuoted*" 2>&1 | tail -3
