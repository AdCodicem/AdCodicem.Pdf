"""Variants: a quoted /Type /XRef stream near a hybrid table's /Prev. usage: genv.py OUTDIR"""
import os
import sys

OUT = sys.argv[1]


def row(off, gen=0, kind='n'):
    return "%010d %05d %s \n" % (off, gen, kind)


def srows(rows):
    return "".join(chr(t) + chr((o >> 24) & 255) + chr((o >> 16) & 255) + chr((o >> 8) & 255) + chr(o & 255)
                   + chr((g >> 8) & 255) + chr(g & 255) for t, o, g in rows)


def obj(n, body):
    return "%d 0 obj\n%s\nendobj\n" % (n, body)


def build(quoted_text, embedded_before_s, s_prev, prev_shift):
    """Three revisions, hybrid newest. The oldest table X; rev 2 writes object 4, its xref stream S (object 6),
    and an embedded file 7 whose data holds quoted_text, before or after S; then the hybrid table T2 whose
    /Prev names X + prev_shift."""
    t = "%PDF-1.5\n%\xe2\xe3\xcf\xd3\n"
    c = len(t); t += obj(1, "<< /Type /Catalog /Pages 2 0 R >>")
    p = len(t); t += obj(2, "<< /Type /Pages /Kids [] /Count 0 >>")
    three = len(t); t += obj(3, "(three old)")
    five = len(t); t += obj(5, "(five old)")
    oldest = len(t)
    t += ("xref\n0 6\n" + row(0, 65535, 'f') + row(c) + row(p) + row(three) + row(0, 1, 'f') + row(five)
          + "trailer\n<< /Size 13 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % oldest)
    four = len(t); t += obj(4, "(four)")
    data = "%PDF-1.5 an attached file\n" + quoted_text + "%%EOF\n"
    head7 = "7 0 obj\n<< /Type /EmbeddedFile /Length %d >>\nstream\n" % len(data)
    seven_text = head7 + data + "\nendstream\nendobj\n"
    prevpart = "" if s_prev is None else " /Prev %010d" % s_prev
    probe = "6 0 obj\n<< /Type /XRef /Size 13 /W [1 4 2] /Index [4 1 6 2]%s /Root 1 0 R /Length %d >>\nstream\n%s\nendstream\nendobj\n"
    if embedded_before_s:
        seven = len(t); t += seven_text
        stream = len(t)
        rows6 = srows([(1, four, 0), (1, stream, 0), (1, seven, 0)])
        t += probe % (prevpart, len(rows6), rows6)
    else:
        stream = len(t)
        length6 = len(probe % (prevpart, 21, "x" * 21))
        seven = stream + length6
        rows6 = srows([(1, four, 0), (1, stream, 0), (1, seven, 0)])
        s6 = probe % (prevpart, len(rows6), rows6)
        assert len(s6) == length6
        t += s6
        assert len(t) == seven
        t += seven_text
    q = seven + len(head7) + len("%PDF-1.5 an attached file\n")
    newest = len(t)
    named = oldest + prev_shift
    t += ("xref\n0 1\n" + row(0, 65535, 'f') + "trailer\n<< /Size 13 /Root 1 0 R /Prev %d /XRefStm %d >>\nstartxref\n%d\n%%%%EOF\n"
          % (named, stream, newest))
    return t, dict(oldest=oldest, four=four, stream=stream, seven=seven, quoted=q, named=named, newest=newest)


def quoted_stream(prev=None):
    inner = srows([(1, 15, 0)])
    prevpart = "" if prev is None else " /Prev %d" % prev
    return "12 0 obj\n<< /Type /XRef /Size 13 /W [1 4 2] /Index [12 1]%s /Length %d >>\nstream\n%s\nendstream\nendobj\n" % (
        prevpart, len(inner), inner)


def plain_text():
    return "Notes on the file format; nothing here is a section of this file at all.\n" * 2


variants = {
    # S gives no /Prev (dropped), the quoted stream past S (deferred), the oldest table taken
    "v2-after-s-noprev.pdf": (quoted_stream(), False, None),
    # the same with plain text in the quoted stream's place (control)
    "v3-after-s-noprev-control.pdf": (plain_text(), False, None),
    # the quoted stream before S (as a writer lays out its objects): kept nearest-first, taken
    "v4-before-s-noprev.pdf": (quoted_stream(), True, None),
    # S gives the right /Prev (the oldest table), the quoted stream past S
    "v5-after-s-rightprev.pdf": (quoted_stream(), False, "OLDEST"),
}

for name, (text, before, sprev) in variants.items():
    # find a shift that puts the named offset nearer the quoted text than the oldest table
    first, meta = build(text, before, 0 if sprev == "OLDEST" else sprev, 0)
    shift = meta["seven"] + 10 - meta["oldest"]
    s_prev = meta["oldest"] if sprev == "OLDEST" else sprev
    final, meta = build(text, before, s_prev, shift)
    with open(os.path.join(OUT, name), "wb") as fh:
        fh.write(final.encode("latin-1"))
    meta["d_oldest"] = meta["named"] - meta["oldest"]
    meta["d_quoted"] = meta["quoted"] - meta["named"]
    meta["d_stream"] = meta["named"] - meta["stream"]
    print(name, meta)
