"""Lists every block of one class from a classify.py --tsv file, compactly: one line per hand-built shape or test row, and the
seeded files (r8own-gen) grouped by limit set, tag and reason kinds.

usage: python3 -I origins.py CLS.tsv [CLASS ...]   (default: worse)
"""
import collections
import sys


def kinds(reasons):
    out = []
    for r in reasons.split(" | "):
        head = r.split(":")[0].split("(")[0]
        out.append(head)
    return " ".join(out)


def main():
    path = sys.argv[1]
    classes = sys.argv[2:] or ["worse"]
    seeded = collections.defaultdict(list)
    named = []
    for line in open(path, encoding="utf-8"):
        key, cls, origin, reasons = line.rstrip("\n").split("\t")
        if cls not in classes:
            continue
        file, limits = key.rsplit(" ", 1)
        name = file.split("/", 1)[-1]
        if name.startswith("r8own-gen_"):
            g = name[len("r8own-gen_"):-4]
            seeded[(cls, limits, kinds(reasons))].append(g)
        else:
            named.append("%s %s [%s] %s  -- %s" % (cls, name, limits, kinds(reasons), origin))
    print("## named shapes and test rows (%d)" % len(named))
    for line in named:
        print(line)
    total = sum(len(v) for v in seeded.values())
    print("\n## seeded files r8own-gen (%d; origin: r8own/gen.py seeds 1000-3999, the own-stream lens differential;"
          " g001167/g002927/g001038 are [7](a)(b)(c), g003625/g003835/g002426/g001618 [11])" % total)
    for (cls, limits, k), gs in sorted(seeded.items(), key=lambda x: (x[0][1], -len(x[1]))):
        print("%s [%s] %s (%d): %s" % (cls, limits, k, len(gs), " ".join(gs)))


main()
