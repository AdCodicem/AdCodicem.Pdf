"""Compares a variant's ZzProtoDiff output with a baseline's, block by block.

usage: python3 -I classify.py VARIANT.txt BASELINE.txt [--manifest manifest.tsv] [--list N] [--show KEY ...] [--tsv OUT.tsv]

Classes (variant V against baseline B):
  identical     the blocks are byte-identical.
  wording-only  same sections taken (naming, named offset, offset, kind, state), same objects in both orders, same repair at
                opening, same Error and Warning finding codes (severity, rule, as multisets), no throw either side, no lost
                limit report, no read-order dependence of its own: what differs is message text (and, counted apart as
                'wording-only+codes', diagnostic codes, Information findings, a finding's location or the repair after reads).
  better        V reads the chain whole (no rebuild at opening, no throw, every section it took Read or Relocated, no Error
                xref.chain-loop / xref.section-not-found / xref.section-malformed / file.root-invalid / file.trailer-*), while B
                rebuilds at opening, serves another value for some object (a freed or older one: B's chain not whole) or gives
                an Error V does not, and V has none of these: a section farther off, a throw, a dependence on read order B does
                not have, a limit report B gives and V does not, opens that differ. An Error V gives and B does not (it can only
                be one outside the chain's, xref.hybrid-stream-wrong in practice), a lost section and the values do not bar it:
                they are named in the reasons. This is the one place the brief's two lists overlap; 'better' takes precedence.
  worse         not better, and one of: V rebuilds at opening where B does not; serves another value for any object in either
                order; gives an Error finding (by rule) B does not; takes a section farther off (matched by naming and named
                offset); loses a section B took (Read, Relocated or Malformed at an offset V took no section at); throws (a T
                line or a THROW value B does not have); depends on read order where B does not. Two signals beyond the brief,
                each named in the reasons: 'limit-lost' (B reports a limit.* code, or throws PdfLimitExceededException under
                ThrowOnLimit, and V does not: a guard's cut no longer reported, ADR 34) and 'open-differs' (V's two opens differ).
  other         anything else that differs.
Tags on worse blocks (reading aids, not classes): MIXED (V's chain whole while B rebuilt at opening or gave an Error V does not),
BOTH-BROKEN (neither chain whole, same values in both orders, same repair at opening), NEARER (B took some section farther off
than V did).
Reasons are printed beside every better and worse block, with the manifest's origin.
"""
import argparse
import collections
import re
import sys

CHAIN_ERRORS = {"xref.chain-loop", "xref.section-not-found", "xref.section-malformed", "file.root-invalid",
                "file.trailer-missing", "file.trailer-malformed"}
TAKEN = {"Read", "Relocated", "Malformed"}
FOUND = {"Read", "Relocated"}


def unesc(s):
    return s  # messages are compared as written; no field needs unescaping for the classes


class Block:
    __slots__ = ("key", "text", "open_rep", "after_rep", "sections", "diags", "added", "objects", "findings", "throws",
                 "open_differs")

    def __init__(self, key, lines):
        self.key = key
        self.text = "\n".join(lines)
        self.open_rep = None
        self.after_rep = {}
        self.sections = []
        self.diags = []
        self.added = {"asc": [], "desc": []}
        self.objects = {}
        self.findings = []
        self.throws = []
        self.open_differs = False
        for line in lines:
            f = line.split("\t")
            tag = f[0]
            if tag == "R":
                if f[1] == "open":
                    self.open_rep = f[2] == "True"
                else:
                    self.after_rep[f[1]] = f[2] == "True"
            elif tag == "S":
                self.sections.append((f[1], int(f[2]), int(f[3]), f[4], f[5]))
            elif tag == "D":
                self.diags.append((f[1], f[2], f[3], f[4] if len(f) > 4 else ""))
            elif tag == "A":
                self.added[f[1]].append((f[2], f[3], f[4], f[5] if len(f) > 5 else ""))
            elif tag == "O":
                self.objects[int(f[1])] = (f[2], f[3])
            elif tag == "F":
                self.findings.append((f[1], f[2], f[3], f[4] if len(f) > 4 else ""))
            elif tag == "T":
                self.throws.append((f[1], f[2]))
            elif tag == "X":
                self.open_differs = True

    # Derived views.
    def errors(self):
        return collections.Counter(r for s, r, _, _ in self.findings if s == "Error")

    def ew(self):
        return collections.Counter((s, r) for s, r, _, _ in self.findings if s in ("Error", "Warning"))

    def order_dependent(self):
        return any(a != d for a, d in self.objects.values())

    def value_throws(self):
        return {n for n, (a, d) in self.objects.items() if a.startswith("THROW") or d.startswith("THROW")}

    def limit_codes(self):
        codes = {c for _, c, _, _ in self.diags if c.startswith("limit.")}
        for order in ("asc", "desc"):
            codes |= {c for _, c, _, _ in self.added[order] if c.startswith("limit.")}
        if any(t == "PdfLimitExceededException" for _, t in self.throws):
            codes.add("throw:PdfLimitExceededException")
        return codes

    def chain_whole(self):
        if self.open_rep is not False or self.throws or self.value_throws() or self.open_differs:
            return False
        if any(state not in FOUND and state != "NamedAgain" for _, _, _, _, state in self.sections):
            return False
        return not (set(self.errors()) & CHAIN_ERRORS)

    def stripped(self):
        """The block without message texts: what is left once wording is set aside."""
        return (self.open_rep, tuple(sorted(self.after_rep.items())), tuple(self.sections),
                tuple(d[:3] for d in self.diags), tuple(a[:3] for a in self.added["asc"]),
                tuple(a[:3] for a in self.added["desc"]), tuple(sorted(self.objects.items())),
                tuple(f[:3] for f in self.findings), tuple(self.throws), self.open_differs)


def parse(path):
    blocks = collections.OrderedDict()
    key = None
    lines = []
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if line.startswith("=== "):
                if key is not None:
                    blocks[key] = Block(key, lines)
                key = line[4:]
                lines = [line]
            else:
                lines.append(line)
    if key is not None:
        blocks[key] = Block(key, lines)
    return blocks


def farther_and_lost(v, b):
    """Sections B took that V took farther off (matched by naming and named offset, in order), and offsets B took that V took
    no section at."""
    farther = []
    used = [False] * len(v.sections)
    for nb, named, off, kind, state in b.sections:
        if state not in TAKEN:
            continue
        for i, (vn, vnamed, voff, vkind, vstate) in enumerate(v.sections):
            if used[i] or vn != nb or vnamed != named:
                continue
            used[i] = True
            if vstate in TAKEN and abs(voff - named) > abs(off - named):
                farther.append("%s %d: %d -> %d" % (nb, named, off, voff))
            break
    v_taken = {off for _, _, off, _, state in v.sections if state in TAKEN}
    lost = sorted({off for _, _, off, _, state in b.sections if state in TAKEN} - v_taken)
    return farther, lost


def classify(v, b, b_rules=None, v_rules=None):
    if v.text.split("\n", 1)[1:] == b.text.split("\n", 1)[1:]:
        return "identical", []
    worse = []
    if v.open_rep and not b.open_rep:
        worse.append("rebuild-at-open")
    diff_values = sorted(n for n in set(v.objects) | set(b.objects) if v.objects.get(n) != b.objects.get(n))
    if diff_values:
        worse.append("values:" + ",".join(
            "%d=%s/%s<-%s/%s" % ((n,) + v.objects.get(n, ("-", "-")) + b.objects.get(n, ("-", "-"))) for n in diff_values[:4])
            + (",..." if len(diff_values) > 4 else ""))
    new_errors = sorted(set(v.errors()) - set(b.errors()))
    unknown = [r for r in new_errors if b_rules is not None and r not in b_rules]
    known = [r for r in new_errors if r not in unknown]
    if known:
        worse.append("error+:" + ",".join(known))
    farther, lost = farther_and_lost(v, b)
    if farther:
        worse.append("farther:" + ";".join(farther))
    if lost:
        worse.append("lost-section:" + ",".join(str(x) for x in lost))
    v_throws = set(v.throws) | {("value", n) for n in v.value_throws()}
    b_throws = set(b.throws) | {("value", n) for n in b.value_throws()}
    if v_throws - b_throws:
        worse.append("throws:" + ",".join("%s:%s" % t for t in sorted(v_throws - b_throws, key=str)))
    if v.order_dependent() and not b.order_dependent():
        worse.append("order-dependent")
    limit_lost = sorted(b.limit_codes() - v.limit_codes())
    if limit_lost:
        worse.append("limit-lost:" + ",".join(limit_lost))
    if v.open_differs and not b.open_differs:
        worse.append("open-differs")

    # Better: V's chain whole, B rebuilding at opening, serving another value or giving an Error V does not, and none of the
    # blocking signals on V's side (a lost section and the values are what B's fault explains).
    # An Error V gives and B does not is no bar here: V's chain being whole, it can only be an Error of another kind than the
    # chain's (xref.hybrid-stream-wrong in practice), while B's chain broke; it is named in the reasons.
    blocking = [w for w in worse if w.split(":")[0] in ("rebuild-at-open", "farther", "throws", "order-dependent",
                                                          "limit-lost", "open-differs")]
    gone_errors = sorted(r for r in set(b.errors()) - set(v.errors()) if v_rules is None or r in v_rules)
    better = []
    if b.open_rep and not v.open_rep:
        better.append("baseline-rebuilds-at-open")
    if diff_values and not b.chain_whole():
        better.append("values-differ")
    if gone_errors:
        better.append("baseline-error:" + ",".join(gone_errors))
    notes = ["error+unknown-to-baseline:" + ",".join(unknown)] if unknown else []
    if v.chain_whole() and better and not blocking:
        reasons = better + [w for w in worse if w.split(":")[0] in ("values", "lost-section", "error+")] + notes
        return "better", reasons
    if worse:
        tags = []
        strong = [x for x in better if x != "values-differ"]
        if v.chain_whole() and strong:
            tags.append("MIXED(also " + ";".join(strong) + ")")
        if not v.chain_whole() and not b.chain_whole() and not diff_values and v.open_rep == b.open_rep:
            tags.append("BOTH-BROKEN(same values)")
        nearer, _ = farther_and_lost(b, v)
        if nearer:
            tags.append("NEARER(" + ";".join(nearer) + " is B's, farther)")
        return "worse", tags + worse + notes
    if unknown:
        return "other", notes + describe_codes(v, b)

    # Wording: same sections, objects, repair at opening, Error and Warning codes; no worse signal (checked above).
    if (v.sections == b.sections and v.objects == b.objects and v.open_rep == b.open_rep and v.ew() == b.ew()
            and set(v.throws) == set(b.throws)):
        if v.stripped() == b.stripped():
            return "wording-only", []
        return "wording-only+codes", describe_codes(v, b)
    return "other", describe_codes(v, b) + (["baseline-better-signals:" + ";".join(better)] if better else [])


def describe_codes(v, b):
    out = []
    vd = collections.Counter(d[:2] for d in v.diags)
    bd = collections.Counter(d[:2] for d in b.diags)
    if vd != bd:
        plus = vd - bd
        minus = bd - vd
        out.append("diag" + "".join(" +%s/%s" % k for k in plus) + "".join(" -%s/%s" % k for k in minus))
    for order in ("asc", "desc"):
        va = collections.Counter(a[:2] for a in v.added[order])
        ba = collections.Counter(a[:2] for a in b.added[order])
        if va != ba:
            out.append("added-%s" % order + "".join(" +%s/%s" % k for k in va - ba) + "".join(" -%s/%s" % k for k in ba - va))
    vf = collections.Counter(f[:2] for f in v.findings)
    bf = collections.Counter(f[:2] for f in b.findings)
    if vf != bf:
        out.append("findings" + "".join(" +%s/%s" % k for k in vf - bf) + "".join(" -%s/%s" % k for k in bf - vf))
    elif [f[:3] for f in v.findings] != [f[:3] for f in b.findings]:
        out.append("finding-locations")
    if v.sections != b.sections:
        out.append("sections")
    if v.after_rep != b.after_rep:
        out.append("repair-after %s<-%s" % (v.after_rep, b.after_rep))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("variant")
    ap.add_argument("baseline")
    ap.add_argument("--manifest", default="/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r8proto/manifest.tsv")
    ap.add_argument("--list", type=int, default=10**9, help="at most this many better and worse blocks listed")
    ap.add_argument("--show", nargs="*", default=[], help="print both blocks of these keys ('path limits')")
    ap.add_argument("--tsv", help="write key, class, origin, reasons for every block to this file")
    args = ap.parse_args()

    origins = {}
    try:
        for line in open(args.manifest, encoding="utf-8"):
            f = line.rstrip("\n").split("\t")
            if len(f) >= 2 and f[0] != "path":
                origins[f[0]] = f[1]
    except OSError:
        pass

    v = parse(args.variant)
    b = parse(args.baseline)
    b_rules = {r for blk in b.values() for sev, r, _, _ in blk.findings if sev == "Error"}
    v_rules = {r for blk in v.values() for sev, r, _, _ in blk.findings if sev == "Error"}
    keys = list(b) + [k for k in v if k not in b]
    counts = collections.Counter()
    by_limits = collections.defaultdict(collections.Counter)
    listed = collections.defaultdict(list)
    rows = []
    for key in keys:
        path, limits = key.rsplit(" ", 1)
        if key not in v or key not in b:
            cls, reasons = "missing", ["only in " + ("baseline" if key in b else "variant")]
        else:
            cls, reasons = classify(v[key], b[key], b_rules, v_rules)
        counts[cls] += 1
        by_limits[limits][cls] += 1
        rows.append((key, cls, origins.get(path, "?"), reasons))
        if cls in ("better", "worse", "other", "missing"):
            listed[cls].append((key, origins.get(path, "?"), reasons))

    order = ["identical", "wording-only", "wording-only+codes", "better", "worse", "other", "missing"]
    print("blocks %d  variant=%s  baseline=%s" % (len(keys), args.variant, args.baseline))
    print("  ".join("%s %d" % (c, counts[c]) for c in order))
    mixed = sum(1 for _, _, r in listed["worse"] if r and r[0].startswith("MIXED"))
    both = sum(1 for _, _, r in listed["worse"] if any(x.startswith("BOTH-BROKEN") for x in r))
    near = sum(1 for _, _, r in listed["worse"] if any(x.startswith("NEARER") for x in r))
    print("  worse tagged MIXED (variant's chain whole, baseline rebuilt at opening or gave an Error it does not) %d;"
          " BOTH-BROKEN (neither chain whole, same values) %d; NEARER (the baseline took some section farther off) %d"
          % (mixed, both, near))
    if b_rules - v_rules or v_rules - b_rules:
        print("  Error rules only the variant's output gives: %s; only the baseline's: %s"
              % (sorted(v_rules - b_rules), sorted(b_rules - v_rules)))
    fam = collections.defaultdict(collections.Counter)
    for key, cls, origin, reasons in rows:
        fam[key.split("/", 1)[-1].split("_", 1)[0]][cls] += 1
    print("  by file family:")
    for name in sorted(fam):
        print("    %-24s " % name + "  ".join("%s %d" % (c, fam[name][c]) for c in order if fam[name][c]))
    for limits in sorted(by_limits):
        print("  [%s] " % limits + "  ".join("%s %d" % (c, by_limits[limits][c]) for c in order if by_limits[limits][c]))
    def group(reasons):
        if reasons and reasons[0].startswith("MIXED"):
            return "worse, MIXED"
        if any(r.startswith("BOTH-BROKEN") for r in reasons):
            return "worse, BOTH-BROKEN"
        return "worse, plain"

    sections = collections.OrderedDict()
    for name in ("worse, plain", "worse, MIXED", "worse, BOTH-BROKEN"):
        sections[name] = [x for x in listed["worse"] if group(x[2]) == name]
    sections["better"] = listed["better"]
    sections["missing"] = listed["missing"]
    for name, items in sections.items():
        if not items:
            continue
        print("\n## %s (%d)" % (name, len(items)))
        for key, origin, reasons in items[:args.list]:
            print("%s\n    origin: %s\n    why: %s" % (key, origin, " | ".join(reasons)))
        if len(items) > args.list:
            print("... %d more" % (len(items) - args.list))
    if listed["other"]:
        kinds = collections.Counter(" ".join(r.split(" ")[0] for r in reasons) for _, _, reasons in listed["other"])
        print("\n## other (%d), by what differs: %s" % (len(listed["other"]), dict(kinds.most_common())))
    if args.tsv:
        with open(args.tsv, "w", encoding="utf-8") as fh:
            for key, cls, origin, reasons in rows:
                fh.write("%s\t%s\t%s\t%s\n" % (key, cls, origin, " | ".join(reasons)))
    for key in args.show:
        for name, blocks in (("variant", v), ("baseline", b)):
            print("\n---- %s %s" % (name, key))
            print(blocks[key].text if key in blocks else "(absent)")


if __name__ == "__main__":
    sys.exit(main())
