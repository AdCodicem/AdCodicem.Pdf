#!/bin/bash
# Runs the round 8 own-stream differential on a variant's worktree and classifies it against the three baselines.
#
# usage: run_variant.sh WORKTREE NAME [--no-build]
#   WORKTREE  a git worktree of the repository holding the variant (never the main checkout)
#   NAME      a short name for the outputs: out-NAME.txt, cls-NAME-vs-{main,d3ef,head}.{txt,tsv} in this folder
# Copies the probe in as tests/AdCodicem.Pdf.Tests/ZzProtoDiffTests.cs, builds the solution in Release, runs the probe twice
# (the two outputs must be byte-identical), classifies, and deletes the probe file again (it is never committed).
set -euo pipefail
R=/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad/r8proto
W=$(cd "$1" && pwd)
NAME=$2
if [ "$W" = "/home/user/AdCodicem.Pdf" ]; then echo "refusing to run in the main checkout" >&2; exit 2; fi
PROBE="$W/tests/AdCodicem.Pdf.Tests/ZzProtoDiffTests.cs"
cp "$R/ZzProtoDiffTests.cs.txt" "$PROBE"
trap 'rm -f "$PROBE"' EXIT
cd "$W"
if [ "${3:-}" != "--no-build" ]; then
  dotnet build AdCodicem.Pdf.slnx -c Release -m:2 > "$R/build-$NAME.log" 2>&1 || { tail -30 "$R/build-$NAME.log"; exit 1; }
  grep -E "Warning\(s\)|Error\(s\)" "$R/build-$NAME.log" | tail -2
fi
for run in 1 2; do
  ZZ_PROTO_MANIFEST="$R/manifest.tsv" ZZ_PROTO_OUT="$R/out-$NAME.run$run.txt" \
    dotnet test --project tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj -c Release --no-build -- \
    --filter-method "*ZzProtoDiff*" > "$R/test-$NAME.run$run.log" 2>&1 || { tail -20 "$R/test-$NAME.run$run.log"; exit 1; }
done
if ! cmp -s "$R/out-$NAME.run1.txt" "$R/out-$NAME.run2.txt"; then echo "NOT DETERMINISTIC: out-$NAME.run1.txt differs from run2" >&2; exit 1; fi
mv "$R/out-$NAME.run1.txt" "$R/out-$NAME.txt"; rm -f "$R/out-$NAME.run2.txt"
echo "blocks: $(grep -c '^=== ' "$R/out-$NAME.txt") (deterministic over two runs)"
for base in main d3ef head; do
  python3 -I "$R/classify.py" "$R/out-$NAME.txt" "$R/out-$base.txt" --manifest "$R/manifest.tsv" \
    --tsv "$R/cls-$NAME-vs-$base.tsv" > "$R/cls-$NAME-vs-$base.txt"
  echo "== vs $base"; sed -n 2,3p "$R/cls-$NAME-vs-$base.txt"
done
