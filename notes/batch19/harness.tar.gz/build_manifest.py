"""Collects the round 8 own-stream files into r8proto/files/ and writes r8proto/manifest.tsv.

usage: python3 -I build_manifest.py
Inputs: the generators' outputs regenerated into r8proto/regen/ (all byte-identical to the files the agents kept), the
C#-built shapes written by ZzProtoGenTests into r8proto/handgen/ (with hand.tsv), and the files kept as they were.
A file whose bytes another already has is not copied again: its origin and limit sets join the first one's line.
"""
import glob
import hashlib
import json
import os
import shutil

S = "/tmp/claude-0/-home-user-AdCodicem-Pdf/b5ddd9fc-0507-5e11-8a94-c9e1fedd4860/scratchpad"
P = S + "/r8proto"
FILES = P + "/files"
REGEN = P + "/regen"
HAND = P + "/handgen"

LIMIT_ORDER = ["default", "trailer100", "count2", "trailer256", "throw", "trailer1m"]

entries = []  # [name, [origins], set(limits)]
by_hash = {}


def add(src, name, origin, limits):
    data = open(src, "rb").read()
    h = hashlib.sha256(data).hexdigest()
    if h in by_hash:
        e = by_hash[h]
        if origin not in e[1]:
            e[1].append(origin)
        e[2].update(limits)
        return
    if os.path.exists(os.path.join(FILES, name)):
        raise SystemExit("name clash: " + name)
    with open(os.path.join(FILES, name), "wb") as fh:
        fh.write(data)
    e = [name, [origin], set(limits)]
    by_hash[h] = e
    entries.append(e)


def main():
    if os.path.isdir(FILES):
        shutil.rmtree(FILES)
    os.makedirs(FILES)

    # 1. The 3,000 seeded hybrid files of the own-stream lens (r8own/gen.py), run as the reviewer ran them.
    cited = {"g001167": "[7](a)", "g002927": "[7](b)", "g001038": "[7](c)", "g003625": "[11]", "g003835": "[11]",
             "g002426": "[11]", "g001618": "[11]"}
    seeds = {}
    for line in open(S + "/r8own/gen/manifest.jsonl"):
        m = json.loads(line)
        seeds[m["name"]] = m["seed"]
    for path in sorted(glob.glob(S + "/r8own/gen/*.pdf")):
        base = os.path.basename(path)[:-4]
        tag = cited.get(base, "[7][8][29]")
        add(path, "r8own-gen_" + base + ".pdf", "%s r8own/gen.py seed %d (3,000 seeded hybrid files)" % (tag, seeds[base + ".pdf"]),
            ["default", "trailer100", "count2"])

    # 2. The C#-built shapes (reviewers' and refuters' builders, and the HybridFiles rows), with their own limit sets.
    for line in open(HAND + "/hand.tsv", encoding="utf-8"):
        name, origin, limits = line.rstrip("\n").split("\t")
        add(os.path.join(HAND, name), name, origin, limits.split(","))

    # 3. r8own's first CutPrev version (cut-*.cutprev-True.pdf, /Prev last in a shorter dictionary), and the copies kept beside it.
    add(S + "/r8own/cut-head.txt.cutprev-True.pdf", "r8own_cut1-cutprev-True.pdf", "[9] r8own CutPrev first version (cut-*.txt)",
        ["default", "trailer100"])
    for path in sorted(glob.glob(S + "/r8own/*.pdf")):
        add(path, "r8own_" + os.path.basename(path), "[8][9] r8own kept copy " + os.path.basename(path), ["default"])
    for path in sorted(glob.glob(S + "/r8refbudget/head.txt.*.pdf")):
        add(path, "r8refbudget_" + os.path.basename(path), "[8] r8refbudget kept copy " + os.path.basename(path), ["default"])

    # 4. r8ref-own (refuter of [7]): NearOwn and Dense shapes.
    for path in sorted(glob.glob(S + "/r8ref-own/out/*.pdf")):
        add(path, "r8ref-own_" + os.path.basename(path), "[7][8] r8ref-own ZzRefOwnFirstRevTests " + os.path.basename(path)[:-4],
            ["default"])

    # 5. r8ref-prevform (refuter of [11]): shape A with the stream's /Prev in eight forms, and g001618 varied.
    for path in sorted(glob.glob(REGEN + "/prevform/*.pdf")):
        add(path, "r8ref-prevform_" + os.path.basename(path), "[11] r8ref-prevform/gen.py " + os.path.basename(path)[:-4], ["default"])
    for path in sorted(glob.glob(REGEN + "/v1618/*.pdf")):
        add(path, "r8ref-prevform-v1618_" + os.path.basename(path), "[11] r8ref-prevform/vary1618.py " + os.path.basename(path)[:-4],
            ["default"])
    for path in sorted(glob.glob(S + "/r8ref-prevform/rev/*.pdf")):
        add(path, "r8ref-prevform-rev_" + os.path.basename(path), "[11] r8ref-prevform/rev copy", ["default"])

    # 6. [29]: genL (reviewer), ref35/gen/mk.py (refuter, same files plus 'other' and the oldest stream's own /Prev), genA f00994_n18.
    for path in sorted(glob.glob(REGEN + "/genL/*.pdf")):
        add(path, "r8bat-genL_" + os.path.basename(path), "[29] lot19/r8bat/genL.py " + os.path.basename(path)[:-4], ["default"])
    for path in sorted(glob.glob(REGEN + "/ref35/*.pdf")):
        add(path, "ref35_" + os.path.basename(path), "[29] ref35/gen/mk.py " + os.path.basename(path)[:-4], ["default"])
    add(S + "/ref35/fa/f00994_n18.pdf", "r8bat-genA_f00994_n18.pdf", "[29] lot19/r8bat/gen8.py seed 202611071648 f00994_n18 (ref35/fa copy)",
        ["default"])

    # 7. [30]: genK (reviewer), genK2 lost/t1 (reviewer's variants), r8ref-kagain genP/genQ (refuter).
    for sub, origin in (("genK", "[30] lot19/r8bat/genK.py"), ("genKlost", "[30] lot19/r8bat/genK2.py lost"),
                        ("genKt1", "[30] lot19/r8bat/genK2.py t1"), ("filesP", "[30] lot19/r8ref-kagain/genP.py"),
                        ("filesQ", "[30] lot19/r8ref-kagain/genQ.py")):
        prefix = {"genK": "r8bat-genK_", "genKlost": "r8bat-genKlost_", "genKt1": "r8bat-genKt1_", "filesP": "r8ref-kagain-P_",
                  "filesQ": "r8ref-kagain-Q_"}[sub]
        for path in sorted(glob.glob(REGEN + "/" + sub + "/*.pdf")):
            add(path, prefix + os.path.basename(path), origin + " " + os.path.basename(path)[:-4], ["default"])
    for path in sorted(glob.glob(S + "/lot19/r8ref-kagain/files/*.pdf")):
        add(path, "r8ref-kagain_" + os.path.basename(path), "[30] lot19/r8ref-kagain/files (genK.py)", ["default"])

    with open(P + "/manifest.tsv", "w", encoding="utf-8") as fh:
        fh.write("path\torigin\tlimits\n")
        for name, origins, limits in entries:
            ordered = [x for x in LIMIT_ORDER if x in limits]
            fh.write("files/%s\t%s\t%s\n" % (name, " | ".join(origins), ",".join(ordered)))
    blocks = sum(len(e[2]) for e in entries)
    print("files", len(entries), "blocks", blocks)


main()
