"""usage: python -I run.py COMMIT WORKERS [ID...] [--chain-only] -- ADR 53 mutants of the guard flag the passed-over
report reads (the parted /Type and the white-space guard).

Each worker owns a git worktree at COMMIT under this folder (w1, w2, ...), the remote corpus hard-linked into it. For
each mutant: the file is restored from git, one exact replacement is applied, the test project is built in Release,
and the chain tests run; a mutant they do not kill runs the whole AdCodicem.Pdf.Tests project. One line per mutant goes
to summary.txt, logs to logs/.
"""
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = 'C:/Users/clemm/repos/AdCodicem.Pdf/.claude/worktrees/wf_629fa085-d7b-1'
CORPUS = 'C:/Users/clemm/repos/AdCodicem.Pdf/tests/corpus/remote'
READER = 'src/AdCodicem.Pdf/IO/PdfFileReader.cs'
PROJ = 'tests/AdCodicem.Pdf.Tests/AdCodicem.Pdf.Tests.csproj'
env = dict(os.environ, DOTNET_CLI_UI_LANGUAGE='en-US', DOTNET_GCHeapHardLimit='0xC0000000')

COND = ('if (!candidate && cutByGuard && value is PdfDictionary { } parted && parted.GetRaw(PdfName.Type) is PdfName type &&\n'
        '                MayBePartedXRef(type))')
SETNEW = 'MayBePartedXRef(type))\n            {\n                _guardMayHideLink = true;\n'
HELPER = 'type.Value.Length < PdfName.XRef.Value.Length && PdfName.XRef.Value.StartsWith(type.Value, StringComparison.Ordinal);'
REPORT = 'if (ChainStoppedByGuard || _guardMayHideLink)'
SETWS = '            _guardMayHideLink = true;\n            section.Fault = "holds neither the xref keyword nor an object";'

MUTANTS = {
    'M01': (COND, COND.replace('!candidate && ', '')),
    'M02': (COND, COND.replace('!candidate', 'candidate')),
    'M03': (COND, COND.replace('cutByGuard && ', '')),
    'M04': (COND, COND.replace('&& cutByGuard &&', '&& !cutByGuard &&')),
    'M05': (COND, COND.replace(' is PdfName type &&\n                MayBePartedXRef(type))', ' is PdfName)')),
    'M06': (COND, COND.replace('MayBePartedXRef(type))', '!MayBePartedXRef(type))')),
    'M07': (COND, COND.replace('is PdfName type', 'is not PdfName type')),
    'M08': (COND, COND.replace('value is PdfDictionary { } parted', 'value is not PdfDictionary { } parted')),
    'M09': (COND, 'if (!(' + COND[4:] + ')'),
    'M10': (SETNEW, 'MayBePartedXRef(type))\n            {\n'),
    'M11': (HELPER, HELPER.replace('Length < PdfName', 'Length <= PdfName')),
    'M12': (HELPER, HELPER.replace('PdfName.XRef.Value.Length &&', 'PdfName.XRef.Value.Length - 1 &&')),
    'M13': (HELPER, HELPER.replace('PdfName.XRef.Value.Length &&', 'PdfName.XRef.Value.Length + 1 &&')),
    'M14': (HELPER, 'PdfName.XRef.Value.StartsWith(type.Value, StringComparison.Ordinal);'),
    'M15': (HELPER, 'type.Value.Length < PdfName.XRef.Value.Length;'),
    'M16': (HELPER, HELPER.replace('Length < PdfName', 'Length >= PdfName')),
    'M17': (HELPER, HELPER.replace('&& PdfName.XRef.Value.StartsWith', '&& !PdfName.XRef.Value.StartsWith')),
    'M18': (HELPER, 'false;'),
    'M19': (REPORT, 'if (_guardMayHideLink)'),
    'M20': (REPORT, 'if (ChainStoppedByGuard)'),
    'M21': (REPORT, 'if (!(ChainStoppedByGuard || _guardMayHideLink))'),
    'M22': (REPORT, 'if (!ChainStoppedByGuard || _guardMayHideLink)'),
    'M23': (REPORT, 'if (ChainStoppedByGuard || !_guardMayHideLink)'),
    'M20b': (REPORT, 'if (ChainStoppedByGuard || (_guardMayHideLink && _xref.Count < 0))'),
    'M24': (SETWS, '            section.Fault = "holds neither the xref keyword nor an object";'),
}


def run(cmd, cwd, timeout, log):
    with open(log, 'w', encoding='utf-8') as handle:
        process = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT)
        try:
            return process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True)
            return 'timeout'


def worker(name, commit, jobs, out, lock):
    tree = os.path.join(HERE, name)
    if not os.path.isdir(tree):
        subprocess.run(['git', 'worktree', 'add', '--detach', tree, commit], cwd=REPO, check=True, capture_output=True)
        subprocess.run(['cp', '-al', CORPUS, os.path.join(tree, 'tests', 'corpus', 'remote')], check=True)
    while True:
        try:
            mid = jobs.get_nowait()
        except queue.Empty:
            return
        t0 = time.time()
        subprocess.run(['git', 'checkout', '--', READER], cwd=tree, check=True)
        path = os.path.join(tree, READER)
        text = open(path, encoding='utf-8', newline='').read()
        old, new = MUTANTS[mid]
        if text.count(old) != 1:
            line = f'{mid}: NOT APPLIED ({text.count(old)} occurrences)'
        else:
            open(path, 'w', encoding='utf-8', newline='').write(text.replace(old, new))
            log = os.path.join(HERE, 'logs', f'{mid}')
            rc = run(['dotnet', 'build', PROJ, '-c', 'Release', '-m:2'], tree, 1500, log + '-build.txt')
            if rc != 0:
                errors = [l.strip() for l in open(log + '-build.txt', encoding='utf-8', errors='replace') if ' error ' in l][:2]
                line = f'{mid}: NOT VIABLE (build) {errors}'
            else:
                rc = run(['dotnet', 'test', '--project', PROJ, '-c', 'Release', '--no-build', '--', '--filter-class',
                          '*CrossReferenceChainTests'], tree, 1500, log + '-chain.txt')
                body = open(log + '-chain.txt', encoding='utf-8', errors='replace').read()
                failed = sorted(set(re.findall(r'failed AdCodicem\.Pdf\.Tests\.(\w+\.\w+)', body)))
                if rc != 0:
                    line = f'{mid}: KILLED by chain tests rc={rc} {len(failed)} tests {failed[:6]}'
                elif CHAIN_ONLY:
                    line = f'{mid}: SURVIVED chain tests'
                else:
                    rc = run(['dotnet', 'test', '--project', PROJ, '-c', 'Release', '--no-build'], tree, 3600, log + '-suite.txt')
                    body = open(log + '-suite.txt', encoding='utf-8', errors='replace').read()
                    failed = sorted(set(re.findall(r'failed AdCodicem\.Pdf\.Tests\.(\w+\.\w+)', body)))
                    total = re.search(r'total: (\d+)\s+failed: (\d+)', body)
                    state = 'KILLED by suite' if rc != 0 else 'SURVIVED suite'
                    line = f'{mid}: {state} rc={rc} {total.groups() if total else None} {failed[:6]}'
        subprocess.run(['git', 'checkout', '--', READER], cwd=tree, check=True)
        line += f' ({time.time() - t0:.0f}s)'
        with lock:
            out.write(line + '\n')
            out.flush()
            print(line, flush=True)


CHAIN_ONLY = '--chain-only' in sys.argv


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    commit, workers = args[0], int(args[1])
    ids = args[2:] or list(MUTANTS)
    os.makedirs(os.path.join(HERE, 'logs'), exist_ok=True)
    jobs = queue.Queue()
    for mid in ids:
        jobs.put(mid)
    lock = threading.Lock()
    with open(os.path.join(HERE, 'summary.txt'), 'a', encoding='utf-8') as out:
        threads = [threading.Thread(target=worker, args=(f'w{k}', commit, jobs, out, lock)) for k in range(1, workers + 1)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()


main()
