"""usage: python -X utf8 reflow.py FILE START END [WIDTH] -- rewraps lines START..END (1-based, inclusive) of FILE, which
share one comment prefix (indentation then '/// ' or '// '), greedily at WIDTH columns (120 by default). Spaces inside an
XML tag, and the space before an em dash, never break a line."""
import re
import sys

path, start, end = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
width = int(sys.argv[4]) if len(sys.argv) > 4 else 120
lines = open(path, encoding='utf-8').read().split('\n')
block = lines[start - 1:end]
m = re.match(r'^(\s*(?:///|//) )', block[0])
prefix = m.group(1)
for line in block:
    assert line.startswith(prefix), line
text = ' '.join(line[len(prefix):].strip() for line in block)
NBSP = '\u0001'
text = re.sub(r'<[^>]*>', lambda t: t.group(0).replace(' ', NBSP), text)
text = text.replace(' —', NBSP + '—')
words = text.split(' ')
out = []
current = ''
for word in words:
    candidate = word if not current else current + ' ' + word
    if len(prefix) + len(candidate.replace(NBSP, ' ')) <= width or not current:
        current = candidate
    else:
        out.append(current)
        current = word
out.append(current)
new = [prefix + line.replace(NBSP, ' ') for line in out]
lines[start - 1:end] = new
open(path, 'w', encoding='utf-8', newline='').write('\n'.join(lines))
for line in new:
    print(len(line), line)
