"""usage: python split.py WORKTREE OUTDIR -- writes OUTDIR/HybridFiles.cs and OUTDIR/CrossReferenceChainTests.cs: the
worktree's versions without the parted-type builder and its theory, for the tests-only commit that comes first."""
import os
import sys

tree, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)

hybrid = open(os.path.join(tree, 'tests/AdCodicem.Pdf.Tests/HybridFiles.cs'), encoding='utf-8', newline='').read()
start = hybrid.index('    /// <summary>\n    /// A one-page document saved three times, whose oldest section is cross-reference stream 7')
end = hybrid.index('    /// <summary>\n    /// A one-page document saved twice, whose middle table\'s')
hybrid = hybrid[:start] + hybrid[end:]
open(os.path.join(out, 'HybridFiles.cs'), 'w', encoding='utf-8', newline='').write(hybrid)

chain = open(os.path.join(tree, 'tests/AdCodicem.Pdf.Tests/CrossReferenceChainTests.cs'), encoding='utf-8', newline='').read()
start = chain.index('    [Theory]\n    [InlineData("stream 6", "spaces", true, "/XRef", 1, "missing", false)]')
end = chain.index('    [Theory]', chain.index('document.Reader.ChainStoppedByGuard.Should().Be(oldestRead == "cut");'))
chain = chain[:start] + chain[end:]
open(os.path.join(out, 'CrossReferenceChainTests.cs'), 'w', encoding='utf-8', newline='').write(chain)
print('ok', len(hybrid), len(chain))
